package accesoadatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AccesoADatos {

    private String url;
    private String user;
    private String pass;
    private static Connection con;
    private static Statement statement;
    private ListaDeComponentes listaComponentes;
    private List<Componente> lista;

    public AccesoADatos() throws ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        url = "jdbc:postgresql://localhost:5432/componentes";
        user = "postgres";
        pass = "admin";
        listaComponentes = new ListaDeComponentes();
        lista = new ArrayList<>();
        con = null;

    }

    public Statement conectar() {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            statement = con.createStatement();
        } catch (SQLException se) {
            se.printStackTrace();
        }
        try {
            con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return statement;
    }

    public List<Componente> obtenerPorTexto(String texto) {
        texto = texto.toLowerCase();
        String sentencia = "SELECT marca, modelo, categoria, precio"
                + " FROM componentes"
                + " WHERE LOWER(marca) LIKE '%" + texto + "%' OR"
                + " LOWER(modelo) LIKE '%" + texto + "%' OR"
                + " LOWER(categoria) LIKE '%" + texto + "%' ";
        try {

            ResultSet rs = conectar().executeQuery(sentencia);
            while (rs.next()) {
                lista.add((new Componente(rs.getString("marca"),
                        rs.getString("modelo"), rs.getString("categoria"),
                        rs.getFloat("precio"))));
            }

        } catch (SQLException e) {
            System.out.println("Error SQL: " + e);
        }
        return lista;

    }

    public List<Componente> obtenerTodos() {
        String sentencia = "SELECT marca, modelo, categoria, precio"
                + " FROM componentes;";
        try {

            ResultSet rs = conectar().executeQuery(sentencia);
            while (rs.next()) {
                lista.add((new Componente(rs.getString("marca"),
                        rs.getString("modelo"), rs.getString("categoria"),
                        rs.getFloat("precio"))));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error SQL: " + e);
        }
        return lista;

    }

    public boolean insertar(Componente c) throws SQLException {
        String sentencia = "INSERT INTO componentes"
                + " (marca, modelo, categoria, precio)"
                + " VALUES('" + c.getMarca() + "', '" + c.getModelo() + "', '+"
                + c.getCategoria() + "', " + c.getPrecio() + " );";
        int cantidad = conectar().executeUpdate(sentencia);
        con.close();
        return cantidad != 0;
    }

    public boolean actualizar(Componente c1, Componente c2) throws SQLException {
        String sentencia = "UPDATE componentes"
                + "SET marca = '" + c2.getMarca() + "', modelo = '" + c2.getModelo()
                + "', categoria = '" + c2.getCategoria() + "', precio = " + c2.getClass()
                + " WHERE marca = '" + c1.getMarca() + "' AND modelo = '" + c1.getModelo() + "' ;";
        int cantidad = conectar().executeUpdate(sentencia);
        con.close();
        return cantidad != 0;
    }

}
