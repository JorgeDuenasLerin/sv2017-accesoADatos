package accesoadatos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ListaDeComponentes implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 777L;
    List<Componente> componentes;
    Componente[] componentesArray;
    AccesoADatos acceso;

    public ListaDeComponentes() {
        componentes = new ArrayList<>();

        try {
            acceso = new AccesoADatos();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ListaDeComponentes.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Componente getComponente(int indice) {
        return componentes.get(indice);
    }

    public void setComponente(Componente c1, Componente c2) {
        try {
            acceso.actualizar(c1, c2);
        } catch (SQLException ex) {
            Logger.getLogger(ListaDeComponentes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Componente[] getComponentes() {
        componentes = acceso.obtenerTodos();
        componentesArray = new Componente[componentes.size()];
        for (int i = 0; i < componentes.size(); i++) {
            componentesArray[i] = componentes.get(i);
        }
        return componentesArray;
    }

    public void setComponentes(Componente[] componentes) {
        this.componentes = Arrays.asList(componentes);
    }

    public int getCantidad() {
        return componentes.size();
    }

    public void anyadir(Componente componente) {
        try {
            acceso.insertar(componente);
        } catch (SQLException ex) {
            Logger.getLogger(ListaDeComponentes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ListaDeComponentes buscar(String texto) {
        ListaDeComponentes listaTemp = new ListaDeComponentes();
        for (Componente com : componentes) {
            if (com.coincide(texto)) {
                listaTemp.anyadir(com);
            }
        }
        return listaTemp;
    }

}
