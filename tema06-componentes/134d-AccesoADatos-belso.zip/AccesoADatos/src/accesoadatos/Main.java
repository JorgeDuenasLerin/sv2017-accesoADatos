//Mario Belso
package accesoadatos;

import java.util.Scanner;

public class Main {
    /*
     * 
     * DROP TABLE componentes; CREATE TABLE componentes( marca VARCHAR(25),
     * modelo VARCHAR(60), categoria VARCHAR(30), precio NUMERIC(7,2), PRIMARY
     * KEY(marca, modelo)
     * 
     * );
     * 
     * INSERT INTO componentes(marca, modelo, categoria, precio)
     * VALUES('marca001', 'modelo001', 'categoria001', 25), ('marca002',
     * 'modelo002', 'categoria002', 10), ('marca003', 'modelo003',
     * 'categoria003', 50);
     * 
     * );
     */

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        ListaDeComponentes lista = new ListaDeComponentes();
        mostrarMenu();
        String opc = sc.nextLine();
        switch (opc) {
            case "1":
                System.out.println("Introduzca el texto: ");
                String text = sc.nextLine();

                break;
            case "2":
                for (Componente c : lista.getComponentes()) {
                    System.out.println(c.toString());
                }
                break;
            case "3":
                System.out.println("Introduzca la marca: ");
                String marca = sc.nextLine();
                System.out.println("Introduzca el modelo: ");
                String modelo = sc.nextLine();
                System.out.println("Introduzca la categoria: ");
                String categoria = sc.nextLine();
                System.out.println("Introduzca el precio: ");
                float precio = sc.nextFloat();
                sc.nextLine();
            case "4":
                System.out.println("Introduzca el modelo a actualizar: ");
                String modelo1 = sc.nextLine();
                System.out.println("Introduzca la marca a actualizar: ");
                String marca1 = sc.nextLine();
                System.out.println("Introduzca el nuevo modelo: ");
                String modelo2 = sc.nextLine();
                System.out.println("Introduzca la nueva marca: ");
                String marca2 = sc.nextLine();
                System.out.println("Introduzca la nueva categoria: ");
                String categoria2 = sc.nextLine();
                System.out.println("Introduzca el nuevo precio: ");
                float precio2 = sc.nextFloat();

                lista.setComponente(new Componente(marca1, modelo1, null, 0), new Componente(marca2, modelo2, categoria2, precio2));

                break;

        }

    }

    static void mostrarMenu() {
        System.out.println("1.- Mostrar por texto.");
        System.out.println("2.- Mostrar todos.");
        System.out.println("3.- Añadir componente.");
        System.out.println();
        System.out.println("Introduzca una opcion: ");
    }
}
