package eclipsefx;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListaDeComponentes implements Serializable {

    private List<Componente> componentes;
    private String nombreFichero;

    public ListaDeComponentes() {
        componentes = new ArrayList<>();
        nombreFichero = "fichero.dat";
        if(new File(nombreFichero).exists()) {
            cargar();
        }
    }

    public ListaDeComponentes(String fichero) {
        componentes = new ArrayList<>();
        this.nombreFichero = fichero;
    }

    public void setComponente(int index, Componente componente) {
        componentes.set(index, componente);
        guardar();
    }

    public Componente getComponente(int index) {
        return componentes.get(index);
    }

    public Componente[] getComponentes() {
        Componente[] arrayComponentnes = new Componente[componentes.size()];
        for (int i = 0; i < arrayComponentnes.length; i++) {
            arrayComponentnes[i] = componentes.get(i);
        }
        return arrayComponentnes;
    }

    public void setComponentes(Componente[] arrayComponentnes) {
        componentes = Arrays.asList(arrayComponentnes);
        guardar();
    }

    public void anyadir(Componente componente) {
        componentes.add(componente);
        guardar();
    }

    public int getCantidad() {
        return componentes.size();
    }

    public ListaDeComponentes buscar(String texto) {
        ListaDeComponentes lista = new ListaDeComponentes("tmp.dat");
        for (Componente componente : componentes) {
            if (componente.getMarca().toLowerCase().contains(texto)
                    || componente.getModelo().toLowerCase().contains(texto)
                    || componente.getCategoria().toLowerCase().contains(texto)) {
                lista.anyadir(componente);
            }
        }
        return lista;
    }

    private void cargar() {
        try {
            File fichero = new File(nombreFichero);
            FileInputStream ficheroSalida = new FileInputStream(fichero);
            ObjectInputStream ficheroObjetos = new ObjectInputStream(
                    ficheroSalida);
            Componente[] lista = (Componente[]) ficheroObjetos.readObject();
            setComponentes(lista);
            ficheroObjetos.close();
        } catch (ClassNotFoundException | IOException e) {
            System.err.println("Ha habido un problema con el fichero");
        }
    }

    private void guardar() {
        try {
            File fichero = new File(nombreFichero);
            FileOutputStream ficheroSalida = new FileOutputStream(fichero);
            ObjectOutputStream ficheroObjetos = new ObjectOutputStream(
                    ficheroSalida);

            ficheroObjetos.writeObject(getComponentes());
            ficheroObjetos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String toString() {
        String texto="";
        for (Componente componente : componentes) {
            texto+=componente+"\n";
        }
        return texto;
    }
    
    

}
