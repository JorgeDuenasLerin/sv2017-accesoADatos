package eclipsefx;
import java.io.Serializable;

//Alejandro Gasc�n Mart�
public class Componente implements Serializable {
    private static final long serialVersionUID = 234789L;

    private String marca;
    private String modelo;
    private String categoria;
    private float precio;

    public Componente() {

    }
    
    public Componente(String marca, String modelo, String categoria, float precio) {
        super();
        this.marca = marca;
        this.modelo = modelo;
        this.categoria = categoria;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Marca: "+marca+", Modelo: "+modelo+", Categor�a: "+categoria+", Precio: "+precio;
    }
    
    
    
    

}
