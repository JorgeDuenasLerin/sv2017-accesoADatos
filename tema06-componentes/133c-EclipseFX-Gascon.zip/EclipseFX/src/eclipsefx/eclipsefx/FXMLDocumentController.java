/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eclipsefx;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author usuario
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button button;
    @FXML
    private TextField marcaBox;
    @FXML
    private TextField modeloBox;
    @FXML
    private TextField categoriaBox;
    @FXML
    private TextField precioBox;
    @FXML
    private TableView<Componente> tabla;
    
    private ObservableList<Componente> tablaObservable;
    @FXML
    private TableColumn<Componente, String> marcaCol;
    @FXML
    private TableColumn<Componente, String> modeloCol;
    @FXML
    private TableColumn<Componente, String> categoriaCol;
    @FXML
    private TableColumn<Componente, Float> precioCol;
    
    ListaDeComponentes listaComponentes;
    @FXML
    private TextField buscarBox;
    @FXML
    private Button buscarButton;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
        String marca=marcaBox.getText();
        String modelo=modeloBox.getText();
        String categoria=categoriaBox.getText();
        float precio=Float.parseFloat(precioBox.getText());
        
        Componente componente= new Componente(marca,modelo,categoria,precio);
        listaComponentes.anyadir(componente);
        
        tabla.setItems(FXCollections.observableArrayList(listaComponentes.getComponentes()));
    }
    
    private void inicializarTabla() {

        
        tablaObservable = FXCollections.observableArrayList(listaComponentes.getComponentes());
        marcaCol.setCellValueFactory(new PropertyValueFactory<>("marca"));
        modeloCol.setCellValueFactory(new PropertyValueFactory<>("modelo"));
        categoriaCol.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        precioCol.setCellValueFactory(new PropertyValueFactory<>("precio"));
        
        tabla.setItems(tablaObservable);

        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listaComponentes=new ListaDeComponentes();
        inicializarTabla();
    }    

    @FXML
    private void buscar(ActionEvent event) {
        tabla.setItems(FXCollections.observableArrayList(
                listaComponentes.buscar(buscarBox.getText()).getComponentes()));
    }
    
}
