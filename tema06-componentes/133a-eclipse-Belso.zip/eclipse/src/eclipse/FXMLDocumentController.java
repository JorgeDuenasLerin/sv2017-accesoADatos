/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eclipse;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 *
 * @author usuario
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField marcaText;
    @FXML
    private TextField modeloText;
    @FXML
    private TextField precioText;
    @FXML
    private TextField categoriaText;
    @FXML
    private ListView<?> listaComps;
    @FXML
    private TextField filtroTexdt;
    
    Serializador ser;
    ListaDeComponentes listaComponentes;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    private void cargarComponentes() {
        ser = new Serializador();
        listaComponentes = new ListaDeComponentes("ListaComps.dat");
        try {
            listaComponentes.setComponentes(ser.cargar());
        } catch (FileNotFoundException e) {

            e.printStackTrace();    
        } catch (ClassNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
        System.out.println("cant: "+listaComponentes.getCantidad());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void anyadirComponente(ActionEvent event) {
    }

    @FXML
    private void filtrar(ActionEvent event) {
    }
    
}
