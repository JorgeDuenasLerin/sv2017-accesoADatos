/*
 * Abilio Reig Sancho
 * Carla Liarte
 */
package controlstocks;

import java.util.Scanner;

public class ControlStocks {

    
    static void mostrarMenu() {
        System.out.println("1. Añadir producto");
        System.out.println("2. Listar producto por parte del nombre");
        System.out.println("0. Salir");
    }
    
    

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String opcion, nombre;
        float precioCompra, precioVenta;
        int stock;
        
        Almacen a = new Almacen("productos.dat");
        int referencia = a.ref();

        do {
            mostrarMenu();
            opcion = sc.nextLine();
            switch (opcion) {
                case "1":
                    System.out.println("Introduce el nombre: ");
                    nombre = sc.nextLine();
                    System.out.println("Introduce el precio de compra: ");
                    precioCompra = sc.nextFloat();
                    sc.nextLine();
                    System.out.println("Introduce el precio de venta: ");
                    precioVenta = sc.nextFloat();
                    sc.nextLine();
                    System.out.println("Introduce el stock de este producto: ");
                    stock = sc.nextInt();
                    sc.nextLine();
                    Producto p = new Producto(referencia, nombre, precioCompra,
                            precioVenta, stock);
                    a.add(p);
                    a.guardarProducto();
                    referencia++;
                    break;
                case "2":
                    a.listar();
                    System.out.println();
                    break;
                case "0":
                    break;
                default:
                    System.out.println("Opción incorrecta");
                    break;
            }
        } while (!opcion.equals("0"));
    }

}
