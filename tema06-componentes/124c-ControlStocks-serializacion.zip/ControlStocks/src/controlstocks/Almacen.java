/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlstocks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Almacen implements Serializable {

    private String nombreFichero;
    public ArrayList<Producto> inventario;
    private Scanner sc = new Scanner(System.in);

    //Si no existe el fichero, se inicia arraylist vacío
    //Si existe, se carga mediante readOject a arraylist.
    public Almacen(String nombreFichero) {
        this.nombreFichero = nombreFichero;
        if (!new File(nombreFichero).exists()) {
            inventario = new ArrayList<>();
        } else {
            FileInputStream fs;
            ObjectInputStream is;
            try {
                fs = new FileInputStream(nombreFichero);
                is = new ObjectInputStream(fs);
                inventario = (ArrayList<Producto>) is.readObject();
            } catch (IOException e) {
                e.getMessage();
            } catch (ClassNotFoundException e) {
                e.getMessage();
            }
        }
    }

    public Almacen() {
    }

    public void guardarProducto() {
        try {
            FileOutputStream fs = new FileOutputStream(nombreFichero);
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(inventario);
            fs.close();
            os.close();

        } catch (IOException e) {
            e.getMessage();
        }
    }

    public void add(Producto p) {
        inventario.add(p);
    }

    public void listar() {
        if (inventario.isEmpty()) {
            System.out.println("Inventario vacío");
        } else {
            System.out.println("Lista de productos: ");
            for (Producto p : inventario) {
                int i = 1;
                System.out.println(i + " ~ " + p.toString());
                i++;
            }
        }
    }
    public int ref() {
        int ref = 1;
        if (inventario.isEmpty()) {
            return 1;
        } else {
            
            for (Producto p : inventario) {
                ref++;
            }
        }
        return ref;
    }
}
