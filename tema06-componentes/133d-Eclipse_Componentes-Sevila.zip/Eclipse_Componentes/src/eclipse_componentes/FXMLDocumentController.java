//Antonio Sevila
package eclipse_componentes;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author antonio
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField marcaField;
    @FXML
    private TextField precioField;
    @FXML
    private TextField buscarField;
    @FXML
    private ListView<Componente> componentesListView;
    @FXML
    private TextField categoriaField;
    @FXML
    private TextField modeloField;
    
    ObservableList<Componente> componentesActuales;
    ListaDeComponentes listaComponentes;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listaComponentes = new ListaDeComponentes();
    }    

    @FXML
    private void anyadir(ActionEvent event) {
        Componente componente = new Componente(marcaField.getText(),
                modeloField.getText(), categoriaField.getText(),
                Double.valueOf(precioField.getText()));
        listaComponentes.anyadir(componente);
        marcaField.setText("");
        modeloField.setText("");
        categoriaField.setText("");
        precioField.setText("");
    }

    @FXML
    private void buscar(ActionEvent event) {
        if( ! buscarField.getText().isEmpty()){
            componentesActuales = FXCollections.observableArrayList(
                    listaComponentes.buscar(buscarField.getText())
                    .getComponentes());
            componentesListView.setItems(componentesActuales);
        }
    }

    @FXML
    private void salir(ActionEvent event) {
        ((Stage)buscarField.getScene().getWindow()).close();
    }
    
}
