/*
  ANTONIO DEFEZ INAÑEZ
 *SERGIO GARCIA BALSAS 
   numero de versión: v.0
Programa que se conecta a una base de datos Mongo DB para el control de Stocks
 */
package ejercicioparejas;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.IndexOptions;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class EjercicioParejas
{

    public static void menu()
    {
        System.out.println("1. Añadir");
        System.out.println("2. Buscar por parte del nombre");
        System.out.println("0. Salir");
    }

    public static void anyadirProducto(MongoCollection<Document> collection,
            Scanner sc)
    {
        System.out.println("Indique la referencia del producto");
        int ref = Integer.parseInt(sc.nextLine());
        System.out.println("Indique el nombre del producto");
        String nombre = sc.nextLine();
        System.out.println("Indique el precio de compra");
        Double precioCompra = Double.parseDouble(sc.nextLine());
        System.out.println("Indique el precio de venta");
        Double precioVenta = Double.parseDouble(sc.nextLine());
        System.out.println("Stock?");
        int stock = Integer.parseInt(sc.nextLine());

        Document producto = new Document();

        producto.append("referencia", ref);
        producto.append("nombre", nombre);
        producto.append("precioCompra", precioCompra);
        producto.append("precioVenta", precioVenta);
        producto.append("stock", stock);
        try
        {
            collection.insertOne(producto);
            System.out.println("Inserción exitosa");
        } catch (Exception e)
        {
            System.err.println("No se ha podido añadir " + e.getMessage());
        }

    }

    public static void buscar(MongoCollection<Document> collection,
            Scanner sc)
    {
        System.out.println("Nombre del producto?");
        String nombre = sc.nextLine();
        for (Document document : collection.find(Filters.regex("nombre", nombre)))
        {
            //System.out.println(document.toJson());
            System.out.println("Nombre: " + document.getString("nombre"));
            System.out.println("Precio compra: " + document.getDouble("precioCompra"));
            System.out.println("Precio venta: " + document.getDouble("precioVenta"));
            System.out.println("Stock: " + document.getInteger("stock"));
        }
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.SEVERE);
        MongoClient mongo = new MongoClient();
        MongoDatabase database = mongo.getDatabase("Stock");
        MongoCollection<Document> collection
                = database.getCollection("productos");
        collection.createIndex(new BasicDBObject("referencia", 1),
                new IndexOptions().unique(true));
        boolean salir = false;

        do
        {
            menu();
            String opcion = sc.nextLine();
            switch (opcion)
            {
                case "1":
                    anyadirProducto(collection, sc);
                    break;
                case "2":
                     buscar(collection, sc);
                    break;
                case "0":
                    salir = true;
                    break;
            }
        } while (!salir);
    }
}
