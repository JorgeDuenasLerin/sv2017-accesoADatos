
package db4repaso;

import java.util.Objects;

public class Producto {
    String referencia;
    String nombre;
    double prec_Compra;
    double prec_Venta;
    int stock=0;

    public Producto(String referencia, String nombre, double prec_Compra, double prec_Venta, int stock) {
        this.referencia = referencia;
        this.nombre = nombre;
        this.prec_Compra = prec_Compra;
        this.prec_Venta = prec_Venta;
        this.stock = stock;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getPrec_Compra() {
        return prec_Compra;
    }

    public void setPrec_Compra(double prec_Compra) {
        this.prec_Compra = prec_Compra;
    }

    public double getPrec_Venta() {
        return prec_Venta;
    }

    public void setPrec_Venta(double prec_Venta) {
        this.prec_Venta = prec_Venta;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object otro) {
        if (otro.equals(this)) {
            return true;
        }
        if (!(otro instanceof Producto)) {
            return false;
        }
        Producto other = (Producto) otro;
        return (this.referencia.equals(other.referencia) 
                && this.nombre.equals(other.nombre));
    }

    @Override
    public String toString() {
        return "Producto{" 
                + "referencia=" + referencia 
                + ", nombre=" + nombre 
                + ", prec_Compra=" + prec_Compra 
                + ", prec_Venta=" + prec_Venta 
                + ", stock=" + stock 
                + '}';
    }
    
    
    
}
