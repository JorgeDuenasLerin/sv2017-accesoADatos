/*Azahara Carbonell Mateo
Alexandra Sanchez Alonso*/
package db4repaso;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import java.util.List;
import java.util.Scanner;

public class Db4repaso {

    public static void main(String[] args) {
        ObjectContainer db = null;
        Scanner sc = new Scanner(System.in);

        String opcion = "";
        do {
            System.out.println("      MENU");
            System.out.println("1.Listar stock: ");
            System.out.println("2.Insertar producto :");
            System.out.println("3.Buscar producto: ");
            System.out.println("0. Salir");
            opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    //listar();
                    break;
                case "2":
                    System.out.println("Referencia:");
                    String ref = sc.nextLine();
                    System.out.println("Nombre:");
                    String nombre = sc.nextLine();
                    System.out.println("Precio de compra:");
                    double precioC = sc.nextDouble();
                    sc.nextLine();
                    System.out.println("Precio de venta:");
                    double precioV = sc.nextDouble();
                    sc.nextLine();
                    System.out.println("Cantidad:");
                    int stock = sc.nextInt();
                    sc.nextLine();
                    Producto p = new Producto(ref, nombre, precioC, precioV, stock);
                    Guardar(db, p);

                    break;
                case "3":
                    System.out.println("Nombre o parte del nombre:");
                    nombre = sc.nextLine();
                    CargarParcial(db, nombre);
                    break;
                case "0":
                    System.out.println("Adios");
                    break;

            }
        } while (!opcion.equals("0"));

    }

    static void Guardar(ObjectContainer db, Producto p) {
        try {
            db = Db4o.openFile("almacen.dat");
            Producto p2 = new Producto(p.getReferencia(), p.getNombre(), p.getPrec_Compra(), p.getPrec_Venta(), p.getStock());
            if (db.get(p2).hasNext() == false) {
                db.set(p2);
                db.commit();
            } else {
                System.out.println("Ese producto ya existe");
            }
        } finally {
            if (db != null) {
                System.out.println("producto guardado");
                db.close();
            }
        }
    }

    //hecho
    static void CargarParcial(ObjectContainer db, String nombreProducto) {

        try {
            db = Db4o.openFile("almacen.dat");

            List<Producto> productos = db.query(new Predicate<Producto>() {
                public boolean match(Producto candidato) {
                    return candidato.getNombre().contains(nombreProducto);
                }
            });
            for (Producto busqueda : productos) {
                System.out.println("Encontrado: " + busqueda.toString());
            }
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

}
