package Componentes;

import java.util.Scanner;
import java.sql.*;
//Antonio Sevila
public class ComponenteMain {

    
    public static void main(String[] args) {
        Menu men = new Menu();
        men.Run(); 
    }
 
}
