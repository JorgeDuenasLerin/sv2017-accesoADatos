package Componentes;

import java.util.ArrayList;
import java.util.Scanner;
//Antonio Sevila
public class Menu
    {
     
        public Menu() {
          
        }
        
        public void Run()
        {
            boolean salida = false;
            Scanner entrada = new Scanner(System.in);
            ListaDeComponentes milista = new ListaDeComponentes();
            do {
                mostrarMenu();
                String opcion = entrada.nextLine();
                switch (opcion) {
                    case "1":
                        anyadirComponente(entrada,milista);
                        break;
                    case "2":
                        buscarComponente(entrada,milista);
                        break;
                    case "3":
                        obtenerTodosComponente(milista);
                        break;
                    case "4":
                        buscarComponenteConcreto(entrada,milista);
                        break;
                    case "5":
                        eliminarComponente(entrada,milista);
                        break;
                    case "6":
                        actualizarComponente(entrada,milista);
                        break;
                    case "7":
                        insertaVariosComponentes(entrada,milista);
                        break;   
                        
                        
                    case "0":
                        salida = true;
                        break;
                }
            } while (!salida);
            System.out.println("Fin de ejecucion");
        }
        
        private void insertaVariosComponentes(Scanner entrada,
                ListaDeComponentes milista) {
           boolean anyadirOtro=true;
            ArrayList<Componente> misComponentes= new ArrayList<>();
           do
           {
               misComponentes.add(crearComponente(entrada));
               System.out.println("Quieres introducir otro(S/N) ?");
               String resp = entrada.nextLine();
               if(!resp.equals("S"))
                   anyadirOtro=false;
           }
           while(anyadirOtro);
           
           int total = milista.insertar(misComponentes);
           System.out.println("Se ha introducido "+total +" Componentes");
           
        }

        private Componente actualizarComponente(Componente original,Scanner entrada)
        {
            Componente nuevo = new Componente(original);
            System.out.println("Mostrando  valores componente");
            System.out.println(original);
            System.out.println("Si quieres dejar el campo igual "
                    + "dejalo vacio");
            //actualizando campos
            System.out.print("Modelo:");
            String modelo = entrada.nextLine();
            if(!modelo.equals(""))
                nuevo.setModelo(modelo);
            System.out.print("Marca:");
            String marca = entrada.nextLine();
            if(!marca.equals(""))
                nuevo.setMarca(marca);
            System.out.print("Categoria:");
            String categoria = entrada.nextLine();
            if(!categoria.equals(""))
                nuevo.setCategoria(categoria);
            System.out.print("precio:");
            String precio_tem =entrada.nextLine();
            if(!precio_tem.equals(""))
                nuevo.setPrecio(Float.parseFloat(precio_tem));
            
            return nuevo;
        }
        
        
    
        private void actualizarComponente(Scanner entrada, ListaDeComponentes milista) {
           System.out.println("Introduce el modelo del componente");
           String modelo = entrada.nextLine();
           System.out.println("Introduce la marca del modelo");
           String marca = entrada.nextLine();
           Componente tmp_original = milista.getComponente(modelo, marca);
           if(tmp_original ==null)
           {
               System.out.println("No se ha encontrado el componente");
           }
           else
           {
               Componente tmp_modificado = actualizarComponente(tmp_original,entrada);
               if(milista.actualizarComponente(tmp_original, tmp_modificado))
                   System.out.println("Se ha llevado a cabo la actualizacion");
               else
                   System.out.println("No ha sido posible la actualizacion");
               
           }
        }

        private void eliminarComponente(Scanner entrada,
                ListaDeComponentes milista) {
            System.out.println("Introduce marca del componente");
            String marca = entrada.nextLine();
            System.out.println("Introduce modelo del componente");
            String modelo = entrada.nextLine();
            if(milista.borradoComponente(marca, modelo))
            {
              System.out.println("Se ha borrado correctamente ");  
            }
            else
            {
                System.out.println("No se ha borrado correctamente");
            }
            
        }

        private void buscarComponenteConcreto(
                Scanner entrada, ListaDeComponentes milista) {
           String marca,modelo;
           System.out.println("Introduce la marca del componente");
           marca = entrada.nextLine();
           System.out.println("Introduce el modelo del componente");
           modelo = entrada.nextLine();
           Componente temp = milista.getComponente(modelo, marca);
           if(temp == null)
           {
               System.out.println("No se encontro el componente");
           }
           else
           {
               System.out.println(temp);
           }
        }

        private  void buscarComponente(Scanner entrada,
                ListaDeComponentes milista) {
            
            System.out.println("Introduzca campo de interes");
            String campo = entrada.nextLine();
            ListaDeComponentes tmp = milista.findComponente(campo);       
            Componente[] temp2 =tmp.getComponentes();

            for(int i=0 ;i<temp2.length;i++)
            {
                System.out.println(temp2[i]);
            }
            
        }
        
        private void obtenerTodosComponente(ListaDeComponentes milista)
        {
            ListaDeComponentes tmp = milista.AllComponente();       
            Componente[] temp2 =tmp.getComponentes();
            for(int i=0 ;i<temp2.length;i++)
            {
                System.out.println(temp2[i]);
            }
        }
        
        

        private  Componente crearComponente(Scanner entrada) {
            String marca;
            String modelo;
            String categoria;
            float precio;
            System.out.println("Introduzca la marca");
            marca = entrada.nextLine();
            System.out.println("Introduzca el modelo");
            modelo = entrada.nextLine();
            System.out.println("Introduzca al categoria");
            categoria = entrada.nextLine();
            System.out.println("Introduzca precio");
            precio = Float.valueOf(entrada.nextLine());
            return new Componente(marca,modelo,categoria,precio);
        }

        private  void anyadirComponente(Scanner entrada,
                ListaDeComponentes milista) {
            int tmp = milista.anyadir(crearComponente(entrada));
            if(tmp ==0)
            {
              System.out.println("No se ha consegido introducir el elemento");  
            }
            else
            {
                System.out.println("Insercion correcta");
            }
        }

        private  void mostrarMenu() {
           System.out.println("1. A�adir 1 nuevo componente");
           System.out.println("2. Buscar componente");
           System.out.println("3. Obtener todos");
           System.out.println("4. Obtener componente");
           System.out.println("5. Eliminar componente");
           System.out.println("6. Actualizar componente");
           System.out.println("7. Introducir varios componentes");
           System.out.println("0. Salir");
        }
    }