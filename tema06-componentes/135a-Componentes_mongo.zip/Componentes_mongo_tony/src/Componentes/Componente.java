package Componentes;
import java.io.Serializable;

//Antonio Sevila
public class Componente implements Serializable {

    private static final long serialVersionUID = 1123123L;
    private String marca;
    private String modelo;
    private String categoria;
    private float precio;
    
    public Componente() {
        
    }

    /*Constructor copia*/
    public Componente(Componente tmp)
    {
        this.marca=tmp.marca;
        this.modelo=tmp.modelo;
        this.categoria=tmp.categoria;
        this.precio =tmp.precio;
    }
    
    public Componente(String marca, String modelo, String categoria,
            float precio) {
       
        this.marca = marca;
        this.modelo = modelo;
        this.categoria = categoria;
        this.precio = precio;
    }


    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }
    
    
    public boolean Contiene(String buscado)
    {
        if(this.categoria.contains(buscado))
            return true;
        else if(this.marca.contains(buscado))
            return true;
        else if(this.modelo.contains(buscado))
            return true;
        else
            return false;
        
    }


    @Override
    public String toString() {
        return "Componente [marca=" + marca + ", modelo=" + modelo
                + ", categoria=" + categoria + ", precio=" + precio
                + "]";
    }
    
    
    
}