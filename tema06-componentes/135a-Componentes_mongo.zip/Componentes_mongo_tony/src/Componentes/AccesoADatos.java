package Componentes;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoCommandException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;

//Antonio Sevila
/*
 * use componentes_db;
 * db.componentes.save({marca: "marca1", modelo: "modelo1", categoria: "categoria1", precio: 1});
 */
public class AccesoADatos {

    private Statement statement;
    MongoClient cliente;
    MongoDatabase db;
    MongoCollection<Document> collection;

    public AccesoADatos() {
        
    }

    private void conectarBaseDatos() {
        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.SEVERE);
        try {
            cliente = new MongoClient();
            db = cliente.getDatabase("componentes_db");
            collection = db.getCollection("componentes");
        } catch (MongoCommandException e) {
        }
    }

    private void cerrarBaseDatos() {
        cliente.close();
    }
    private float doubleToFloat(double num) {
        return (float)num;
    }

    public ArrayList<Componente> obtenerPorTexto(String texto) {
        conectarBaseDatos();
        ArrayList<Componente> listaComponentes = new ArrayList<>();
        for (Document doc : collection.find(Filters.or(
                Filters.regex("marca", texto),Filters.regex("modelo", texto),
                Filters.regex("descripcion", texto)))) {
            float precio2 = doubleToFloat(doc.getDouble("precio"));
            listaComponentes.add(new Componente(doc.getString("marca"),
                    doc.getString("modelo"),doc.getString("categoria"),
                    precio2));
        }
        cliente.close();
        return listaComponentes;
    }

    public int Insertar(Componente c) {
        conectarBaseDatos();
        collection.insertOne(new Document()
                .append("marca", c.getMarca())
                .append("modelo", c.getModelo())
                .append("categoria", c.getCategoria())
                .append("precio", c.getPrecio()));
        cliente.close();
        //TO DO find the amount of inserted values.
        return 1;
    }

    public Componente obtenerComponente(String marca1, String modelo1) {
        conectarBaseDatos();
        Componente comp = null; 
        for (Document doc : collection.find(Filters.and(
                Filters.eq("marca", marca1),Filters.eq("modelo", modelo1)))){
            float precio2 = doubleToFloat(doc.getDouble("precio"));
            comp = new Componente(doc.getString("marca"),
                    doc.getString("modelo"),doc.getString("categoria"),
                    precio2);
        }
        cliente.close();
        return comp;
    }

    public ArrayList<Componente> obtenerTodo() {
        conectarBaseDatos();
        ArrayList<Componente> listaComponentes = new ArrayList<>();
        for (Document doc : collection.find()) {
            float precio2 = doubleToFloat(doc.getDouble("precio"));
            listaComponentes.add(new Componente(doc.getString("marca"),
                    doc.getString("modelo"),doc.getString("categoria"),
                    precio2));
        }
        cliente.close();
        return listaComponentes;
    }

    public int borrarComponente(Componente c) {
        conectarBaseDatos();
        collection.deleteOne(Filters.and(
                Filters.eq("marca", c.getMarca()),
                Filters.eq("modelo", c.getModelo())));
        cliente.close();
        //TO DO find the amount of inserted values.
        
        return 1;
    }

    public int upadateComponente(Componente c1, Componente c2) {
        conectarBaseDatos();
        collection.updateOne(new Document()
                .append("marca", c1.getMarca())
                .append("modelo", c1.getModelo()),
                Updates.combine(
                        Updates.set("marca", c2.getMarca()),
                        Updates.set("modelo", c2.getModelo()),
                        Updates.set("categoria", c2.getCategoria()),
                        Updates.set("precio", c2.getPrecio())));
        cliente.close();
        return 0;
    }

    public int Insertar(ArrayList<Componente> c) {
        conectarBaseDatos();
        for(Componente comp : c) {
            collection.insertOne(new Document()
                .append("marca", comp.getMarca())
                .append("modelo", comp.getModelo())
                .append("categoria", comp.getCategoria())
                .append("precio", comp.getPrecio()));
        }
        cliente.close();
        //TO DO find the amount of inserted values
        return 1;
    }

}
