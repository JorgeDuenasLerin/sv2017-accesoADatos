//Antonio Sevila
//Control de stocks
package controlstocks_fichero_texto;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author antonio
 */
public class ControlStocks_fichero_texto {

    public static void mostrarPorNombre(String nombreBuscar) {
        try {
            BufferedReader ficheroLectura = new BufferedReader(
                    new FileReader(new File("Inventario.txt")));
            
            String linea = ficheroLectura.readLine();
            while (linea != null) {
                if(linea.contains(nombreBuscar)){
                    System.out.println(linea.replace(",", ", "));
                }
                linea = ficheroLectura.readLine();
            }
            ficheroLectura.close();
            
        } catch (IOException errorDeFichero) {
            System.out.println(
                    "Ha habido problemas: "
                    + errorDeFichero.getMessage());
        }

    }

    public static void anyadirStock(Scanner teclado) {
        System.out.println("Introduce la referencia del producto");
        int referencia = teclado.nextInt();
        teclado.nextLine();
        System.out.println("Introduce el nombre del producto");
        String nombre = teclado.nextLine();
        System.out.println("Introduce el precio de compra");
        double precioCompra = teclado.nextDouble();
        teclado.nextLine();
        System.out.println("Introduce el precio de venta");
        double precioVenta = teclado.nextDouble();
        teclado.nextLine();
        System.out.println("Introduce stock");
        String stock = teclado.nextLine();
        try {
            PrintWriter fichero = new PrintWriter(
                    new BufferedWriter(new FileWriter("Inventario.txt", true)));
            fichero.print("Referencia: " + referencia + ",");
            fichero.print("Nombre: " + nombre + ",");
            fichero.print("Precio de compra: " + precioCompra + ",");
            fichero.print("Precio de venta: " + precioVenta + ",");
            fichero.println("Stock: " + stock);
            System.out.println("Producto añadido al inventario");
            fichero.close();
        } catch (FileNotFoundException e) {
            System.out.println("Ha habido problemas: " + e.getMessage());
        } catch (IOException ex) {
            System.out.println("Ha habido problemas: " + ex.getMessage());
        }
    }

    public static void mostrarMenu() {
        System.out.println("1. Introducir stock");
        System.out.println("2. Buscar por nombre");
        System.out.println("S. Salir");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String opcion = null;
        do {
            mostrarMenu();
            opcion = teclado.nextLine();
            switch (opcion) {
                case "1":
                    anyadirStock(teclado);
                    break;
                case "2":
                    if ((new File("Inventario.txt").exists())) {
                        System.out.println("Introduce el trozo de nombre "
                                + "por el que buscar:");
                        String nombreBuscar = teclado.nextLine();
                        
                        mostrarPorNombre(nombreBuscar);
                    } else {
                        System.out.println("No hay ningún producto "
                                + "en el inventario");
                    }
                    break;
                case "s":
                case "S":
                    System.out.println("Adios!");
                    opcion = opcion.toUpperCase();
                    break;
            }
        } while (!opcion.equals("S"));
    }
}
