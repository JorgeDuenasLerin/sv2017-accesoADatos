//Antonio sevila
package Componentes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class ListaDeComponentes implements Serializable {

    private static final long serialVersionUID = 141235L;
    private ArrayList<Componente> listaComponentes;
    private boolean temporal;
    private AccesoADatos datos;

    public ListaDeComponentes() {
        listaComponentes = new ArrayList<>();
        datos = new AccesoADatos();
    }

    public ListaDeComponentes(boolean temporal) {
        listaComponentes = new ArrayList<>();
        this.temporal = temporal;
    }

    public void anyadir(Componente componente) {
        listaComponentes.add(componente);
    }

    public int getCantidad() {
        return listaComponentes.size();
    }

    public Componente getComponente(int index) {
        return listaComponentes.get(index);
    }

    public Componente[] getComponentes() {
        Componente[] componentesArray = new Componente[listaComponentes
                .size()];
        for (int i = 0; i < listaComponentes.size(); i++) {
            componentesArray[i] = listaComponentes.get(i);
        }
        return componentesArray;
    }

    public void setComponente(int index, Componente componente) {
        listaComponentes.set(index, componente);
    }

    public void setComponentes(Componente[] newArray) {
        listaComponentes = new ArrayList<>();
        for (Componente componente : newArray) {
            listaComponentes.add(componente);
        }
    }
    
    public ListaDeComponentes buscar(String texto) {
        ListaDeComponentes listaTmp = datos.obtenerPorTexto(texto);
        return listaTmp;
    }

    /*private void cargar() {
        try {
            File fichero = new File(nombreFichero);
            FileInputStream ficheroSalida = new FileInputStream(fichero);
            ObjectInputStream ficheroObjetos = new ObjectInputStream(
                    ficheroSalida);
            Componente[] lista = (Componente[]) ficheroObjetos
                    .readObject();
            setComponentes(lista);
            ficheroObjetos.close();
        } catch (ClassNotFoundException | IOException e) {
            System.err.println("Ha habido un problema con el fichero");
        }
    }

    private void guardar() {
        try {
            File fichero = new File(nombreFichero);
            FileOutputStream ficheroSalida = new FileOutputStream(fichero);
            ObjectOutputStream ficheroObjetos = new ObjectOutputStream(
                    ficheroSalida);

            ficheroObjetos.writeObject(getComponentes());
            ficheroObjetos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}
