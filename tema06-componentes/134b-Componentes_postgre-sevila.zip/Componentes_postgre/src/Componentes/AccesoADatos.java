//Antonio Sevila
package Componentes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccesoADatos {

    private Connection connection;
    public AccesoADatos() {
        
    }
    
    public boolean borrar(Componente c) {
        boolean borrado = false;
        conectarBD();
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "DELETE FROM componente WHERE"
                    + " marca = '" + c.getMarca() + "'"
                    + " AND modelo = '" + c.getModelo() + "'";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            borrado = cantidad==1?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        return borrado;
    }
    
    public boolean actualizar(Componente origen, Componente nuevoValor) {
        boolean actualizado = false;
        conectarBD();
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "UPDATE componente SET"
                    + " marca = '" + nuevoValor.getMarca() + "'"
                    + ", modelo = '" + nuevoValor.getModelo()
                    + "', categoria = '" + nuevoValor.getCategoria() + "'"
                    + ", precio = " + nuevoValor.getPrecio()
                    + " WHERE marca = '" + origen.getMarca() + "'"
                    + " AND modelo = '" + origen.getModelo() + "'";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            actualizado = cantidad==1?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        return actualizado;
    }
    
    public ListaDeComponentes obtenerTodos() {
        conectarBD();
        ListaDeComponentes listaComponentes = new ListaDeComponentes(true);
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "SELECT * FROM componente";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            while (rs.next()) {
                Componente comp = new Componente(rs.getString("marca"),
                        rs.getString("modelo"), rs.getString("categoria"),
                        rs.getDouble("precio"));
                listaComponentes.anyadir(comp);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        
        return listaComponentes;
    }
    
    public Componente obtener(String marca, String modelo) {
        conectarBD();
        Componente componente = null;
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "SELECT * FROM componente WHERE"
                    + " marca = '" + marca + "' AND modelo = '"
                    + modelo + "'";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            if(rs.next()) {
                componente = new Componente(marca, modelo,
                        rs.getString("categoria"), rs.getDouble("precio"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        
        return componente;
    }
    
    public ListaDeComponentes obtenerPorTexto(String texto) {
        conectarBD();
        ListaDeComponentes listaComponentes = new ListaDeComponentes(true);
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "SELECT * FROM componente WHERE"
                    + " marca LIKE '%" + texto + "%' OR modelo LIKE '%"
                    + texto + "%' OR categoria LIKE '%" + texto + "%'";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            while (rs.next()) {
                Componente comp = new Componente(rs.getString("marca"),
                        rs.getString("modelo"), rs.getString("categoria"),
                        rs.getDouble("precio"));
                listaComponentes.anyadir(comp);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        
        return listaComponentes;
    }
    
    public boolean insertar(Componente c) {
        boolean insertado = false;
        conectarBD();
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "INSERT INTO componente VALUES ('"
                    + c.getMarca() + "', '" + c.getModelo() + "', '"
                    + c.getCategoria() + "', " + c.getPrecio() + ");";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            insertado = cantidad==1?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        return insertado;
    }
    
    public int insertar(ListaDeComponentes lc) {
        boolean insertado = false;
        conectarBD();
        int cont = 0;
        Statement statement;
        try {
            statement = connection.createStatement();
            for(Componente c : lc.getComponentes()) {
                String sentenciaSQL = "INSERT INTO componente VALUES ('"
                        + c.getMarca() + "', '" + c.getModelo() + "', '"
                        + c.getCategoria() + "', " + c.getPrecio() + ");";
                int cantidad = statement.executeUpdate(sentenciaSQL);
                insertado = cantidad==1?true:false;
                if(insertado) {
                    cont++;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        return cont;
    }
    
    private void conectarBD() {
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/Componentes";
            String usr = "postgres";
            String pass = "postgre2017";
            connection = DriverManager.getConnection(url, usr, pass);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void cerrarBD() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
