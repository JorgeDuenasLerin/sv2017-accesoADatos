//Antonio Sevila
package Componentes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccesoADatos {

    private Connection connection;
    public AccesoADatos() {
        
    }
    public ListaDeComponentes obtenerPorTexto(String texto) {
        conectarBD();
        ListaDeComponentes listaComponentes = new ListaDeComponentes();
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "SELECT * FROM componente WHERE"
                    + " marca LIKE '%" + texto + "%' OR modelo LIKE '%"
                    + texto + "%' OR categoria LIKE '%" + texto + "%'";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            while (rs.next()) {
                Componente comp = new Componente(rs.getString("marca"),
                        rs.getString("modelo"), rs.getString("categoria"),
                        rs.getDouble("precio"));
                listaComponentes.anyadir(comp);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        cerrarBD();
        
        return listaComponentes;
    }
    public boolean insertar(Componente c) {
        boolean insertado = false;
        conectarBD();
        
        Statement statement;
        try {
            statement = connection.createStatement();
            String sentenciaSQL = "INSERT INTO componente VALUES ('"
                    + c.getMarca() + "', '" + c.getModelo() + "', '"
                    + c.getCategoria() + "', " + c.getPrecio() + ");";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            insertado = cantidad==1?true:false;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

        cerrarBD();
        return insertado;
    }
    
    private void conectarBD() {
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/Componentes";
            String usr = "postgres";
            String pass = "postgre2017";
            connection = DriverManager.getConnection(url, usr, pass);
        } catch (ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    private void cerrarBD() {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error cerrando la conexi�n...");
        }
    }
}
