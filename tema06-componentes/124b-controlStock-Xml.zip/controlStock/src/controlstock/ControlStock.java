// Roberto Garcia Marcos
// Javier Montejo Lorente

package controlstock;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class ControlStock {
    public static void main(String[] args) throws FileNotFoundException {
        mostrarCabecera();
        boolean exit = false;
        Scanner sc = new Scanner(System.in);
        String opcion = "";
        PrintWriter fichero = new PrintWriter ("stock.xml");
        fichero.println("<stock>");
        
        do{
            mostrarMenu();
            System.out.println("Introduce opcion: ");
            opcion = sc.nextLine();
            
            switch(opcion){
                case "1":
                    anyadirElemento(sc);
                    break;
                case "2":
                    leerElementos();
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    System.out.println("Acho tio, Opcion incorrecta :o");
                    break;
            }
        }
        while(!exit);
        fichero.println("</stock>");
        fichero.close();
        
    }
    
    public static void anyadirElemento(Scanner sc){
        System.out.println("Referencia: ");
        String referencia = sc.nextLine();
        System.out.println("Nombre: ");
        String nombre = sc.nextLine();
        System.out.println("Precio de compra: ");
        String precioCompra = sc.nextLine();
        System.out.println("Precio de venta: ");
        String precioVenta = sc.nextLine();
        System.out.println("Stock: ");
        String stock = sc.nextLine();
        
        try{
            PrintWriter fichero = new PrintWriter ("stock.xml");
            fichero.println("<articulo>"
                + "<ref>" + referencia + "</ref>"
                + "<nombre>" + nombre + "</nombre>"
                + "<precioCompra>" + precioCompra + "</precioCompra>"
                + "<precioVenta>" + precioVenta + "</precioVenta>"
                + "<stock>" + stock + "</stock>"
                + "</articulo>");
        fichero.close();
        }
        catch(FileNotFoundException e){
            System.out.println("ERROR. Fichero no encontrado.");
        }
        
    }
    
    public static void leerElementos(){
        try {
            File inputFile = new File("stock.xml");
            DocumentBuilderFactory dbFactory 
                = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            
            System.out.println("Elemento base : " 
                + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("producto");
            System.out.println();
            
            System.out.println("Recorriendo productos..."); 
            
            for (int temp = 0; temp < nList.getLength(); temp++) {
                
                Node nNode = nList.item(temp);
                
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    
                    Element eElement = (Element) nNode;
                    System.out.println("Referencia: " 
                        + eElement.getAttribute("referencia"));
                    System.out.println("Nombre: " 
                        + eElement.getAttribute("nombre"));
                        
                    System.out.println("Precio compra: " 
                        +eElement.getAttribute("precioCompra"));
                    
                    System.out.println("Precio venta: " 
                        + eElement.getAttribute("precioVenta"));
                        
                    System.out.println("Stock: " 
                        + eElement.getAttribute("stock"));
                        
                    System.out.println(); 
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void mostrarCabecera(){
        System.out.println("-----------------------------------");
        System.out.println("|           HEVERIS               |");
        System.out.println("-----------------------------------");
    }
    
    public static void mostrarMenu(){
        System.out.println("1. Introducir dato");
        System.out.println("2. Leer todos los datos");
        System.out.println("0. SALIR");
    }
    
}
