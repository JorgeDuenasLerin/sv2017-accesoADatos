package stock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;

//Mario Belso Ros
//Alejandro Gascón
/*
   nombre de la BBDD: controlStock

    CREATE TABLE stock(
            referencia VARCHAR(20) PRIMARY KEY,
        nombre VARCHAR(45),
        precioCompra NUMERIC(10,2),
        precioVenta NUMERIC(10,2),
            stock NUMERIC(10)
    );

 */
public class Stock {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            String opcion = "";

            Class.forName("org.postgresql.Driver");

            String url = "jdbc:postgresql://localhost:5432/controlStock";
            String usuario = "postgres";
            String password = "admin";

            Connection con = DriverManager.getConnection(url, usuario, password);

            do {
                System.out.println();
                System.out.println("1.A�adir producto");
                System.out.println("2.Buscar por nombre");
                System.out.println("S.Salir");
                opcion = entrada.nextLine();
                switch (opcion) {
                    case "1":
                        anadirProducto(con);
                        break;
                    case "2":
                        buscarProducto(con);
                        break;
                    case "3":
                        break;

                }

            } while (!opcion.equals("s"));
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {

        }
    }

    public static void anadirProducto(Connection con) {
        System.out.println("Referencia: ");
        String referencia = entrada.nextLine();
        System.out.println("Nombre: ");
        String nombre = entrada.nextLine();
        System.out.println("Precio de compra: ");
        double precioCompra = Double.parseDouble(entrada.nextLine());
        System.out.println("Precio de venta: ");
        double precioVenta = Double.parseDouble(entrada.nextLine());
        System.out.println("Stock: ");
        int stock = Integer.parseInt(entrada.nextLine());
        try {
            Statement statement = con.createStatement();
            String producto = "INSERT INTO stock (referencia, nombre, "
                    + "precioCompra, precioVenta, stock) "
                    + " VALUES ('" + referencia
                    + "','" + nombre
                    + "'," + precioCompra
                    + "," + precioVenta
                    + "," + stock
                    + ");";
            statement.executeUpdate(producto);
            System.out.println("Producto guardado.");
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: No se ha podido guardar el producto.");
        }
    }

    private static void buscarProducto(Connection con) {
        System.out.println("Introduce el nombre del producto a buscar: ");
        String nombre = entrada.nextLine();
        PreparedStatement statement = null;
        try {
            statement = con.prepareStatement(
                    "SELECT referencia, nombre, "
                    + "precioCompra, precioCompra, "
                    + "precioVenta, stock "
                    + "FROM stock WHERE nombre LIKE "
                    + "'%" + nombre + "%'");

            ResultSet rs = statement.executeQuery();
            System.out.println("Referencia----nombre-----precio de Compra----"
                    + "precio de Venta-------Stock");
            while (rs.next()) {
                System.out.println(String.format("%-15s", rs.getString("referencia"))
                        + String.format("%-15s", rs.getString("nombre"))
                        + String.format("%-15s", rs.getBigDecimal("precioCompra"))
                        + String.format("%-15s", rs.getBigDecimal("precioVenta"))
                        + String.format("%-15s", rs.getBigDecimal("stock")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Stock.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
