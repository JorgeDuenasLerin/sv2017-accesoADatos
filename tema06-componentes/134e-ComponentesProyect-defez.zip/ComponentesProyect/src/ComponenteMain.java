import java.util.Scanner;
import java.sql.*;
/*Antonio Defez*/
public class ComponenteMain {

    
    public static void main(String[] args) {
        Menu men = new Menu();
        men.Run(); 
    }
 
}
