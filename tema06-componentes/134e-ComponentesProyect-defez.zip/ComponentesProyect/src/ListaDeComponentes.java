import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;



/*Antonio Defez Iba�ez*/

public class ListaDeComponentes  implements Serializable{

    private  ArrayList<Componente> ComponentesLista;
    AccesoADatos acceso;
    
    //inicializo el array
    public ListaDeComponentes()
    {
        ComponentesLista = new ArrayList<>();
        acceso = new AccesoADatos();
       
    }
   
    
    //1 set (devuelvo array)
    public void setComponentes(Componente[] array)
    {
        ComponentesLista = new ArrayList<Componente>(Arrays.asList(array));
       
    }
    //2 set (inserto e posicion)
    public void setComponente(int index,Componente key)
    {
        ComponentesLista.add(index, key);
        
    }
    
    public boolean borradoComponente(String marca, String modelo)
    {
         Componente tmp = getComponente(modelo,marca);
         if(tmp!=null)
             return acceso.borrarComponente(tmp)!=0;
         return false;
    }
    
    

    //1 get devuelvo array
    public Componente[] getComponentes()
    {
        Componente[] tmp2 =convertArray(ComponentesLista);
        return tmp2;
    }
    
    //2get  paso el indice y me devuelve a hacer eso 
    public Componente getComponente(int index)
    {
        return ComponentesLista.get(index);
    }


    public int anyadir(Componente tmp)
    {
        ComponentesLista.add(tmp);
        return acceso.Insertar(tmp);
    }
    
    public  int getCantidad()
    {
        return ComponentesLista.size();
    }
 
    private  Componente [] convertArray(ArrayList<Componente> tmp)
    {
        Componente[] tmp2 = new Componente[tmp.size()];
        for(int j=0; j<tmp2.length;j++)
        {
            tmp2[j] = tmp.get(j);
        }
        return tmp2;
    }
    
    
    public ListaDeComponentes findComponente(String busqueda)
    {
        ArrayList<Componente>temp1=acceso.obtenerPorTexto(busqueda);
        ListaDeComponentes temp= new ListaDeComponentes();
        Componente[] temp2 = convertArray(temp1);
        
         temp.setComponentes(temp2);
         return temp;
    }
    
    public boolean actualizarComponente(Componente c1,Componente c2)
    {
       return acceso.upadateComponente(c1, c2)!=0;
    }
    
    
    public ListaDeComponentes AllComponente() 
    {
        ArrayList<Componente>temp1=acceso.obtenerTodo();
        ListaDeComponentes temp= new ListaDeComponentes();
        Componente[] temp2 = convertArray(temp1);
        
         temp.setComponentes(temp2);
         return temp;
    }
    
    public Componente getComponente(String modelo,String marca)
    {
        return acceso.obtenerComponente(marca, modelo);
    }
    
    
    public  int insertar(ArrayList<Componente> lc) 
    {
        return acceso.Insertar(lc);
    }
    
   
 
}
