import java.sql.*;
import java.util.ArrayList;

/*Antonio Defez
 create table componente(
    marca varchar(30),
    modelo varchar(30),
    categoria varchar(30),
    precio numeric(6,2),
    primary key(marca,modelo)
)


 * 
 * */
public class AccesoADatos {

    private Connection connection;
    private Statement statement;
    public AccesoADatos() 
    {
        conectarBaseDatos();
    }
    
    private  void conectarBaseDatos()
    {
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/ComponenteDB";
            String usr = "postgres";
            String pass = "root";
            connection = DriverManager.getConnection(url, usr, pass);
            statement = connection.createStatement();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       

    }
    
    
    public ArrayList<Componente> obtenerPorTexto(String texto)
    {
        String sentenciaSQL = "SELECT marca,modelo,categoria"
                + ",precio FROM componente where "
                + " marca like '%"+texto+"%' "
                + " or  modelo like '%"+texto+"%' "
                + " or categoria like '%"+texto +"%'";
        
        try {
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            ArrayList<Componente> comp = new ArrayList<>();
            while (rs.next()) {
                String marca = rs.getString("marca");
                String modelo = rs.getString("modelo");
                String categoria = rs.getString("categoria");
                Float precio = rs.getFloat("precio");
                
                Componente temp = new Componente(marca,modelo,
                        categoria,precio);
           
                comp.add(temp);
            }
            return comp;

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
        
    }
    
    
    public int Insertar(Componente c)
    {
       
        try {
            int cantidad = statement.executeUpdate(
                     "INSERT INTO componente  "
                    + "VALUES('"+c.getMarca()+"','"+c.getModelo()+"','"
                    +c.getCategoria()+"',"+c.getPrecio()+");");
            return cantidad;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
 
 
    }
    

    
    public Componente obtenerComponente(String marca1,String modelo1) 
    {
        String sentenciaSQL = "SELECT marca,modelo,categoria"
                + ",precio FROM componente where "
                + " marca like '%"+marca1+"%'" + " and "
                +" modelo like '%"+modelo1+"%'";
        try {
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            ArrayList<Componente> comp = new ArrayList<>();
            while (rs.next()) {
                String marca = rs.getString("marca");
                String modelo = rs.getString("modelo");
                String categoria = rs.getString("categoria");
                Float precio = rs.getFloat("precio");
                
                Componente temp = new Componente(marca,modelo,
                        categoria,precio);
                comp.add(temp);
            }
            return comp.isEmpty()?null:comp.get(0);

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    
    public ArrayList<Componente> obtenerTodo()
    {
        String sentenciaSQL = "SELECT marca,modelo,categoria"
                + ",precio FROM componente";
        try {
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            ArrayList<Componente> comp = new ArrayList<>();
            while (rs.next()) {
                String marca = rs.getString("marca");
                String modelo = rs.getString("modelo");
                String categoria = rs.getString("categoria");
                Float precio = rs.getFloat("precio");
                
                Componente temp = new Componente(marca,modelo,categoria,precio);
             
                comp.add(temp);
            }
            return comp;

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    
    public int borrarComponente(Componente c)
    {
        try {
            int cantidad = statement.executeUpdate(
                    "delete from componente  "
                    +"where marca like '%"+c.getMarca()+"%'"
                    +" and modelo like '%"+c.getModelo()+"%'"
                    );
            return cantidad;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
    }
    
    public int upadateComponente(Componente c1,Componente c2)
    {
        String sentenciaSQL = 
                "UPDATE componente SET "
                + "marca='"+c2.getMarca()+"',"
                + "modelo='"+c2.getModelo()+"',"
                + "categoria='"+c2.getCategoria()+"',"
                + "precio="+c2.getPrecio()+
                " WHERE marca like '"+c1.getMarca()+"' "
                + "and modelo like '"+c1.getModelo()+"';";
        
        
        try {
            int cantidad = statement.executeUpdate(
                    sentenciaSQL
                    );
            return cantidad;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
    }
    
    
    public int Insertar(ArrayList<Componente> c)
    {
        int cont_total =0;
        for(int i=0; i<c.size();i++)
        {
            cont_total+=Insertar(c.get(i));
        }
        
        return cont_total;
    }
    
}
