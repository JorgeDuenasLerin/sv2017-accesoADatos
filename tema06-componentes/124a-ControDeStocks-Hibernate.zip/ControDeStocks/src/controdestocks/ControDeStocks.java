/**
 * create table articulo(
	referencia varchar(30) primary key,
    nombre varchar(50),
    precioCompra numeric(7,2),
    precioVenta numeric(7,2),
    stock numeric
);

insert into articulo values('RP234', 'Mesa camilla', 99.50, 149.99, 20);
insert into articulo values('HF452', 'Platos llanos', 14.85, 25.99, 50);
 */


package controdestocks;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Juan Salinas, Fernando Carbonell
 */
public class ControDeStocks {

    public static void main(String[] args) {
       boolean salir = false;
        Scanner sc = new Scanner(System.in);

        do
        {
            System.out.println("1.Añadir Producto");
            System.out.println("2.Buscar Producto por parte del "
                    + "nombre");
            String opcion = sc.nextLine();

            switch (opcion)
            {
                case "1":
                    anadirProducto();
                    break;
                case "2":
                    buscarProducto();
                    break;
            }
        } while (salir = false);
    }

    public static void anadirProducto()
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca referencia de producto");
        String referencia = sc.nextLine();
        System.out.print("Introduzca nombre de producto");
        String nombre = sc.nextLine();
        System.out.print("Introduzca precio compra del producto");
        BigDecimal pc = sc.nextBigDecimal();
        System.out.print("Introduzca precio venta del producto");
        BigDecimal pv = sc.nextBigDecimal();
        System.out.print("Introduzca Stock incial Producto");
        BigDecimal stock = sc.nextBigDecimal();

        Session sesion = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();

        Articulo p = new Articulo(referencia, nombre, pc, pv, stock);
        sesion.save(p);
        trans.commit();
        sesion.close();
                
    }

    public static void buscarProducto()
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Diga parte del nombre del prodcuto");
        String buscar = sc.nextLine();
        
        Session sesion = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery("from Articulo where "
                + "lower(nombre) like lower('%" + buscar + "%')");
        List resultados = consulta.list();
        for (Object resultado : resultados)
        {
            Articulo titulo = (Articulo) resultado;
            System.out.println(titulo);
        }
        sesion.close();
    }
    
}
