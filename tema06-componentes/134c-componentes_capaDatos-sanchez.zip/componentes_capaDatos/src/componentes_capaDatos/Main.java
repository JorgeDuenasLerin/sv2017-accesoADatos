package componentes_capaDatos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
 
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);      
        AccesoADatos acceso = new AccesoADatos();
        ArrayList<Componente> listaComponentes;
        boolean salir=false;
        String opcion;

        do {
            System.out.println("1. A�adir");
            System.out.println("2. Mostrar todo");
            System.out.println("2. Buscar por texto");
            System.out.println("S. Salir");
            opcion = teclado.nextLine();
            
            switch(opcion) {
            case "1":
              
                break;
            case "2":
              
                listaComponentes= acceso.obtenerTodo();
                for(Componente c :  listaComponentes) {
                    System.out.println(c.toString());
                }
                
                break;
            case "3":
                System.out.println("Que busca: ");
                String busco=teclado.nextLine();
                listaComponentes= acceso.obtenerPorTexto(busco);
                for(Componente c :  listaComponentes) {
                    System.out.println(c.toString());
                }
                
                break;
            case "s":
            case "S":
                salir=true;
                break;
            }
        }
        while( ! salir);
        teclado.close();
       
    }
}
