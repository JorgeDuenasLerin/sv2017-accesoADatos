package componentes_capaDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AccesoADatos {
    ArrayList<Componente> listaComponentes;   
    Componente componente;
    String url;
    String usr;
    String pass;
    Connection con;
    Statement statement;
    ResultSet rs;
    public AccesoADatos() {
        try{
            Class.forName("org.postgresql.Driver");
            url = "jdbc:postgresql://localhost:5432/componentesBD";
            usr = "postgres";
            pass = "1234";
            con = DriverManager.getConnection(url, usr, pass);
           
        }catch(Exception e){
        System.out.println("ERROR: No se ha podido establecer la conexi�n.");
        }      
    }
    
    public ArrayList<Componente> obtenerPorTexto(String texto) {
        listaComponentes = new ArrayList<Componente> ();

        Statement statement;
        try {
            statement = con.createStatement();

            String sentenciaSQL = "SELECT * FROM componentes where LOWER(marca) like '"
            + texto.toLowerCase() 
            +"' or LOWER(modelo) like '" 
            + texto.toLowerCase()+ "'";
            
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            int cont=0;
            while (rs.next()) {
                Componente comp = new Componente(
                        rs.getString(1), 
                        rs.getString(2), 
                        rs.getString(3),
                        Double.parseDouble(rs.getString(4)));
                
                listaComponentes.add(comp);
                cont++;
            }
            if(cont ==0) {
                System.out.println("no hay coincidencias");
            
            }
            rs.close();
           
        } catch (SQLException e) {
            System.out.println(e);
        }
        return listaComponentes;
      
    }
    
    public ArrayList<Componente>  obtenerTodo() {
        listaComponentes = new ArrayList<Componente> ();         
        Statement statement;
      
        try {
            statement = con.createStatement();
       
            String sentenciaSQL = "SELECT * FROM componentes ORDER BY marca";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            int cont=0;
            while (rs.next()) {
                Componente comp = new Componente(
                                rs.getString(1), 
                                rs.getString(2), 
                                rs.getString(3),
                                Double.parseDouble(rs.getString(4)));
                
                listaComponentes.add(comp);
                cont++;
            }
            if(cont ==0) {
                System.out.println("no hay coincidencias");
            }
            rs.close();            
       
            } catch (SQLException e) {
                System.out.println(e);
            }
        return listaComponentes;
    }
    
   /* public ArrayList<Componente>  obtener(String marca,String modelo) {
        listaComponentes = new ArrayList<Componente> ();
        return listaComponentes;
    }*/
    
    /*public boolean insertar(Componente componente) {
       
    }*/
    
    /*public boolean borrar(Componente componente) {
        
    }*/

}
