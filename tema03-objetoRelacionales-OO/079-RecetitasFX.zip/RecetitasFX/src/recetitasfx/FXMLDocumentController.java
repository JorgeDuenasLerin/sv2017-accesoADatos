/*
CREATE TABLE Recetas 
(
    id SERIAL PRIMARY KEY,
    nombre varchar(30),
    ingredientes varchar(30),
    comensales numeric(3),
    tiempo numeric(4),
    dificultad numeric(4),
    preparacion varchar(30)
);


 */
package recetitasfx;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 *
 * @author sergio
 */
public class FXMLDocumentController implements Initializable
{

    @FXML
    private Label label;
    @FXML
    private Button botonanadir;
    @FXML
    private Button botonmostrar;
    @FXML
    private TextField textonombre;
    @FXML
    private TextField textoingredientes;
    @FXML
    private TextField textocomensales;

    ObservableList<String> items = FXCollections.observableArrayList();
    @FXML
    private ListView<String> listview;

    private void handleButtonAction(ActionEvent event)
    {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {

    }

    @FXML
    private void accionanadir(ActionEvent event) throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");

        String url = "jdbc:postgresql://localhost:5432/RECETASBD";
        String usuario = "postgres";
        String password = "cactus22";
        Connection con = DriverManager.getConnection(url, usuario, password);
        
        Statement statement = con.createStatement();
        
        String nombre = textonombre.getText();
        String ingrediente = textoingredientes.getText();
        String comensales = textocomensales.getText();
        
          String sentenciaSQLInsert = 
        "INSERT INTO Recetas ( nombre, ingredientes, comensales) VALUES ("
                                + "'" + nombre + "',"
                                 + "'" + ingrediente + "',"
                               
                               
                                + "'" + comensales + "'" +");";

                        int cantidad2 = statement.executeUpdate(sentenciaSQLInsert);
                        if (cantidad2 == 1)
                        {
                            System.out.println("Datos insertados de forma correcta");
                            //TO DO PONER UN LABEL PARA EL USUARIO
                        }
                        else
                        {
                            System.out.println("No se han podido insertar");
                        }
                        

        
        
    }

    @FXML
    private void accionMostrar(ActionEvent event) throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");

        String url = "jdbc:postgresql://localhost:5432/RECETASBD";
        String usuario = "postgres";
        String password = "cactus22";
        Connection con = DriverManager.getConnection(url, usuario, password);

        Statement statement = con.createStatement();
        String sentenciaSQL = "SELECT * FROM Recetas ";
        ResultSet rs = statement.executeQuery(sentenciaSQL);

        while (rs.next())
        {
            System.out.println("id " + rs.getString(1) + "  "
                    + " nombre: " + rs.getString(2)
                    + " ingrediente: " + rs.getString(3) + " "
                    + " comensales: " + rs.getString(4) + " "
            );
            items.add(" ID: " + rs.getString(1)  + " Nombre: " + rs.getString(2) 
                    + " Ingredientes: " +rs.getString(3)
            + " comensales: " + rs.getString(4) + " ");
        }
        rs.close();
        listview.setItems(items);
    }

}
