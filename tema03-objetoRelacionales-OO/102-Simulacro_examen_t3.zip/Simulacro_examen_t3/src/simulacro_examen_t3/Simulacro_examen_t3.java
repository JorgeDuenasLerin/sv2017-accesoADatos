//Antonio Sevila
package simulacro_examen_t3;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author antonio
 */
public class Simulacro_examen_t3 {

    public static double encontrarPrecioArticulo(Connection con, double codigo) {
        double precio = 0;
        try {
            Statement statement = con.createStatement();
            String sentenciaSQL = "SELECT precio FROM producto"
                    + " WHERE codigo=" + codigo + ";";
            ResultSet rs = statement.executeQuery(sentenciaSQL);

            if (rs.next()) {
                precio = rs.getDouble("precio");
            } else {
                System.out.println("Producto no encontrado");
            }

        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        } finally {
            return precio;
        }
    }

    public static void insertarVenta(Connection con, double precio) {
        Statement statement;
        try {
            statement = con.createStatement();
            String sentenciaSQL = "INSERT INTO venta (precio, fechaYhora)"
                    + " VALUES (" + precio + ", CURRENT_TIMESTAMP);";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            if (cantidad > 0) {
                System.out.println("Venta registrada");
            } else {
                System.out.println("No se ha podido insertar la venta");
            }

        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }

    }

    public static void insertarVentaDetallada(Connection con, double cod) {
        Statement statement;
        try {
            statement = con.createStatement();
            String sentenciaSQL = "INSERT INTO ventaDetallada"
                    + " (precio, fechaYhora, codigoArticulo) VALUES "
                    + "(" + encontrarPrecioArticulo(con, cod)
                    + ", CURRENT_TIMESTAMP, " + cod + ");";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            if (cantidad > 0) {
                System.out.println("Venta registrada");
            } else {
                System.out.println("No se ha podido insertar la venta");
            }

        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }

    public static ArrayList<Ventas> buscarVentasDetalladas(Connection con,
            String fechaInicio, String fechaFin) {
        ArrayList<Ventas> lista = new ArrayList<>();
        try {
            Statement statement = con.createStatement();
            String sentenciaSQL = "SELECT venta.precio, codigoarticulo,"
                    + "venta.fechaYhora, descripcion, proveedor "
                    + "FROM venta, ventaDetallada "
                    + "LEFT JOIN producto "
                    + "ON ventaDetallada.codigoArticulo=producto.codigo "
                    + "WHERE venta.fechaYhora"
                    + " BETWEEN '"+ fechaInicio + "' AND '"+ fechaFin + "';";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            while (rs.next()) {

                Ventas venta = new Ventas(rs.getDouble("precio"),
                        rs.getInt("codigoarticulo"), rs.getString("descripcion"),
                        rs.getString("proveedor"), rs.getTimestamp("fechaYhora"));

                lista.add(venta);
            }
            if (lista.size() == 0) {
                System.out.println("No se han encontrado datos");
            }

        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        } finally {
            return lista;
        }
    }

    public static void buscarYmostrarVentas(Connection con,
            String fechaInicio, String fechaFin) {
        try {
            Statement statement = con.createStatement();
            String sentenciaSQL = "SELECT venta.*, codigoArticulo"
                    + " FROM venta, ventaDetallada;";
            ResultSet rs = statement.executeQuery(sentenciaSQL);
            System.out.println(String.format("%-7s", "Código")
                    + String.format("%-20s", "Precio")
                    + String.format("%-30s", "Fecha y hora de venta")
                    + String.format("%-20s", "Código artículo"));
            System.out.println("---------------------------------------------"
                    + "---------------------------------------------");
            while (rs.next()) {
                System.out.println(String.format("%-7s", rs.getInt("cod"))
                        + String.format("%-20s", rs.getDouble("precio"))
                        + String.format("%-30s", rs.getTimestamp("fechaYhora"))
                        + String.format("%-20s", rs.getInt("codigoArticulo")));
            }

        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduce nombre de usuario (vendedor/admin)");
        String tipoUser = teclado.nextLine().toLowerCase();
        double total = 0;
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/Bazar";
            String usr = "postgres";
            String pass = "postgre2017";
            Connection con = DriverManager.getConnection(url, usr, pass);
            switch (tipoUser) {
                case "vendedor":
                    String precio = "";

                    do {
                        System.out.println("Introduce el precio");
                        precio = teclado.nextLine();

                        if (!precio.equals("f") && !precio.equals("F")) {
                            double precioNumerico = Double.parseDouble(precio);

                            if (precioNumerico <= 1000) {
                                total += precioNumerico;
                                insertarVenta(con, precioNumerico);
                            } else if (precioNumerico >= 10000) {
                                double precioEncontrado
                                        = encontrarPrecioArticulo(
                                                con, precioNumerico);
                                total += precioEncontrado;
                                insertarVentaDetallada(con, precioNumerico);
                            }
                        }
                    } while (!precio.equals("f"));
                    System.out.println("Total: " + total);

                    break;
                case "admin":
                    System.out.println("Introduce la contraseña");
                    String contrasenya = teclado.nextLine();

                    if (contrasenya.equals("2345")) {
                        System.out.println("1. Ver lista de ventas");
                        System.out.println("2. Volcar ventas");
                        String opcionAdmin = teclado.nextLine();

                        System.out.println("Introduce una fecha y hora de inicio"
                                + " (yyyy/mm/dd hh:mm");
                        String fechaInicio = teclado.nextLine();

                        System.out.println("Introduce una fecha y hora de fin"
                                + " (yyyy/mm/dd hh:mm");
                        String fechaFin = teclado.nextLine();

                        switch (opcionAdmin) {
                            case "1":
                                buscarYmostrarVentas(con, fechaInicio, fechaFin);
                                break;
                            case "2":
                                ObjectContainer db = null;
                                ArrayList<Ventas> listaVentasDetalladas
                                        = buscarVentasDetalladas(con,fechaInicio
                                                ,fechaFin);
                                try {
                                    db = Db4o.openFile("ventas.dat");
                                    for (Ventas v : listaVentasDetalladas) {
                                        if( !db.get(v).hasNext()){
                                            db.set(v);
                                        }
                                    }
                                    db.commit();
                                    //No es necesario, pero quería comprobar 
                                    // que se había guardado bien
                                    ObjectSet set = db.get(
                                            new Ventas(0,0,null,null,null));
                                    
                                    while(set.hasNext()){
                                        System.out.println(set.next());
                                    }
                                } finally {
                                    if (db != null) {
                                        db.close();
                                    }
                                }
                                break;
                            default:
                                System.out.println("Opción no válida.");
                                break;
                        }
                    } else {
                        System.out.println("Contraseña incorrecta.");
                    }
                    break;
                default:
                    System.out.println("Usuario no reconocido.");
                    break;
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

}
