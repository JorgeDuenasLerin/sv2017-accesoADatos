/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulacro_examen_t3;

import java.sql.Timestamp;

/**
 *
 * @author antonio
 */
public class Ventas {

    private double precio;
    private int codigoArticulo;
    private String descripcion;
    private String proveedor;
    private Timestamp fechaYhora;

    public Ventas(double precio, int codigoArticulo, String descripcion,
            String proveedor, Timestamp fechaYhora) {
        this.precio = precio;
        this.codigoArticulo = codigoArticulo;
        this.descripcion = descripcion;
        this.proveedor = proveedor;
        this.fechaYhora = fechaYhora;
    }

    public String toString() {
        return "Ventas: Precio = " + precio + ", código del artículo = "
                + codigoArticulo + ", descripción = " + descripcion
                + ", proveedor = " + proveedor + ", fecha y hora = "
                + fechaYhora;
    }

    public boolean equals(Object otro) {
        if (otro == this) {
            return true;
        }
        if (!(otro instanceof Ventas)) {
            return false;
        }
        Ventas venta = (Ventas) otro;
        return (this.fechaYhora.equals(venta.fechaYhora) &&
                this.precio == venta.precio && 
                this.codigoArticulo == venta.codigoArticulo);
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the codigoArticulo
     */
    public int getCodigoArticulo() {
        return codigoArticulo;
    }

    /**
     * @param codigoArticulo the codigoArticulo to set
     */
    public void setCodigoArticulo(int codigoArticulo) {
        this.codigoArticulo = codigoArticulo;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the proveedor
     */
    public String getProveedor() {
        return proveedor;
    }

    /**
     * @param proveedor the proveedor to set
     */
    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    /**
     * @return the fechaYhora
     */
    public Timestamp getFechaYhora() {
        return fechaYhora;
    }

    /**
     * @param fechaYhora the fechaYhora to set
     */
    public void setFechaYhora(Timestamp fechaYhora) {
        this.fechaYhora = fechaYhora;
    }
}
