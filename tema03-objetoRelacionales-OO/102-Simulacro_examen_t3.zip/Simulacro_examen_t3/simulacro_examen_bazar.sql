--Antonio Sevila

CREATE DOMAIN tipoPrecioProducto AS NUMERIC(6,2)
	CHECK (VALUE >= 0);
	
CREATE TYPE tipoProveedor AS
	ENUM ('p1','p2');
	
CREATE TABLE producto(
	codigo NUMERIC(13) PRIMARY KEY,
	descripcion VARCHAR(100),
	precio tipoPrecioProducto,
	proveedor tipoProveedor,
	comentario TEXT[]
);

CREATE DOMAIN tipoPrecioVenta AS NUMERIC(6,2)
	CHECK (VALUE >= 0);
	
CREATE TABLE venta(
	cod SERIAL PRIMARY KEY,
	precio tipoPrecioVenta,
	fechaYhora timestamp
);


CREATE TABLE ventaDetallada(
	codigoArticulo NUMERIC(13),
	FOREIGN KEY (codigoArticulo) REFERENCES producto(codigo)
) INHERITS (venta);

ALTER TABLE ventaDetallada ADD PRIMARY KEY(cod);

--INSERTS

insert into producto VALUES (12345678, 'goma de borrar', 0.20, 'p1', ARRAY['Son buenas','Marca milán']);
insert into producto VALUES (23456789, 'Lápiz bueno', 0.30, 'p2', ARRAY['Buenos comentarios','No se que más poner', 'imaginación 0']);


