/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aaa_bd4o_relojes;

/**
 *
 * @author antonio
 */
public class Reloj {
    private String marca;
    private String modelo;
    private double precio;
    
    public Reloj(String marca, String modelo, double precio){
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    @Override
    public String toString() {
        return "Marca: " + marca + ", modelo: " + modelo
                + ", precio: " + precio;
    }
    @Override
    public boolean equals(Object objeto1) {
        if (this == objeto1) {
            return true;
        }
        if (!(objeto1 instanceof Reloj)) {
            return false;
        }
        Reloj reloj = (Reloj) objeto1;
        return this.getMarca().equals(reloj.getMarca())
                && this.getModelo().equals(reloj.getModelo())
                && this.getPrecio() == reloj.getPrecio();
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
