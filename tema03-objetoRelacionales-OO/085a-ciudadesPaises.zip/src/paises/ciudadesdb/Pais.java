package paises.ciudadesdb;

public class Pais {

    String nombre;
    int nHabitantes;

    public Pais(String nombre, int nHabitantes) {
        this.nombre = nombre;
        this.nHabitantes = nHabitantes;
    }

    public String getNombre() {
        return nombre;
    }

    public int getnHabitantes() {
        return nHabitantes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setnHabitantes(int nHabitantes) {
        this.nHabitantes = nHabitantes;
    }

}
