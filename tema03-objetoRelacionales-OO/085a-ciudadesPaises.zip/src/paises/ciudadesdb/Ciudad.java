package paises.ciudadesdb;

public class Ciudad {

    String nombre;
    int nHabitantes;
    Pais pais;

    public Ciudad(String nombre, int nHabitantes, Pais pais) {
        this.nombre = nombre;
        this.nHabitantes = nHabitantes;
        this.pais = pais;
    }

    public String getNombre() {
        return nombre;
    }

    public int getnHabitantes() {
        return nHabitantes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setnHabitantes(int nHabitantes) {
        this.nHabitantes = nHabitantes;
    }

    public Pais getPais() {
        return pais;
    }

    @Override
    public String toString() {
        return "Ciudad{Nombre=" + nombre + " Habitantes=" + nHabitantes + 
                ", pais=" + pais.getNombre() +  '}';
    }

}
