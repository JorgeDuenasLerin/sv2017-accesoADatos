/*Antonio Defez
 */
package recetasv2;

import java.util.Objects;

public class Receta {

    private String nombre;
    private String ingredientes;
    private int comensales;
    private short tiempo;
    private short dificultad;
    private String preparacion;

    public Receta() {
    }

    public Receta(String nombre) {
        this.nombre = nombre;
    }

    public Receta(String nombre, String ingredientes, int comensales,
            short tiempo, short dificultad, String preparacion) {
        this.nombre = nombre;
        this.ingredientes = ingredientes;
        this.comensales = comensales;
        this.tiempo = tiempo;
        this.dificultad = dificultad;
        this.preparacion = preparacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public int getComensales() {
        return comensales;
    }

    public void setComensales(int comensales) {
        this.comensales = comensales;
    }

    public short getTiempo() {
        return tiempo;
    }

    public void setTiempo(short tiempo) {
        this.tiempo = tiempo;
    }

    public short getDificultad() {
        return dificultad;
    }

    public void setDificultad(short dificultad) {
        this.dificultad = dificultad;
    }

    public String getPreparacion() {
        return preparacion;
    }

    public void setPreparacion(String preparacion) {
        this.preparacion = preparacion;
    }

    @Override
    public String toString() {
        return "Receta{" + "nombre=" + nombre
                + ", ingredientes=" + ingredientes
                + ", comensales=" + comensales
                + ", tiempo=" + tiempo
                + ", dificultad=" + dificultad
                + ", preparacion=" + preparacion + '}';
    }

    @Override
    public boolean equals(Object otro) {
        if (otro == this) {
            return true;
        }
        if (!(otro instanceof Receta)) {
            return false;
        }
        Receta other = (Receta) otro;
        return (this.nombre.equals(other.nombre)
                );
    }

}
