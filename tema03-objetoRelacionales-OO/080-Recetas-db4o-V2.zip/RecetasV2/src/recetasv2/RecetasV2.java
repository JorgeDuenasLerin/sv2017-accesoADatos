/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetasv2;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

/**
 *
 * @author Usuario
 */
public class RecetasV2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ObjectContainer db = null;
        try
        {
            db = Db4o.openFile("recetas.dat");
            ObjectSet macarones = db.get(new Receta("Macarrones"));
            while(macarones.hasNext())
                System.out.println(macarones.next());
            
            
        }
        finally
        {
            if(db!=null)
            {
                System.out.println("Todo ok1!!");
                db.close();
            }
        }
    }
}
