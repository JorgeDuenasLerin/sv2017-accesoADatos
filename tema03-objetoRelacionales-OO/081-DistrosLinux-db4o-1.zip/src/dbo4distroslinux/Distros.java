
package dbo4distroslinux;

import java.util.Objects;

public class Distros {
    String nombre;
    String mantenedor;
    int libre;
    String url;

    public Distros(String nombre, String mantenedor, int libre, String url) {
        this.nombre = nombre;
        this.mantenedor = mantenedor;
        this.libre = libre;
        this.url = url;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getMantenedor() {
        return mantenedor;
    }

    public int getLibre() {
        return libre;
    }

    public String getUrl() {
        return url;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMantenedor(String mantenedor) {
        this.mantenedor = mantenedor;
    }

    public void setLibre(int libre) {
        this.libre = libre;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "Distros{" + "nombre=" + nombre + ", mantenedor=" + mantenedor + ", libre=" + libre + ", url=" + url + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Distros other = (Distros) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.mantenedor, other.mantenedor)) {
            return false;
        }
        if (!Objects.equals(this.libre, other.libre)) {
            return false;
        }
        if (!Objects.equals(this.url, other.url)) {
            return false;
        }
        return true;
    }

    
    
}
