package dbo4distroslinux;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.Scanner;

public class Dbo4DistrosLinux {

    public static void main(String[] args) {
        ObjectContainer db = null;

        System.out.println("1.- Insertar distro");
        System.out.println("2.- Leer distro");
        Scanner sc = new Scanner(System.in);
        String opc = sc.nextLine();
        if (opc.equals("1")) {
            try {
                db = Db4o.openFile("distros.dat");

                System.out.println("Introduzca distro, mantenedor, libre o no y url: ");
                String distro = sc.nextLine();
                String mantenedor = sc.nextLine();
                int libre = sc.nextInt();
                sc.nextLine();
                String url = sc.nextLine();
                db.set(new Distros(distro, mantenedor, libre, url));
                db.commit();
            } catch (Exception e) {
                System.out.println("Error");
            } finally {
                if (db != null) {
                    db.close();
                }
            }
        } else if (opc.equals("2")) {
            try {
                System.out.println("Inserte el nombre de la distro: ");
                String distro = sc.nextLine();
                db = (ObjectContainer) Db4o.openFile("distros.dat");
                ObjectSet recetas = db.get(new Distros(distro, null, 0, null));
                System.out.println(recetas.size());
                while (recetas.hasNext()) {
                    System.out.println(recetas.next());
                }

            } catch (Exception e) {
                System.out.println("Algun error con el trasto este del 2008.");
            } finally {
                if (db != null) {
                    db.close();
                }
            }
        }

    }

}
