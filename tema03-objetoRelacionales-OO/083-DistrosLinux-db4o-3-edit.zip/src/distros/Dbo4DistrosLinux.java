package distros;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.Scanner;

public class Dbo4DistrosLinux {

    public static void main(String[] args) {
        ObjectContainer db = null;

        System.out.println("1.- Insertar distro");
        System.out.println("2.- Leer distro");
        System.out.println("3.- Modificar");
        Scanner sc = new Scanner(System.in);
        String opc = sc.nextLine();
        if (opc.equals("1")) {
            try {
                db = Db4o.openFile("distros.dat");

                System.out.println("Introduzca distro, mantenedor, libre o no y url: ");
                String distro = sc.nextLine();
                String mantenedor = sc.nextLine();
                int libre = sc.nextInt();
                sc.nextLine();
                String url = sc.nextLine();

                if (db.get(new Distros(distro, null, 0, null)).hasNext()
                        == false) {
                    db.set(new Distros(distro, mantenedor, libre, url));
                    db.commit();
                    System.out.println("Dato añadido.");
                } else {
                    System.out.println("Dato repetido, no añadido.");
                }
            } catch (Exception e) {
                System.out.println("Error");
            } finally {
                if (db != null) {
                    db.close();
                }
            }
        } else if (opc.equals("2")) {
            try {
                System.out.println("Inserte el nombre de la distro: ");
                String distro = sc.nextLine();
                db = (ObjectContainer) Db4o.openFile("distros.dat");
                ObjectSet recetas = db.get(new Distros(distro, null, 0, null));
                while (recetas.hasNext()) {
                    System.out.println(recetas.next());
                }

            } catch (Exception e) {
                System.out.println("Algun error con el trasto este del 2008.");
            } finally {
                if (db != null) {
                    db.close();
                }
            }
        } else if (opc.equals("3")) {
            System.out.println("Introduce el nombre de la distro a modificar: ");
            String distro = sc.nextLine();
            System.out.println("¿Que dato quieres cambiar?");
            System.out.println("1.- Distro // 2.- Mantenedor // 3.- Libre // 4.- URL");
            String cambio = sc.nextLine();
            System.out.println("Introduzca el nuevo valor: ");
            String nuevoDato = sc.nextLine();
            try {

                db = (ObjectContainer) Db4o.openFile("distros.dat");
                ObjectSet lista = db.get(new Distros(distro, null, 0, null));
                if (lista.hasNext()) {
                    Distros dis = (Distros) lista.next();
                    switch (cambio) {
                        case "1":
                            dis.setNombre(nuevoDato);
                            break;
                        case "2":
                            dis.setMantenedor(nuevoDato);
                            break;
                        case "3":
                            dis.setLibre(Integer.parseInt(nuevoDato));
                            break;
                        case "4":
                            dis.setUrl(nuevoDato);
                            break;
                    }

                    db.set(dis);
                    db.commit();
                }
            } catch (Exception e) {
                System.out.println("Algun error con el trasto este del 2008.");
            } finally {
                if (db != null) {
                    db.close();
                }
            }

        }

    }

}
