/*
 *SERGIO GARCIA BALSAS
Examen Mongo DB
 */
package simulacromongo;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

/**
 *
 * @author Sergio
 */
public class SimulacroMongo
{

    public static void menuAdmin()
    {
        System.out.println("1. Añadir operarios");
        System.out.println("2. Ver operarios");
        System.out.println("3. Añadir incidencias");
        System.out.println("4. Ver incidencias");
        System.out.println("5. Marcar incidencia como solucionada");
        System.out.println("0. Salir");
    }

    public static void menuOperario()
    {
        System.out.println("1. Lista de incidencias no solucionadas");
        System.out.println("2. Indicar visita");
        System.out.println("0. Salir");
    }

    public static void anyadirOperario(MongoCollection<Document> operario,
            Scanner sc)
    {
        System.out.println("Codigo?");
        Double codigo = sc.nextDouble();
        sc.nextLine();
        System.out.println("Nombre?");
        String nombre = sc.nextLine();
        System.out.println("Numero de especialidades?");
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<Document> listaEspecialdiades = new ArrayList<>(); //asi es como lo han hecho fer y antonio 
        for (int i = 0; i < n; i++)
        {
            System.out.println("Especialidad ?");
            String e = sc.nextLine();
            Document especialidad = new Document();
            especialidad.append("Profesion", e);
            listaEspecialdiades.add(especialidad);
        }
        Document d = new Document();
        d.append("codigo", codigo);
        d.append("nombre", nombre);
        d.append("especialidades", listaEspecialdiades);
        operario.insertOne(d);

    }

    public static void verOperario(MongoCollection<Document> operario,
            Scanner sc)
    {
        System.out.println("Nombre operario?");
        String nombre = sc.nextLine();
        int count = 0;
        for (Document usuario : operario.find(Filters.regex("nombre", nombre)))
        {
            System.out.println("Nombre: " + usuario.get("nombre").toString());
            System.out.println("Codigo : " + usuario.getDouble("codigo"));
            ArrayList<Document> lista = new ArrayList();
            lista = (ArrayList) usuario.get("especialidad");
            for (int i = 0; i < lista.size(); i++)
            {
                System.out.println(lista.get(i).toJson());
            }
            count++;
        }
        if (count == 0)
        {
            System.out.println("No se han encontrado resultados");
        }
    }

    public static void anyadirIncidencia(MongoCollection<Document> incidencia,
            Scanner sc)
    {
        System.out.println("Codigo");
        double codigo = sc.nextDouble();
        sc.nextLine();
        Date fecha = new Date();
        System.out.println("Nombre del cliente?");
        String nombre = sc.nextLine();
        System.out.println("Telefono?");
        String telefono = sc.nextLine();
        System.out.println("Direccion?");
        String direccion = sc.nextLine();
        System.out.println("Descripcion?");
        String descripcion = sc.nextLine();
        System.out.println("Especialidades implicadas");
        int n = sc.nextInt();
        sc.nextLine();
        List<Document> lista = new ArrayList<>();
        for (int i = 0; i < n; i++)
        {
            Document profesiones = new Document();
            System.out.println("Nombre de la profesion");
            String profesion = sc.nextLine();
            profesiones.append("profesion", profesion);
            lista.add(profesiones);
        }
        Document incidencias = new Document();
        incidencias.append("codigo", codigo);
        incidencias.append("fecha", fecha);
        incidencias.append("nombre", nombre);
        incidencias.append("telefono", telefono);
        incidencias.append("direccion", direccion);
        incidencias.append("descripcion", descripcion);
        incidencias.append("especialidades", lista);
        incidencia.insertOne(incidencias);
    }

    public static void verIncidencia(MongoCollection<Document> incidencia,
            Scanner sc)
    {
        System.out.println("Nombre de la incidencia?");
        String nombreIncidencia = sc.nextLine();
        int count = 0;
        for (Document d : incidencia.find(Filters.regex("nombre", nombreIncidencia)))
        {
            //System.out.println(d.toJson());
            System.out.println("Codigo: " + d.getDouble("codigo"));
            System.out.println("Fecha: " + d.getDate("fecha"));
            System.out.println("Nombre: " + d.getString("nombre"));
            System.out.println("Telefono: " + d.getString("telefono"));
            System.out.println("Direccion: " + d.getString("direccion"));
            System.out.println("Descripcion: " + d.getString("descripcion"));
            ArrayList<Document> l;
            l = (ArrayList) d.get("especialidades");
            for (int i = 0; i < l.size(); i++)
            {
                System.out.println(l.get(i).toJson()); //tambien vale sin .toJson()
            }
            count++;
        }
        if (count == 0)
        {
            System.out.println("No se han encontrado incidencias con ese nombre");
        }
    }

    public static void verIncidenciaNoSolucionadas(MongoCollection<Document> incidencia)
    {
        int count = 0;
        for (Document d : incidencia.find(Filters.eq("fechaReparacion", null)))
        {
            System.out.println(d.toJson());
            System.out.println("Nombre: " + d.getString("nombre"));
            //to do sacar más datos
            count++;
        }
        if (count == 0)
        {
            System.out.println("No hay incidencias por resolver");
        }
    }
    
    public static void indicarVisita(MongoCollection<Document> visita, Scanner sc)
    {
        System.out.println("Codigo operario?");
        double codigoOperario = sc.nextDouble();
        sc.nextLine();
        System.out.println("Codigo incidencia?");
        double codigoIncidencia = sc.nextDouble();
        sc.nextLine();
        Document d = new Document();
        d.append("codigoOperario", codigoOperario);
        d.append("codigoIncidencia", codigoIncidencia);
        System.out.println("Se ha arreglado? [si/no]");
        String arreglado = sc.nextLine().toLowerCase();
        if (arreglado.equals("si"))
        {
            Date fecha = new Date();
            d.append("fechaFinalizacion", fecha);
        }
        else
        {
            System.out.println("No se añadirá la fecha");
        }
        visita.insertOne(d);
    }

    public static void marcarIncidenciaSolucionada(MongoCollection<Document> incidencia,
            Scanner sc)
    {
        System.out.println("Codigo de la incidencia?");
        double codigo = sc.nextDouble();
        sc.nextLine();
        System.out.println("Fecha de reparacion?");
        String fecha = sc.nextLine();
        int count = 0;
        for (Document s : incidencia.find(Filters.eq("codigo", codigo)))
        {
            incidencia.updateOne(Filters.eq("codigo", codigo), Updates.set("fechaReparacion", fecha));
            count++;
        }
        if (count == 0)
        {
            System.out.println("No hay incidencias con ese código");
        }

    }

    public static String nombre(MongoCollection<Document> operario, String nombredeUsuario)
    {
        String nombreOperarios = "";
        for (Document s : operario.find(Filters.eq("nombre", nombredeUsuario)))
        {
            nombreOperarios = s.getString("nombre");
        }
        return nombreOperarios;
    }

    public static void main(String[] args)
    {
        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.SEVERE);
        MongoClient mongo = new MongoClient();
        MongoDatabase database = mongo.getDatabase("empresa");
        MongoCollection<Document> operario = database.getCollection("operario");
        MongoCollection<Document> incidencia = database.getCollection("incidencias");
        MongoCollection<Document> visita = database.getCollection("visitas");
        Scanner sc = new Scanner(System.in);
        System.out.println("Nombre de usuario?");
        String nombredeUsuario = sc.nextLine();
        if (nombredeUsuario.equals("admin"))
        {
            System.out.println("Contraseña?");
            String password = sc.nextLine();
            if (password.equals("1234"))
            {
                boolean salir = false;
                do
                {
                    menuAdmin();
                    String opcion = sc.nextLine();
                    switch (opcion)
                    {
                        case "1":
                            anyadirOperario(operario, sc);
                            break;
                        case "2":
                            verOperario(operario, sc);
                            break;
                        case "3":
                            anyadirIncidencia(incidencia, sc);
                            break;
                        case "4":
                            verIncidencia(incidencia, sc);
                            break;
                        case "5":
                            marcarIncidenciaSolucionada(incidencia, sc);
                            break;
                        case "0":
                            salir = true;
                            break;
                    }
                } while (!salir);
                System.out.println("Saliendo");
            } else
            {
                System.out.println("Contraseña incorrecta");
            }
        } else if (nombredeUsuario.equals(nombre(operario, nombredeUsuario)))
        {
            boolean salir = false;
            do
            {
                menuOperario();
                String opcion = sc.nextLine();
                switch (opcion)
                {
                    case "1":
                        verIncidenciaNoSolucionadas(incidencia);
                        break;
                    case "2":
                        indicarVisita( visita, sc);
                        break;
                    case "0":
                        salir = true;
                        break;

                }
            } while (!salir);
        } else
        {
            System.out.println("Adios");
        }
    }
}
