

package videojuegosbasedatos;
import java.io.Serializable;


public class Videojuego implements Serializable
{
    protected String genero;
    protected String titulo;
    protected String plataforma;
    protected String descripcion;
    
    public Videojuego()
    {
    }
    
    public Videojuego(String genero,String titulo,String plataforma,
                      String descripcion)
    {
        this.genero=genero;
        this.titulo=titulo;
        this.plataforma=plataforma;
        this.descripcion=descripcion;
    }
    
    public String getGenero()
    {
        return genero;
    }
    
    public String getTitulo()
    {
        return titulo;
    }
    
    public String getPlataforma()
    {
        return plataforma;
    }
    
    public String getDescripcion()
    {
        return descripcion;
    }
    
    public void setGenero(String genero)
    {
        this.genero=genero;
    }
    
    public void setTitulo(String titulo)
    {
        this.titulo=titulo;
    }
    
    public void setPlataforma(String plataforma)
    {
        this.plataforma=plataforma;
    }
    
    public void setDescripcion(String descripcion)
    {
        this.descripcion=descripcion;
    }
    
    /*Formato de guardado en la fichero*/
    @Override
    public String toString()
    {
        return (genero+"@"+titulo+"@"+plataforma+"@"+descripcion);
    }
    
    /*Formato para mostrar por pantalla*/
    public void MostrarDatos()
    {
        System.out.println("Genero->"+genero);
        System.out.println("Titulo->"+titulo);
        System.out.println("Plataforma->"+plataforma);
        System.out.println("Descripcion->"+descripcion);
    }
    
}
