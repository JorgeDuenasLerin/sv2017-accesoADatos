/*
Antonio defez ibanez
Abilio Reig
 */
package videojuegosbasedatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class VideojuegosBaseDatos {

    /**
     * @param args the command line arguments
     */
    public static int contador =0;
    public static void mostrarMenu()
    {
        System.out.println("1.Para introducir Videojuego");
        System.out.println("2.Buscar Videojueo "); //buscar un
        System.out.println("3.Modificar Videojuego");
        System.out.println("4.Salir app");
        System.out.println("Introduce opcion");
        
    }
    

    private static void createTable(Connection con) throws SQLException {
        String sqlCreate = "CREATE TABLE IF NOT EXISTS " + "videojuego("
                + "id        integer,"
                + "   genero           VARCHAR(30) ,"
                + "   titulo            VARCHAR(30),"
                + "   plataforma          VARCHAR(30),"
                + "   descripcion           VARCHAR(30),"
                + "   PRIMARY KEY (id));";
        Statement stmt = con.createStatement();
        stmt.execute(sqlCreate);
    }
    
    private static void insertarVideojuego(Connection con) throws SQLException {
       Scanner entrada=new Scanner(System.in);
        String genero,titulo,plataforma,descripcion;
        System.out.println("Añadiendo nuevo juego");
        System.out.println("Introduce genero");
        genero=entrada.nextLine();
        System.out.println("Introduce titulo");
        titulo=entrada.nextLine();
        System.out.println("Introduce plataforma");
        plataforma=entrada.nextLine();
        System.out.println("Introduce descripcion");
        descripcion=entrada.nextLine();
        
        Videojuego v1= new Videojuego(genero,titulo,plataforma,descripcion);
         Statement statement = con.createStatement();
         String sentenciaSQL = "INSERT INTO VIDEOJUEGO VALUES "
                +
                "("+contador
                +",'"+v1.getGenero()
                +"','"+v1.getTitulo()
                +"','"+v1.getPlataforma()
                +"','"+v1.getDescripcion()+"'"
                +");";
        int cantidad = statement.executeUpdate(sentenciaSQL);
        
        if(cantidad == 0)
            System.out.println("No ha sido posible añadir un nuevo objeto");
        else
        {
            System.out.println("Se ha insertado correctemente ");
            contador++;
        }
    }

    private static void buscarVideojuego(Connection con) throws SQLException {
        Scanner entrada=new Scanner(System.in);
        System.out.println("Introduce titulo y plataforma para buscar juego");
        System.out.println("Introduce titulo");
        String titulo=entrada.nextLine().toLowerCase();
        System.out.println("Introduce plataforma");
        String plataforma=entrada.nextLine().toLowerCase();
        
        Statement statement = con.createStatement();

        String sentenciaSQL = "select * from videojuego where LOWER(nombre) like ('" + titulo + "') "
                            + "and LOWER(plataforma) like ('" + plataforma + "');";
        ResultSet rs2 = statement.executeQuery(sentenciaSQL);
        
        if(rs2 == null)
        {
            System.out.println("No se ha encontrado");
        }
        else
        {
            while (rs2.next()) {
            System.out.println(rs2.getString(1) +
                        "\t " + rs2.getString(2)+
                        "\t " + rs2.getString(3)+
                        "\t "+rs2.getString(4)
            );
        }
        
        }
        rs2.close();
    }


    private static void actualizarVideojuego(Connection con) {
        
        String titulo;
        String genero;
        String plataforma;
        String descripcion;
        
        Scanner entrada = new Scanner(System.in);
        System.out.println("Intro para no modificar");

        System.out.println("Introduce nuevo titulo");
        titulo=entrada.nextLine();
        if(titulo.equals(""))
            titulo=v1.getTitulo();

        System.out.println("Introduce nuevo genero");
        genero=entrada.nextLine();
        if(genero.equals(""))
            genero=v1.getGenero();

        System.out.println("Introduce nueva plataforma");
        plataforma=entrada.nextLine();
        if(plataforma.equals(""))
            plataforma=v1.getPlataforma();

        System.out.println("Introduce nueva descripcion");
        descripcion=entrada.nextLine();
        if(descripcion.equals(""))
            descripcion=v1.getDescripcion();

        vtemp = new Videojuego(titulo,genero,plataforma,descripcion);
        
        
        System.out.println("¿Qué juego quieres modificar? (Introduce su ID");
                    int id = sc.nextInt();
                    String sentencia = "UPDATE videojuego "
                            + "SET titulo = " + userInput 
                            + ", genero = " + userInput2 
                            + ", plataforma = " + userInput3 
                            + ", descripcion = " + userInput4 
                            + "WHERE id = " + userInputID ";";
    }
    
    
    
    
    public static void main(String[] args) {
        try {
            int contador =0;
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/videojuegos";
            String usuario = "postgres";
            String password = "root";
            //abro la conexion
            Connection con = DriverManager.getConnection(url, usuario, password);
            createTable(con);
            boolean exit =false;
            Scanner entrada = new Scanner(System.in);
            
            do {
                mostrarMenu();
                String opcion = entrada.nextLine();
                switch(opcion){
                    case "1":
                        insertarVideojuego(con,contador);
                        break;
                    case "2":
                        buscarVideojuego(con);
                        break;
                    case "3":
                        actualizarVideojuego(con);
                        break;
                    case "4":
                        exit = true;
                        break;
                }
            }while (!exit);
            //cierro la conexion
            con.close();
        } catch (ClassNotFoundException ex) {
            System.out.println("Error class not found");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


    
}
