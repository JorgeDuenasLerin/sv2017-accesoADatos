//Roberto García Marcos
//Sandra Sánchez Alonso
//Azahara Carbonell Mateo

package bd_biblioteca;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;


public class BD_Biblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException,
            SQLException  {
        Scanner sc = new Scanner(System.in);
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "sudo";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();
        crearTablas(con);       
        ArrayList<Libro> libros = new ArrayList<>();
        ArrayList<Persona> personas = new ArrayList<>();
        MostrarMenu(sc,statement,libros,personas);
    }
    
    public static void MostrarMenu(Scanner sc,Statement statement,ArrayList<Libro> libros,ArrayList<Persona> personas)
            throws ClassNotFoundException,SQLException{   
    
    String opcion=" ";
        do{
            System.out.println("        MENU");
            System.out.println("1_ Ingresar nuevo usuario");
            System.out.println("2_ Ingresar nuevo libro");
            System.out.println("3_ Indicar prestamo");
            System.out.println("4_ Devolución de prestamo");
            System.out.println("5_ Buscar libro");
            System.out.println("6_ Mostrar Morosos");
            System.out.println("7_ Salir");
            opcion=sc.nextLine();
            switch(opcion){
                case "1": 
                    System.out.println("No disponible");
                    //DarDeAltaUsuario(statement,sc);
                    break;
                case "2": 
                    DarDeAltaLibro(statement,sc);
                    break;
                case "3": 
                    hacerPrestamo(statement,sc,libros);
                    break;
                case "4": 
                    //devolverPrestamo(con,sc);
                    break;
                case "5": 
                    BuscarLibro(statement,sc);
                    break;
                case "6": 
                    break;
                case "7":
                    System.out.println("Adios");
                    break;
            }
        }
            while(!opcion.equals("7"));
    }
    public static void BuscarLibro(Statement statement, Scanner sc)
            throws ClassNotFoundException,SQLException {
        System.out.println("Titulo:");
        String titulo=sc.nextLine();
        
        //String sentenciaSQL = "select libros.titulo,libros.prestado,"
                
    }
    
    public static void DarDeAltaUsuario(Statement statement, Scanner sc)
            throws ClassNotFoundException,SQLException {
        String dni, nombre, apellidos, telefono;
        System.out.println("Introduzca el DNI: ");
        dni = sc.nextLine();
        System.out.println("Introduzca el nombre: ");
        nombre = sc.nextLine();
        System.out.println("Introduzca los apellidos: ");
        apellidos = sc.nextLine();
        System.out.println("Introduzca telefono: ");
        telefono = sc.nextLine();

        String stentenciaSQL = "INSERT INTO personas (dni,nombre,apellidos,tlf) "
                + "VALUES ('" + dni.toLowerCase() + "','" + nombre.toLowerCase() 
                + "','" + apellidos.toLowerCase() + "','"
                + telefono
                + "');";
        int datos = statement.executeUpdate(stentenciaSQL);
        System.out.println(datos + "nuevo usuario añadido");

    } 
    public static void DarDeAltaLibro(Statement statement, Scanner sc)
            throws ClassNotFoundException,SQLException {
        String isbn, titulo, autor;
        System.out.println("Introduzca el ISBN: ");
        isbn = sc.nextLine();
        System.out.println("Introduzca el titulo: ");
        titulo = sc.nextLine();
        System.out.println("Introduzca el autor: ");
        autor = sc.nextLine();       

        String stentenciaSQL = "INSERT INTO libros (isbn,titulo,autor) "
                + "VALUES ('" + isbn.toLowerCase() + "','" + titulo.toLowerCase() 
                + "','" + autor.toLowerCase()
                + "');";
        int datos = statement.executeUpdate(stentenciaSQL);
        System.out.println(datos + "nuevo libro añadido");

    }
    public static void crearTablas(Connection con) {
        try{
            Statement statement = con.createStatement();
            // tabla libros
            String createTable = "CREATE TABLE IF NOT EXISTS libros("
                    + "titulo VARCHAR(255),"
                    + "autor VARCHAR(255),"
                    + "isbn VARCHAR(30), -- 30 POR PRUEBAS"
                    + "prestado boolean,"
                    + "PRIMARY KEY isbn);";
            statement.executeUpdate(createTable);
            
            // tabla personas
            createTable = "CREATE TABLE IF NOT EXISTS personas("
                    + "dni VARCHAR(9),"
                    + "nombre VARCHAR(50),"
                    + "apellidos VARCHAR(50),"
                    + "telefono VARCHAR(12),"
                    + "PRIMARY KEY dni);";
            statement.executeUpdate(createTable);
            
            // tabla prestamos
            createTable = "CREATE TABLE IF NOT EXISTS prestamos("
                    + "isbn VARCHAR(30) REFERENCES libros,"
                    + "dni VARCHAR(9) REFERENCES personas,"
                    + "fechaInicio VARCHAR(8),"
                    + "fechaFin VARCHAR(8),"
                    + "fechaDevolucion VARCHAR(8),"
                    + "PRIMARY KEY (isbn, dni, fechaInicio));";
            statement.executeUpdate(createTable);
            //statement.close();
        }
        catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
    }
     public static void hacerPrestamo(Statement statement, Scanner teclado,ArrayList<Libro> libros) 
            throws SQLException {
        //indicar un prestamo
        //una persona va a coger un libro
        //tiene que ser un libro que exista y una persona que exista
        //llamo a la funcion de enseñar la tabla de usuarios
        //tendremos un arraylist de libros y personas
        mostrarPersonas(statement);
        System.out.print("Dime dni: ");
        String dni = teclado.nextLine();
        
        mostrarLibros(statement);
        System.out.print("Dime isbn del libro: ");
        String isbn = teclado.nextLine();
        //fecha inicio es ahora.
        LocalDateTime fecha = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String fechaIni = fecha.toString();
        
        Prestamo prestamo = new Prestamo(dni,isbn,fechaIni);
        for(Libro libro : libros){
            if(isbn.equalsIgnoreCase(libro.getIsbn())){
                libro.setPrestado(true);
            }
        }
        
    }

    public static void mostrarPersonas(Statement statement)
            throws SQLException {

        String sentenciaSQL = "SELECT * FROM personas;";
        ResultSet rs = statement.executeQuery(sentenciaSQL);

        System.out.println(String.format("%-12s", "dni")
                + String.format("%-18s", "Nombre")
                + String.format("%-20s", "Apellidos"));

        System.out.println("--------------------------------");

        while (rs.next()) {
            System.out.println(String.format("%-12s", rs.getString(1))
                    + String.format("%-18s", rs.getString(2))
            + String.format("%-20s", rs.getString(3)));
        }
        rs.close();
    }
    public static void mostrarLibros(Statement statement)
            throws SQLException {

        String sentenciaSQL = "SELECT * FROM libros;";
        ResultSet rs = statement.executeQuery(sentenciaSQL);

        System.out.println(String.format("%-15s", "isbn")
                + String.format("%-18s", "Titulo"));

        System.out.println("-----------------------------------");

        while (rs.next()) {
            System.out.println(String.format("%-15s", rs.getString(1))
                    + String.format("%-18s", rs.getString(2)));
        }
        rs.close();
    }
    // NO TERMINADA
    public static void devolverPrestamo(Connection con, Scanner sc){
        try{
            String dni = "";
            String isbn = "";
            Statement statement = con.createStatement();
         
            System.out.println("Introduce dni: ");
            dni = sc.nextLine();
            System.out.println("Introduce ISBN: ");
            isbn = sc.nextLine();

            String query = "UPDATE libros SET devuelto = true"
                    + "WHERE isbn IS LIKE '%" + isbn + "%';";
            statement.executeUpdate(query);
            statement.close();
        }
        catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
    }
}
