/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd_biblioteca;


public class Prestamo {

    private String isbn;//pk
    private String dni;//pk
    private String fechaIni;//pk
    private String fechaFin;
    private String fechaDev;

    public Prestamo(String isbn, String dni, String fechaIni) {
        this.isbn = isbn;
        this.dni = dni;
        this.fechaIni = fechaIni; //yyyy/MM/dd
        int dia = Integer.parseInt(fechaIni.substring(8)) + 15;
        fechaFin = fechaIni.substring(0, 7) + dia;
        fechaDev = "";//si esta vacio es que no lo ha devuelto
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(String fechaIni) {
        this.fechaIni = fechaIni;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getFechaDev() {
        return fechaDev;
    }

    public void setFechaDev(String fechaDev) {
        this.fechaDev = fechaDev;
    }

}
