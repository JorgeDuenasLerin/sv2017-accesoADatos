// Daniel Ossa y Miguel Moya
package videojuegos;

import java.sql.SQLException;
import java.util.Scanner;

public class Videojuego {

    public final static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");

            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (final Exception e) {

        }
    }

    public static void main(String[] args) {
        boolean finish = false;
        Scanner scanner = new Scanner(System.in);
        byte opcion;

        try {
            Videojuegos videojuegos = new Videojuegos();

            while (!finish) {
                System.out.println("¿Qué operación desea realizar?");
                System.out.println("    1) Añadir.");
                System.out.println("    2) Buscar.");
                System.out.println("    3) Modificar.");
                opcion = scanner.nextByte();
                scanner.nextLine();
                String titulo,
                         genero,
                         plataforma,
                         resumen;
                switch (opcion) {
                    case 1:
                        int anyo = -1;
                        do {
                            System.out.println("Escribe el titulo:");
                            titulo = scanner.nextLine();
                        } while ("".equals(titulo));
                        do {
                            System.out.println("Escribe el genero:");
                            genero = scanner.nextLine();
                        } while ("".equals(genero));
                        do {
                            System.out.println("Escribe el año:");
                            anyo = scanner.nextInt();
                        } while (anyo == -1);
                        do {
                            System.out.println("Escribe la plataforma:");
                            plataforma = scanner.nextLine();
                        } while ("".equals(plataforma));
                        do {
                            System.out.println("Escribe el resumen:");
                            resumen = scanner.nextLine();
                        } while ("".equals(resumen));
                        videojuegos.insertar(titulo, genero,
                                anyo, plataforma, resumen);
                        break;
                    case 2:
                        System.out.println("Introduce que buscar: ");
                        String buscar = scanner.nextLine();

                        videojuegos.buscar(buscar, buscar, buscar, buscar);
                        break;
                    case 3:
                        System.out.println("Introduce la id del campo"
                                + " a modificar:");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        
                        System.out.println("Introduce el nuevo titulo"
                                + "(dejar vacío para no modificar): ");
                        titulo = scanner.nextLine();
                        
                        System.out.println("Introduce el nuevo genero"
                                + "(dejar vacío para no modificar): ");
                        genero = scanner.nextLine();
                        
                        System.out.println("Introduce el nuevo año"
                                + "(dejar vacío para no modificar): ");
                        anyo = scanner.nextInt();
                        scanner.nextLine();
                        
                        System.out.println("Introduce el nuevo plataforma"
                                + "(dejar vacío para no modificar): ");
                        plataforma = scanner.nextLine();
                        
                        System.out.println("Introduce el nuevo resumen"
                                + "(dejar vacío para no modificar): ");
                        resumen = scanner.nextLine();
                        
                        videojuegos.modificar(id, titulo, genero, 
                                anyo, plataforma, resumen);
                        break;
                    default:
                        System.out.println("No se reconoce la opción");
                        break;
                }
                clearConsole();
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Error");
        } catch (SQLException ex) {
            System.out.println("Error");
        }
    }
}
