//Alejandro Gascón y Miguel Moya
package videojuegos;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Videojuegos implements Serializable {

    private Connection con;

    public Videojuegos() throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");

        String url = "jdbc:postgresql://localhost:5432/videojuegos";
        String usuario = "postgres";
        String password = "";
        this.con = DriverManager.getConnection(url, usuario, password);
    }

    public int insertar(String titulo, String genero, int anyo,
            String plataforma, String resumen) throws SQLException {
        Statement statement = con.createStatement();

        String sql = " INSERT INTO videojuego (titulo, genero, anyo, plataforma, resumen)"
                + " VALUES ('" + titulo + "', '"
                + genero + "', '" + anyo + "', '"
                + resumen + "', '"
                + genero + "');";
        statement.executeUpdate(sql);
        statement.close();
        int cantidad = statement.executeUpdate(sql);
        statement.close();
        return cantidad;
    }

    public int modificar(int id, String titulo, String genero, int anyo,
            String plataforma, String resumen) throws SQLException {
        Statement statement = con.createStatement();

        String sql = " update videojuego set"
                + titulo != "" ? ("titulo = '" + titulo) : ""
                + genero != "" ? ("', genero = '" + genero) : ""
                + "', anyo + '" + anyo
                + "', plataforma = '" + plataforma
                + "', resumen = '" + resumen
                + "');";

        statement.executeUpdate(sql);
        statement.close();
        int cantidad = statement.executeUpdate(sql);
        statement.close();
        return cantidad;
    }

    public void crearDataBase() throws SQLException {
        Statement statement = con.createStatement();

        String sql = "create table if not exist videojuego ( "
                + "id numeric(5) primary key,"
                + "titulo varchar(30),"
                + "genero varchar(30),"
                + "anyo numeric(4),"
                + "plataforma varchar(30),"
                + "resumen varchar(100));";

        statement.executeUpdate(sql);
        statement.close();
    }

    public void buscar(String titulo, String genero,
            String plataforma, String resumen) throws SQLException {
        Statement statement = con.createStatement();

        String sentenciaSQL = "SELECT * FROM videojuego WHERE"
                + "titulo like('%" + titulo + "%') "
                + "or genero like('%" + genero + "%') "
                + "or plataforma like('%" + plataforma + "%') "
                + "or resumen like('%" + titulo + "%');";
        ResultSet rs = statement.executeQuery(sentenciaSQL);

        System.out.println(String.format("%-20s", "id")
                + String.format("%-20s", "titulo")
                + String.format("%-20s", "genero")
                + String.format("%-20s", "año")
                + String.format("%-20s", "plataforma")
                + String.format("%-20s", "resumen"));
        System.out.println("-------------------------------------"
                + "-------------------------------"
                + "-------------------------------");
        while (rs.next()) {
            System.out.println(String.format("%-20s", rs.getString(1))
                    + String.format("%-20s", rs.getString(2))
                    + String.format("%-20s", rs.getString(3))
                    + String.format("%-20s", rs.getString(4))
                    + String.format("%-20s", rs.getString(5))
                    + String.format("%-20s", rs.getString(6)));
        }
        rs.close();
        statement.close();
    }

    public void buscarPorId(int id) throws SQLException {
        Statement statement = con.createStatement();

        String sentenciaSQL = "SELECT * FROM videojuego WHERE id = " + id;
        ResultSet rs = statement.executeQuery(sentenciaSQL);

        System.out.println(String.format("%-20s", "id")
                + String.format("%-20s", "titulo")
                + String.format("%-20s", "genero")
                + String.format("%-20s", "año")
                + String.format("%-20s", "plataforma")
                + String.format("%-20s", "resumen"));
        System.out.println("-------------------------------------"
                + "-------------------------------"
                + "-------------------------------");
        while (rs.next()) {
            System.out.println(String.format("%-20s", rs.getString(1))
                    + String.format("%-20s", rs.getString(2))
                    + String.format("%-20s", rs.getString(3))
                    + String.format("%-20s", rs.getString(4))
                    + String.format("%-20s", rs.getString(5))
                    + String.format("%-20s", rs.getString(6)));
        }
        rs.close();
        statement.close();
    }
}
