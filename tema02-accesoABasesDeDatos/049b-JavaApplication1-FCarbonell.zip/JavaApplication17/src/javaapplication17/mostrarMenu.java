package javaapplication17;

import java.sql.SQLException;
import java.util.Scanner;

public class mostrarMenu
{

    private Bd bd = new Bd();

    public void mostrar() throws ClassNotFoundException, SQLException
    {
        Scanner teclado = new Scanner(System.in);
        boolean salir = false;
        //Creamos las tablas
        bd.crearTablas();
        
        do
        {
            System.out.println("1. Añadir usuarios");
            System.out.println("2. Añadir libros");
            System.out.println("3. Indicar préstamo");
            System.out.println("4. Devolver préstamo");
            System.out.println("5. Buscar libros");
            System.out.println("6. Mostrar listado de morosos");
            System.out.println("7. Salir");

            String opcion = teclado.nextLine();

            switch (opcion)
            {
                case "1": //Añadir usuarios
                    System.out.println("No está disponible todavía");
                    break;
                case "2": //Añadir libro    
                    System.out.println("Introduce el ID del libro");
                    String codigo = teclado.nextLine();
                    System.out.println("Introduce titulo del Libro");
                    String titulo = teclado.nextLine();
                    System.out.println("Introduce genero: ");
                    String genero = teclado.nextLine();
                    bd.anadirLibro(codigo,titulo,genero);
                    break;
                case "3": //Indicar prestamo
                    System.out.println("Introduce el dni del usuario");
                    String dni = teclado.nextLine();
                    System.out.println("Introduce el codigo del libro");
                    String cod = teclado.nextLine();
                    System.out.println("Introduce la fecha de incio del prestamo");
                    String f1 = teclado.nextLine();
                    System.out.println("Introduce la fecha de fin del prestamo");
                    String f2 = teclado.nextLine();
                    System.out.println("Introduce la fecha maxima de devolucion");
                    String f3 = teclado.nextLine();

                    bd.indicarPrestamo(dni, cod, f1, f2, f3);
                    break;
                case "4": //Devolver prestamo
                    System.out.println("Introduce el codigo del libro");
                    String codigo3 = teclado.nextLine();
                    bd.devolverPrestamo(codigo3);
                    break;
                case "5": //Buscar libro
                    System.out.println("Introduce el libro que buscas");
                    String libro = teclado.nextLine();
                    bd.buscarLibros(libro);
                    break;
                case "6": //Mostrar listado de morosos
                    bd.morosos();
                    break;
                case "7":
                    salir = true;
                    break;
            }
        } while (!salir);
        System.out.println("Gracias por usar la libreria");
    }
}
