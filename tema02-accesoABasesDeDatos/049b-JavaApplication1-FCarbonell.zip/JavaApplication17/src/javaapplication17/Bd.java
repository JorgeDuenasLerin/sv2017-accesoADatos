package javaapplication17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Bd
{

    public Bd()
    {
    }

    public void anadirLibro(String codigo, String titulo, String genero)
            throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String sentenciaSQLanyadir = "INSERT INTO libros values ('"
                + codigo + "','"
                + titulo + "','"
                + genero + "');";

        statement.executeUpdate(sentenciaSQLanyadir);
        con.close();
    }

    public void indicarPrestamo(String dni, String cod, String fechainicio, String fechafin,
            String fechadevolucion) throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String sentenciaSQLanyadir = "INSERT INTO prestamos values ('"
                + dni + "','"
                + cod + "','"
                + fechainicio + "','"
                + fechafin + "','"
                + fechadevolucion + "');";

        statement.executeUpdate(sentenciaSQLanyadir);
        con.close();
    }

    public void devolverPrestamo(String codigo) throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String sentenciaSQL = "select fechadevolucion from prestamos, libros\n"
                + "WHERE libros.cod = prestamos.cod and libros.cod='"+codigo+"';";
        statement.executeQuery(sentenciaSQL);
        con.close();
    }

    public void buscarLibros(String nombre) throws ClassNotFoundException, SQLException
    {

        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String buscarLibros = "select l.cod, l.nombre from libros l, prestamos p "
                + "where l.nombre like '%nombre%'";

        statement.executeQuery(buscarLibros);
        con.close();
    }

    public void morosos() throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String consultaMorosos = "select p.dni, l.cod from personas p, libros l, "
                + "prestamos pr where p.dni = pr.dni and l.cod = pr.cod "
                + "and fechaDevolucion is null";
        statement.executeQuery(consultaMorosos);
        con.close();
    }

    public void crearTablas() throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "anguila";
        Connection con = DriverManager.getConnection(url, usuario, password);
        Statement statement = con.createStatement();

        String sentenciaPersonas = "CREATE TABLE IF NOT EXISTS personas ( "
                + "dni varchar (10) PRIMARY KEY, "
                + "nombre varchar (10), "
                + "email varchar (50) "
                + ");";
        statement.executeUpdate(sentenciaPersonas);

        String sentenciaLibros = "CREATE TABLE IF NOT EXISTS libros ( "
                + "cod varchar (10) PRIMARY KEY, "
                + "titulo varchar (50), "
                + "genero varchar (10) "
                + ");";
        statement.executeUpdate(sentenciaLibros);

        String sentenciaPrestamos = "CREATE TABLE IF NOT EXISTS prestamos ( "
                + "dni varchar (10) , "
                + "cod varchar (10) ,"
                + "fechaInicio date , "
                + "fechaFin date,"
                + "fechaDevolucion date, "
                + "FOREIGN KEY (dni) REFERENCES personas (dni),"
                + "FOREIGN KEY (cod) REFERENCES libros (cod),"
                + "PRIMARY KEY(dni, cod, fechaInicio)"
                + ");";

        statement.executeUpdate(sentenciaPrestamos);
    }
}
