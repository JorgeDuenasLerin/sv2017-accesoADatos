
package javaapplication17;

public class Libro {

    private String cod;
    private String titulo;
    private String genero;

    public Libro(String cod, String titulo, String genero) {
        this.cod = cod;
        this.titulo = titulo;
        this.genero = genero;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
