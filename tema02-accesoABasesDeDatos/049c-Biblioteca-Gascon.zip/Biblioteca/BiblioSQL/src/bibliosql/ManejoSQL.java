package bibliosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ManejoSQL {

    String[] sentCreaTablas = new String[3];
    String url;
    String usuario;
    String password;

    public ManejoSQL(String sent1, String sent2, String sent3) {
        sentCreaTablas[0] = sent1;
        sentCreaTablas[1] = sent2;
        sentCreaTablas[2] = sent3;
        url = "jdbc:postgresql://localhost:5432/Biblioteca";
        usuario = "postgres";
        password = "admin";
    }

    public ManejoSQL() throws ClassNotFoundException, SQLException {
        url = "jdbc:postgresql://localhost:5432/Biblioteca";
        usuario = "postgres";
        password = "admin";
    }

    public void crearTabla() {
        try {
            Connection con =
                    DriverManager.getConnection(url, usuario, password);
            Statement statement = con.createStatement();
            int cantidad = 0;
            for(String s : sentCreaTablas)
            {
                 cantidad = statement.executeUpdate(s);
            }
            System.out.println("Datos insertados: " + cantidad);
            con.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("No ha podido crearse la tabla");
        }
        
    }
    
    public void addLibro(
            String codigo, String titulo, String autor, boolean prestado) {
        try {
            Connection con =
                    DriverManager.getConnection(url, usuario, password);       
            Statement statementOUT = con.createStatement();
            String sentenciaSQL = "INSERT INTO libros VALUES(" +
                    "'" + codigo + "'" +
                    "'" + titulo + "'" +
                    "'" + autor + "'" +
                    "'" + prestado + "');";
            ResultSet rs = statementOUT.executeQuery(sentenciaSQL);
            rs.close();
            con.close();
            statementOUT.close();
        } 
        catch (SQLException e) {
            System.out.println("No se ha podido insertar el libro");
        }
    }
    
    public void devolverPrestamo(
            String libroIntroducido, String personaIntroducida) {
        try {
            Connection con =
                    DriverManager.getConnection(url, usuario, password);       
            Statement statementOUT = con.createStatement();
            String sentenciaSQL = 
                    "update prestamos set fecha_devolucion where" +
                    "libro=" + libroIntroducido + " and " +
                    "persona=" + personaIntroducida + ";";
            ResultSet rs = statementOUT.executeQuery(sentenciaSQL);
            rs.close();
            con.close();
            statementOUT.close();
        } 
        catch (SQLException e) {
            System.out.println("No se ha podido devolver el libro");
        }
    }
    
    public void indicarPrestamo(String nombre, String libro, String fechaInicio, String fechaFin) {
        try {
            Connection con
                    = DriverManager.getConnection(url, usuario, password);
            Statement statementOUT = con.createStatement();
            String sentenciaSQL = "INSERT INTO prestamos VALUES("
                    +"select codigo from personas where LOWER(nombre) like '%"
                    +nombre.toLowerCase() + "%'; , select codigo from libros where"
                    + "LOWER(nombre) like '%"+libro+"%';, "+fechaInicio+", "+ 
                    fechaFin+");";
            ResultSet rs = statementOUT.executeQuery(sentenciaSQL);
            rs.close();
            con.close();
            statementOUT.close();
        } 
        catch (SQLException e) {
            System.out.println("Error con SQL.");
        }
    }
    public void mosrtarPrestados() {
        try {
            Connection con
                    = DriverManager.getConnection(url, usuario, password);
            Statement statementOUT = con.createStatement();
            String sentenciaSQL = "select nombre from libro where prestado = false";
            ResultSet rs = statementOUT.executeQuery(sentenciaSQL);
            rs.close();
            con.close();
            statementOUT.close();
        } catch (SQLException e) {
            System.out.println("Error con SQL.");
        }
    }
}
