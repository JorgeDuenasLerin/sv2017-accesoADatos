//Mario Belso 
//Alejandro Gascón
//Daniel Ossa
package bibliosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class BiblioSQL {

    public static void showMenu() {
        System.out.println("1 -- Añadir Libro");
        System.out.println("2 -- Indicar Prestamo");
        System.out.println("3 -- Devolver Prestamo");
        System.out.println("4 -- Buscar libro (Prestado)");
        System.out.println("5 -- Ver Morosos");
        System.out.print("Opcion: ");
    }
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException{
        
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/biblioteca";
        String usuario = "postgres";
        String password = "1234";
        Connection con = DriverManager.getConnection(url, usuario, password);
        String sentenciaSQL;
        ResultSet rs;
        Scanner scan = new Scanner(System.in);
        boolean exit = false;
        String opcion;
        ManejoSQL manejoSQL = new ManejoSQL();
        
        do
        {
            showMenu();
            opcion = scan.nextLine();
            
            switch ( opcion ) {
                case "1":
                    
                    System.out.print("Codigo: ");
                    String codigo = scan.nextLine();
                    System.out.print("Titulo: ");
                    String titulo = scan.nextLine();
                    System.out.print("Autor: ");
                    String autor = scan.nextLine();
                    
                    manejoSQL.addLibro(codigo, titulo, autor, false);
                    
                    
                    break;
                    
                case "2":
                    System.out.print("Libro a prestar: ");
                    String libro = scan.nextLine();
                    System.out.print("Persona que se lo lleva: ");
                    String persona = scan.nextLine();
                    System.out.print("Fecha inicio: ");
                    String fechaInicio = scan.nextLine();
                    System.out.print("Fecha fin: ");
                    String fechaFin = scan.nextLine();
                    
                    manejoSQL.indicarPrestamo(
                            libro, persona, fechaInicio, fechaFin);
                    break;
                    
                case "3":
                    System.out.print("Libro a devolver: ");
                    String libroD = scan.nextLine();
                    System.out.print("Persona que lo devuelve: ");
                    String personaD = scan.nextLine();
                    
                    manejoSQL.devolverPrestamo(libroD, personaD);
                    break;
                    
                case "4":
                    manejoSQL.mosrtarPrestados();
                    break;
                    
                case "5":
                    break;
                    
                case "0":
                    exit = true;
                    break;
                    
                default:
                    System.out.println("No es una opcion valida!");
                    break;
            }
        }
        while( !exit );
    }
}
