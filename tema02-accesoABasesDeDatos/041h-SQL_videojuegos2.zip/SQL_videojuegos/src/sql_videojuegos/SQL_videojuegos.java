/*base datos videojuegos, añadir, buscar y modificar */
//Juan Salinas y Alexandra Sanchez
package sql_videojuegos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SQL_videojuegos {

    public static void main(String[] args) throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/videojuegos";
        String usuario = "postgres";
        String password = "1234";
        Connection con = DriverManager.getConnection(url, usuario, password);

        Statement statement = con.createStatement();
        String sentenciaSQL;

        sentenciaSQL = "CREATE TABLE IF NOT EXISTS videojuegos "
                + "( id serial, titulo varchar(30),"
                + "genero varchar(30), anyo integer, plataforma varchar(30),"
                + "resumen varchar(30),"
                + "primary key(id));";

        int cantidad = statement.executeUpdate(sentenciaSQL);
        System.out.println("tabla creada: " + cantidad);

        Scanner teclado = new Scanner(System.in);

        boolean salir = true;
        String opcion = "";
        do {
            System.out.println("MENU");
            System.out.println("1.- Añadir videojuego");
            System.out.println("2.- Buscar videojuego");
            System.out.println("3.- Modifocar videojuego");
            System.out.println("4.- Salir");
            opcion = teclado.nextLine();

            switch (opcion) {
                case "1":
                    //System.out.println("ID:");
                    //String id = teclado.nextLine();
                    System.out.print("titulo: ");
                    String titulo = teclado.nextLine();
                    System.out.println("genero: ");
                    String genero = teclado.nextLine();
                    System.out.println("año: ");
                    String anyo = teclado.nextLine();
                    System.out.println("plataforma: ");
                    String plat = teclado.nextLine();
                    System.out.println("resumen: ");
                    String resumen = teclado.nextLine();

                    //inserto el videojuego
                    sentenciaSQL = "INSERT INTO videojuegos (titulo,"
                            + "genero, anyo, plataforma,resumen) VALUES" + "('"
                            + titulo + "','"
                            + genero + "','" + Integer.parseInt(anyo) + "','"
                            + plat + "','" + resumen + "');";

                    cantidad = statement.executeUpdate(sentenciaSQL);

                    System.out.println("juegos insertados: " + cantidad);

                    break;
                case "2"://buscar videojuego por nombre
                    System.out.println("Dime nombre de videojuego:");
                    String nombre = teclado.nextLine();
                    String sentenciaSQL2 = "SELECT * FROM videojuegos WHERE "
                            + "lower(titulo) LIKE '%" 
                            + nombre.toLowerCase() + "%';";
                    ResultSet rs = statement.executeQuery(sentenciaSQL2);

                    System.out.println(String.format("%-10s", "Id")
                            + String.format("%-10s", "titulo")
                            + String.format("%-10s", "genero")
                            + String.format("%-10s", "año")
                            + String.format("%-10s", "plataforma")
                            + String.format("%-10s", "resumen"));
                    System.out.println("-------------------------------------"
                            + "-------------------------");

                    while (rs.next()) {
                        System.out.println(String.format("%-10s", rs.getString(1))
                                + String.format("%-10s", rs.getString(2))
                                + String.format("%-10s", rs.getString(3))
                                + String.format("%-10s", rs.getString(4))
                                + String.format("%-10s", rs.getString(5))
                                + String.format("%-10s", rs.getString(6)));
                    }
                    rs.close();
                    break;
                case "3"://modificar
                    System.out.println("Que juego quiere modificar(titulo):");
                    String nombre2 = teclado.nextLine();
                    System.out.println("Que campo quiere modificar?: ");
                    System.out.println("(titulo)(genero)(anyo)"
                            + "(plataforma)(resumen)");
                    String campo = teclado.nextLine();
                    System.out.println("cambio de campo: ");
                    String cambio = teclado.nextLine();

                    sentenciaSQL = "UPDATE videojuegos SET " + campo + " = '"
                            + cambio + "'  WHERE LOWER(titulo) LIKE '" 
                            + nombre2.toLowerCase() + "';";

                    cantidad = statement.executeUpdate(sentenciaSQL);
                    System.out.println("juegos modificados: " + cantidad);
                    
                    sentenciaSQL2 = "SELECT * FROM videojuegos WHERE "
                            + "lower(titulo) LIKE '%" 
                            + nombre2.toLowerCase() + "%';";
                    rs = statement.executeQuery(sentenciaSQL2);

                    System.out.println(String.format("%-10s", "Id")
                            + String.format("%-10s", "titulo")
                            + String.format("%-10s", "genero")
                            + String.format("%-10s", "año")
                            + String.format("%-10s", "plataforma")
                            + String.format("%-10s", "resumen"));
                    System.out.println("-------------------------------------"
                            + "-------------------------");

                    while (rs.next()) {
                        System.out.println(String.format("%-10s", rs.getString(1))
                                + String.format("%-10s", rs.getString(2))
                                + String.format("%-10s", rs.getString(3))
                                + String.format("%-10s", rs.getString(4))
                                + String.format("%-10s", rs.getString(5))
                                + String.format("%-10s", rs.getString(6)));
                    }
                    rs.close();
                    

                    break;
                case "4":
                    System.out.println("Saliendo...\n\n");

                    con.close();
                    salir = false;
                    break;
                default:
                    System.out.println("Opcion incorrecta\n\n");
                    break;
            }
        } while (salir);

    }

}
