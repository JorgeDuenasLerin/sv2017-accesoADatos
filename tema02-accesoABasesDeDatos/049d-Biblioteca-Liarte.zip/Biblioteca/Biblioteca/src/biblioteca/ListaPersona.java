package biblioteca;

/**
 * @author Miguel Moya Ortega
 */
public class ListaPersona {

}
