
package biblioteca;

import java.util.Scanner;

/**
 *
 * @authors Miguel Moya, Carla Liarte, Toni Defez y Javier Montejo.
 */
public class Biblioteca {
    
    public static void main(String[] args) {
        String opcion;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("MENU");
            System.out.println("1.- Añadir usuarios");
            System.out.println("2.- Añadir libros");
            System.out.println("3.- Indicar péstamo");
            System.out.println("4.- Devolver péstamo");
            System.out.println("5.- Buscar libros");
            System.out.println("6.- Morosos");
            System.out.println("0.- Salir");
            opcion = scanner.nextLine();
            
            DB db = new DB();

            switch (opcion) {
                case "1":
                    System.out.println("No implementado");
                    break;
                case "2":
                    System.out.println("Introduce el titulo: ");
                    String titulo = scanner.nextLine();
                    System.out.println("Introduce el autor: ");
                    String autor = scanner.nextLine();
                    
                    db.addLibro(new Libro(0, titulo, autor));
                case "3":
                    
                    break;
                case "4":
                    
                    break;
                case "5":
                    
                    break;
                case "6":
                    
                    break;
                case "0":
                    System.out.println("BYE!! :D");
                    break;
                default:
                    System.out.println("Opcion no conocida");
            }
        } while (opcion != "0");
    }
    
}
