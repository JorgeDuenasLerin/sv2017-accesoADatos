package biblioteca;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Miguel Moya Ortega
 */
public class ListaLibro {

    List<Libro> misLibros;

    public ListaLibro() {
        misLibros = new ArrayList<>();
    }

    public void addLibro(Libro libr1) {
        misLibros.add(libr1);
    }

    public Libro searchLibro(String autor, String titulo) {
        Libro temp = null;
        for (Libro lib : misLibros) {
            if (lib.getAutor().equals(autor) && lib.getTitulo().equals(titulo)) {
                temp = lib;
            }
        }
        return temp;
    }

    public void AddLibro() {

    }

}
