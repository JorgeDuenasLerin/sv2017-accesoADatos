package biblioteca;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Miguel Moya Ortega
 */
public class DB {

    private String url;
    private String usuario;
    private String password;
    private Connection con;
    private String sentenciaSQL;
    private Statement statement;

    public DB() {
        try {
            Class.forName("org.postgresql.Driver");

            url = "jdbc:postgresql://localhost:5432/biblioteca";
            usuario = "postgres";
            password = "******";
            con = DriverManager.getConnection(url, usuario, password);

            sentenciaSQL = "create table libro("
                    + "id serial primary key,"
                    + "titulo varchar(30),"
                    + "autor varchar(30)"
                    + ");"
                    + "create table personas("
                    + "id serial primary key,"
                    + "nombre varchar(30),"
                    + "apellidos varchar(30),"
                    + "direccion varchar(40)"
                    + ");"
                    + "create table prestamos("
                    + "id serial primary key,"
                    + "fecha_ini DATE,"
                    + "fecha_fin DATE,"
                    + "fecha_dev DATE"
                    + ");";

            statement = con.createStatement();

            statement.executeUpdate(sentenciaSQL);

            statement.close();
        } catch (SQLException ex) {
            System.out.println("Error de SQL");
        } catch (ClassNotFoundException ex) {
            System.out.println("Clase no encontrada");
        }
    }

    public void CloseConnection() {
        try {
            con.close();
        } catch (SQLException ex) {
            System.out.println("No se ha podio cerrar");
        }
    }

    public boolean addPrestamo(Libro lib, Persona persona) {
        return false;
    }

    public void escribirTodosLibros() {
        try {
            sentenciaSQL = "SELECT * FROM libros";
            ResultSet rs = statement.executeQuery(sentenciaSQL);

            System.out.println(String.format("%-20s", "id")
                    + String.format("%-20s", "titulo")
                    + String.format("%-20s", "autor"));
            System.out.println("-------------------------------------"
                    + "-------------");
            while (rs.next()) {
                Libro l = new Libro(Integer.parseInt(rs.getString(1)), 
                        rs.getString(2), rs.getString(3));
                System.out.println(l);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error en la SQL");
        }
    }

    public boolean addLibro(Libro lib) {
        try {
            statement = con.createStatement();
            sentenciaSQL = "INSERT INTO libro VALUES "
                    + "('" + lib.getTitulo()
                    + "','" + lib.getAutor()
                    + ");";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            statement.close();
            if (cantidad == 0) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }
    

    public void searchLibro(String parametro)
    {
        Libro temp = null;
        try {
            Statement statement = con.createStatement();
            String sentenciaSQL="SELECT RPAD(id,10),RPAD(titulo,10),RPAD(autor,10) "
                + " FROM libro where titulo like "
                    +"'%"+parametro+"%'";
             ResultSet rs = statement.executeQuery(sentenciaSQL);
               System.out.println("id" + "\t" + "titulo"+"\t"+"autor"+"\t");
        while (rs.next()) {
            System.out.println(rs.getString(1) +
                        "\t " + rs.getString(2)+
                        "\t " + rs.getString(3)
            );
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public int getMorosos() {
        try {
            Statement statement = con.createStatement();
            String sentenciaSQL = "SELECT nombre, titulo, COUNT(cantidadMorosos)"
                    + "FROM libros l, personas p, prestamos pr";
            int cantidad = statement.executeUpdate(sentenciaSQL);
            
        } catch (Exception e) {
            e.getMessage();
        }
                
        return 0;

    }
}
