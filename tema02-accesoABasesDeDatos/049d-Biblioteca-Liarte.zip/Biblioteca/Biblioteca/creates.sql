create database biblioteca;

create table libro(
id serial primary key,
titulo varchar(30),
autor varchar(30)
);

create table personas(
id serial primary key,
nombre varchar(30),
apellidos varchar(30),
direccion varchar(40)
);

create table prestamos(
id serial primary key,
id_libro integer,
id_persona integer,
fecha_ini DATE,
fecha_fin DATE,
fecha_dev DATE
foreign key (id_libro) references libro(id),
foreing key( id_persona) references personas(id)
);

--Se añaden 3 personas porque en la v1, no hace falta añadir.
insert into personas(nombre, apellidos, direccion) values
('Antonio', 'Lorent', 'calle arboles');
	
insert into personas(nombre, apellidos, direccion) values
('Fabio', 'Lorente', 'calle perales');

insert into personas(nombre, apellidos, direccion) values
('Laura', 'Suarez', 'calle girasoles');


