
package biblioteca;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/*
@author Mario
*/
public class ExportarXML {
    private String nombreFichero;
    
    public ExportarXML(String nombreFichero)
    {
        this.nombreFichero = nombreFichero;
    }
    public void exportar(ArrayList<Libro> libros)
    {
        try
            {
                PrintWriter salidaXML = new PrintWriter(nombreFichero);
                salidaXML.println("<libros>");
                for(Libro lib : libros)
                {
                    salidaXML.println("    <libro>");
                    salidaXML.println("       <titulo>"+ lib.getTitulo()
                            + "</titulo>");
                    salidaXML.println("        <autor>" + lib.getAutor() + 
                            "</autor>");
                    salidaXML.println("        <paginas>" +lib.getNumPag() +
                            "</paginas>");
                    salidaXML.println("    </libro>");
                }
                salidaXML.println("</libros>");
                salidaXML.close();
            }
        catch(FileNotFoundException e)
        {
            System.out.println("Fichero no encontrado.");
        }
        catch(IOException e)
        {
            System.out.println("Error a la hora de escribir-");
        }
    }
}
