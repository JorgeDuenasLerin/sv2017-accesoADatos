/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author antonio
 */

public class ListaLibros implements Serializable{
    private ArrayList<Libro> listaLibros;

    public ListaLibros(ArrayList<Libro> listaLibros) {
        this.listaLibros = listaLibros;
    }

    public ListaLibros() {
        listaLibros = new ArrayList<>();
    }

    public void add(Libro libro) {
        listaLibros.add(libro);
    }

    public void remove(Libro libro) {
        listaLibros.remove(libro);
    }

    public void serializar() {
        try {
            ArrayList<Libro> listaLibros2 = this.listaLibros;
            File fichero = new File("lista_de_libros.dat");
            FileOutputStream ficheroSalida = new FileOutputStream(fichero);
            ObjectOutputStream ficheroObjetos
                    = new ObjectOutputStream(ficheroSalida);
            ficheroObjetos.writeObject(listaLibros2);
            ficheroObjetos.close();
        } catch (FileNotFoundException i) {
            System.out.println("No se ha podido abrir el archivo");
        } catch (IOException e) {
            System.out.println("Problemas de entrada o salida");
        }
    }

    public void cargarLibros(){
        ArrayList<Libro> listaLibros2 = new ArrayList<>();
        try {
            File fichero = new File("lista_de_libros.dat");
            FileInputStream ficheroEntrada = new FileInputStream(fichero);
            ObjectInputStream ficheroObjetosEntrada
                    = new ObjectInputStream(ficheroEntrada);
            listaLibros2 = (ArrayList<Libro>) ficheroObjetosEntrada.
                    readObject();
            ficheroObjetosEntrada.close();

        } catch (FileNotFoundException i) {
            System.out.println("No se ha podido abrir el archivo");
        } catch (IOException e) {
            System.out.println("Problemas de entrada o salida");
        } catch (ClassNotFoundException ex) {
            System.out.println("No se ha encontrado la clase");
        } finally {
            this.listaLibros = listaLibros2;
        }
    }

    /**
     * @return the listaLibros
     */
    public ArrayList<Libro> getListaLibros() {
        return listaLibros;
    }

    /**
     * @param listaLibros the listaLibros to set
     */
    public void setListaLibros(ArrayList<Libro> listaLibros) {
        this.listaLibros = listaLibros;
    }

    public void muestraLibros() {
        this.listaLibros.forEach(e -> System.out.println(e));
    }
}
