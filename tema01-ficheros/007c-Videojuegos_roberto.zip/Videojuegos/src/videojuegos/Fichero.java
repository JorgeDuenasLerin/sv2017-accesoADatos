/*Clase fichero, donde guardamos el arrayList de Videojuegos*/
package videojuegos;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Fichero {

    String nombreFichero = null;
    ArrayList<Videojuego> list;
    //PrintWriter ficheroSalida;
    //BufferReader ficheroEntrada;

    public Fichero() {

    }

    public void guardarLista(String nombreFichero, ArrayList<Videojuego> lista) {
        try {
            PrintWriter fichSalida = new PrintWriter(nombreFichero);

            for (int juego = 0; juego < lista.size(); juego++) {
                String tit = lista.get(juego).getTitulo();
                String gen = lista.get(juego).getGenero();
                int ano = lista.get(juego).getAnyo();
                String plat = lista.get(juego).getPlataforma();
                String res = lista.get(juego).getResumen();

                fichSalida.println(tit + "-" + gen + "-" + ano + "-" + plat + "-" + res);
            }
            fichSalida.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarLista(String nombreFichero, ArrayList<Videojuego> lista) {
        if (new File(nombreFichero).exists()) {

            try {
                BufferedReader miFichero = new BufferedReader(
                        new FileReader(
                                new File(nombreFichero)));
                String linea;

                do {
                    linea = miFichero.readLine();
                    if (linea != null) {
                        //System.out.println(linea);

                        //String cadena = "Esto es una prueba.";
                        String[] campos = linea.split("-");
                        for (String campo : campos) {
                            Videojuego miVideojuego = new Videojuego(
                            campos[0],campos[1],Integer.parseInt(campos[2]),campos[3],campos[4]);
                            
                            lista.add(miVideojuego);
                        }
                    }
                } while (linea != null);
                miFichero.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("No existe ese fichero.");
        }
    }

}