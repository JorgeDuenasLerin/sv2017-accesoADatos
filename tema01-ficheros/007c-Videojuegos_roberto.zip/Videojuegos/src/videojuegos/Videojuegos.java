// Base de datos de videojuegos en un fichero de texto
// Roberto Garcia Marcos, Sergio Garcia Balsas, Alexandra Sanchez Alonso

package videojuegos;
import java.util.ArrayList;
import java.util.Scanner;

public class Videojuegos {

    public static void main(String[] args) {
        Videojuegos v = new Videojuegos();
        ArrayList<Videojuego> listaVideojuegos = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean exit = false;
        String option = "" ;
        
        do{
            MuestraMenu();
            option = sc.next();
            
            switch (option){
                case "1": 
                    v.IntroducirJuego(sc, listaVideojuegos);
                    break;
                case "2":
                    v.BuscarJuego(sc, listaVideojuegos);
                    break;
                case "3":
                    v.ModificarVideojuego(listaVideojuegos);
                    break;
                case "4": exit = true;
                    break;
                default: System.out.println("Opción no válida");
            }
        }
        while (!exit);
    }
    
    public static void MuestraMenu(){
        System.out.println("1. Añadir videojuego");
        System.out.println("2. Buscar videojuego");
        System.out.println("3. Modificar videojuego");
        System.out.println("4. Salir");
    }
    
    public void ModificarVideojuego(ArrayList listaVideojuegos){
        Scanner teclado = new Scanner (System.in);
        System.out.println("Titulo del videojuego que quiere modificar");
        String nuevonombre = "";
        /*
        for (int i = 0; i < listaVideojuegos.size() ; i++ )
        {
            if (!listaVideojuegos.get(i).)
            {
            } else {
                System.out.println ("Nombre antiguo "+
                    listaVideojuegos.get(i).getTitulo());
                System.out.println ("Introduzca nuevo nombre ");
                nuevonombre = teclado.next();

                listaVideojuegos.get(i).setTitulo(nuevonombre);
            }
        }
        */
    }
    
    public void IntroducirJuego(Scanner sc, ArrayList listaVideojuegos){
        System.out.println("Introduce el nombre: ");
        String nombre = sc.next();
        System.out.println("Genero: ");
        String genero = sc.next();
        System.out.println("Año: ");
        int anyo = sc.nextInt();
        System.out.println("Plataforma: ");
        String plataforma = sc.next();
        System.out.println("Descripcion: ");
        String descripcion = sc.next();
        
        //Añade el videjuego
        Videojuego videojuego = new Videojuego(
                nombre, genero, anyo, plataforma, descripcion);
        listaVideojuegos.add(videojuego);
        Fichero fich = new Fichero();
        fich.guardarLista("videojuegos.txt", listaVideojuegos);
    }
    
    public void BuscarJuego(Scanner sc, ArrayList listaVideojuegos){
        // TO DO
        
        System.out.println("Introduce el titulo: ");
        String titulo = sc.nextLine();
        /*
        for(int i = 0; i < listaVideojuegos.size(); i++){
            if(titulo == listaVideojuegos.get(i).toString(){
                
            }
        }
        */
    }
}
