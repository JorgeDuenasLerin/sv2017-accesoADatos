/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionlibros;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.jar.Attributes;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import jdk.internal.org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author abi
 */
public class Biblioteca implements Serializable {

    private String nombreFichero;
    private ArrayList<Libro> lista;

    public Biblioteca(String nombreFichero) {

        if (!new File(nombreFichero).exists()) {
            lista = new ArrayList<>();
        } else {
            FileInputStream fs;
            ObjectInputStream is;
            try {
                fs = new FileInputStream(nombreFichero);
                is = new ObjectInputStream(fs);
                lista = (ArrayList<Libro>) is.readObject();

            } catch (IOException e) {
                e.getMessage();
            } catch (ClassNotFoundException e) {
                e.getMessage();
            }
        }
    }
    public Biblioteca(){
        
    }

    public void add(Libro l) {
        lista.add(l);
    }
    public void guardar(){
        try {
            FileOutputStream fs = new FileOutputStream("biblioteca.dat");
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(lista);
            fs.close();
            os.close();

        } catch (IOException e) {
            e.getMessage();
        }
    }
    public void exportar() {
        String nombre = "fichero.xml";
        for (Libro libro : lista) {

            try {
                PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(nombre)));
                printWriter.println("<libros>");

                printWriter.println("<libro>");

                printWriter.println("<titulo>");
                printWriter.println(libro.getTitulo());
                printWriter.println("</titulo>");

                printWriter.println("<autor>");
                printWriter.println(libro.getAutor());
                printWriter.println("</autor>");

                printWriter.println("<paginas>");
                printWriter.println(libro.getNumPag());
                printWriter.println("</paginas>");

                printWriter.println("</libro>");

                printWriter.println("</libros>");
                printWriter.close();
            } catch (IOException e) {
                System.out.println("Error en la escritura");
            } catch (Exception e) {
                System.out.println("Error al guardar en el xml");
            }

            /*try {
            FileOutputStream fs = new FileOutputStream("biblioteca.dat");
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(lista);
            fs.close();
            os.close();

        } catch (IOException e) {
            e.getMessage();
        }*/
        }
    }

    

    public void listar() {
        if (lista.isEmpty()) {
            System.out.println("Inventario vacío");
        } else {
            System.out.println("Lista de libros: ");
            for (Libro l : lista) {
                int i = 1;
                System.out.println(i + " ~ " + l.toString());
                i++;
            }
        }
    }

    public String toXML() {
        StringBuilder sb = new StringBuilder();
        for (Libro l : lista) {
            sb.append(l.toXML());
        }

        return XML.tag("biblioteca", sb.toString());
    }

    public void exportarXML(String path) {
        try {
            PrintWriter p = new PrintWriter(path);

            p.write(toXML());
            p.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Biblioteca.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public static Biblioteca cargarXML(String path) {
        Biblioteca biblioteca = new Biblioteca();
        try {
            SAXParserFactory saxParserFactory
                    = SAXParserFactory.newInstance();
            SAXParser saxParser = saxParserFactory.newSAXParser();
            DefaultHandler manejadorEventos = new DefaultHandler() {
                String etiquetaActual = "";
                String contenido = "";
                String titulo;
                String autor;
                int paginas;

                public void startElement(String uri, String localName,
                        String qName, Attributes attributes)
                        throws SAXException {
                    etiquetaActual = qName;
                }
                public void characters(char ch[], int start, int length)
                         {
                    contenido = new String(ch, start, length);
                    switch(etiquetaActual)
                    {
                        case "titulo":
                            titulo = contenido;
                            break;
                        case "autor":
                            autor = contenido;
                            break;
                        case "paginas":
                            paginas = Integer.valueOf(contenido);
                            break;
                    }
                }

                public void endElement(String uri, String localName,
                        String qName)  {
                    if (qName == "libro") {
                        biblioteca.add(new Libro(titulo, autor, paginas));
                    }
                }
            };
            // Cuerpo de la función
            saxParser.parse("asignaturas.xml", manejadorEventos);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return biblioteca;
    }
    

}
