/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionlibros;

import java.io.Serializable;

/**
 *
 * @author alumno
 */
public class XML implements Serializable{
    static String XMLOpen(String content)
    {
        return "<" + content + ">";
    }
    
    static String XMLClose(String content)
    {
        return "<" + content + ">";
    }
    
    static String tag(String fName, String value)
    {
        return XMLOpen(fName) + "\n\t" + value + "\n" + XMLClose(fName);
    }
}