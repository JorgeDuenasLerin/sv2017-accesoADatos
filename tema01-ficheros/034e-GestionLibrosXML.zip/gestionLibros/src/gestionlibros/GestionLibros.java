/*
 * Hector Bordajandi Moleon
 * Abilio Reig Sancho
 * Iván Galán Pastor
 */
package gestionlibros;

import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author abi
 */
public class GestionLibros implements Serializable{

    /**
     * @param args the command line arguments
     */
    public static void mostrarMenu() {
        System.out.println("1. Añadir libro");
        System.out.println("2. Mostrar libros");
        System.out.println("3. Exportar datos");
        System.out.println("4. Cargar XML");
        System.out.println("4. Salir");
    }
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        Biblioteca b = new Biblioteca("biblioteca.dat");
        String opcion="";

        do {
            mostrarMenu();
            System.out.println("Introduce una opcion: ");
            opcion = sc.nextLine();

            switch (opcion) {

                case "1":
                    System.out.println("Introduce el titulo: ");
                    String titulo = sc.nextLine();
                    System.out.println("Introduce el autor: ");
                    String autor = sc.nextLine();
                    System.out.println("Introduce numero de paginas: ");
                    int numPag = sc.nextInt();
                    Libro l = new Libro(titulo, autor, numPag);
                    b.add(l);
                    b.guardar();
                    break;

                case "2":
                    System.out.println("Lista de libros: ");
                    b.listar();
                    break;
                    
                case "3": 
                    System.out.println("Exportando...");
                    b.exportarXML("exportador.xml");
                    System.out.println("Completado");
                    b.exportar();
                    break;

                case "4":
                    System.out.println("Fin del programa");
                    break;
                case "5":
                    Biblioteca.cargarXML("fichero.xml");
                default:
                    break;
            }
        } while (!"5".equals(opcion));

    }

}
