//serializar libros y exportar en xml
/*Azahara, Alexandra, Juan */
package mibiblioteca;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 *
 * @author Sandra
 */
public class MiBiblioteca {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        boolean salir = true;
        File file = new File("Biblioteca.xml");
        //Serializador serial = new Serializador("Biblioteca.dat");
        Libro miLibro;
        Biblioteca libros = new Biblioteca();

        if (file.exists()) {//si existe el fichero cargo
            cargar(libros);
        }
        String opcion = "";
        do {
            System.out.println("MENU");
            System.out.println("1.- añadir libro ");
            System.out.println("2.- mostrar biblioteca");

            System.out.println("3.- Salir");
            opcion = teclado.nextLine();

            switch (opcion) {
                case "1":

                    System.out.print("titulo: ");
                    String titulo = teclado.nextLine();
                    System.out.print("autor: ");
                    String autor = teclado.nextLine();
                    System.out.print("pags: ");
                    String pags = teclado.nextLine();

                    libros.add(new Libro(titulo, autor, pags));
                    //serial.serializar(libros);//serializo
                    guardar(libros.getLibros());

                    break;
                case "2":
                    System.out.println("LIBROS");

                    for (Libro libro : libros.getLibros()) {

                        System.out.println(libro.toString());
                    }

                    break;
                case "3":
                    System.out.println("Saliendo...\n\n");
                    guardar(libros.getLibros());//xml exportar
                    salir = false;
                    break;
                default:
                    System.out.println("Opcion incorrecta\n\n");
                    break;
            }
        } while (salir);
    }

    static void guardar(ArrayList<Libro> lista) {
        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // elemento raiz
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("libros");
            doc.appendChild(rootElement);

            for (Libro l : lista) {
                Element libro = doc.createElement("libro");
                rootElement.appendChild(libro);

                //
                Element titulo = doc.createElement("titulo");
                titulo.appendChild(doc.createTextNode(l.getTitulo()));
                libro.appendChild(titulo);

                Element autor = doc.createElement("autor");
                autor.appendChild(doc.createTextNode(l.getAutor()));
                libro.appendChild(autor);

                Element pags = doc.createElement("pags");
                pags.appendChild(doc.createTextNode(l.getPags()));
                libro.appendChild(pags);
            }
            //
            // escribimos el contenido en un archivo .xml
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("biblioteca.xml"));

            transformer.transform(source, result);

            System.out.println("File saved!");

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }

    }

    static void cargar(Biblioteca libros) {
        try {
            File inputFile = new File("biblioteca.xml");
            DocumentBuilderFactory dbFactory
                    = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("libros");
            System.out.println();

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                Element eElement = (Element) nNode;

                /*System.out.println("Titulo: " 
                        + eElement.getAttribute("titulo"));
                    System.out.println("Autor: " 
                        + eElement.getElementsByTagName("autor")
                        .item(0).getTextContent());
                    System.out.println("Paginas: " 
                        + eElement.getElementsByTagName("pags")
                        .item(0).getTextContent());
                    
                    System.out.println(); */
                libros.add(
                        new Libro(eElement.getElementsByTagName("titulo")
                                .item(0).getTextContent(),
                                eElement.getElementsByTagName("autor")
                                        .item(0).getTextContent(), eElement.getElementsByTagName("pags")
                                .item(0).getTextContent()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
