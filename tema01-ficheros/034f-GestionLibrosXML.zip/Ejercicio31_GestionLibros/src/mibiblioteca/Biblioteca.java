/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mibiblioteca;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Sandra
 */
public class Biblioteca  implements Serializable{
    private ArrayList<Libro> libros;
    
    public Biblioteca(){
         libros= new ArrayList<>();
    }

    public ArrayList<Libro> getLibros() {
        return libros;
    }

    public void add(Libro libro) {
        libros.add(libro);
    }
}
