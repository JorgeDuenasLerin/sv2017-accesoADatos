/* Esta clase es el serializador...*/
package mibiblioteca;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Serializador {

    File fichero;
    ObjectInputStream ficheroObjetos2;

    public Serializador() {
        fichero = new File("Biblioteca.dat");//para este ejercicio
    }

    public Serializador(String fichero) {
        this.fichero = new File(fichero);//puedo decirle el fichero
    }

    public void serializar(Object o) {
        try {
            ObjectOutputStream ficheroObjetos = new ObjectOutputStream(
                    new FileOutputStream(fichero));//añadir

            ficheroObjetos.writeObject(o);//lo serializo
            ficheroObjetos.close();//cierro fichero

            System.out.println("Objeto serializado...\n");

        } catch (Exception e) {
            System.out.println("Error, " + e.getMessage());
        }
    }

    public Object deserializar() {
        Object o = null;
        try {
            ObjectInputStream ficheroObjetos2 = new ObjectInputStream(
                    new FileInputStream(fichero));

            o = ficheroObjetos2.readObject();

            System.out.println("Objeto deserializado...\n");
            ficheroObjetos2.close();//cierro fichero
            return o;
            

        } catch (Exception e) {
            System.out.println("Error, " + e.getMessage());
        }
        return o;
    }

    
}
