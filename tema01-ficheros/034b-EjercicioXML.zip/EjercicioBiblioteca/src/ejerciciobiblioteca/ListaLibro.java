/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciobiblioteca;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *Antonio Defez
Fernando carbonell
 * @author Usuario
 */
public class ListaLibro implements Serializable {
     protected ArrayList<Libro> miLista;
    
    public ListaLibro()
    {
        miLista=new ArrayList<>();
    }
    
    public void add(Libro juego)
    {
        miLista.add(juego);
    }
    
    public Libro get (int indice)
    {
        return miLista.get(indice);
    }
    
    public int Count()
    {
        return miLista.size();
    }
    
    /*Busca un juego en funcion de su titulo y de su nombre*/
    public Libro BuscarLibro(String nombre, String autor)
    {
        Libro temp = null;
        for(Libro v1 : miLista)
        {
            if(v1.getTitulo().equals(nombre) 
               && v1.getAutor().equals(autor))
            {
               temp = v1;
            }
        }
        return temp;
    }
    
    /*Actualiza el juego antiguo con el nuevo*/
    public void update(Libro v_viejo,Libro v_nuevo)
    {
        int pos=buscarPosicion(v_viejo);
        if(pos > -1)
        {
            miLista.set(pos, v_nuevo);
        }
    }
    
    public int buscarPosicion(Libro v1)
    {
        int cont=0;
        for(Libro v : miLista)
        {
            if(v.equals(v1))
            {
            return cont;
            }
            cont++;
        }
        return -1;
    }
}
