/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciobiblioteca;

import java.io.Serializable;

/**
 *Antonio Defez
Fernando carbonell
 * @author Usuario
 */
public class Libro  implements Serializable {
    private String titulo;
    private String autor;
    private int numPaginas;
    
    public Libro(String titulo, String autor, int numPaginas) {
        this.titulo = titulo;
        this.autor = autor;
        this.numPaginas = numPaginas;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }
    
        /*Formato de guardado en la fichero*/

    
    /*Formato para mostrar por pantalla*/
    public void MostrarDatos()
    {
        System.out.println("Titulo->"+titulo);
        System.out.println("Autor->"+autor);
        System.out.println("Numero de Paginas->"+numPaginas);
    }
}
