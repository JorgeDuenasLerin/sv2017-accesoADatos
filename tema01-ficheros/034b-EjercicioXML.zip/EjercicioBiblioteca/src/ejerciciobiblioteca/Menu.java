/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciobiblioteca;

/**
 *
 * @author Usuario
 */

/*
Antonio Defez
Fernando carbonell
Clase que administra el menu y la gestion del la clase listaVideojuegos
*/

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
public class Menu 
{
    protected ListaLibro miLista;
    protected Fichero miFichero;
    
    public Menu() throws IOException, FileNotFoundException,
            ClassNotFoundException
    {
        miLista= new ListaLibro();
        miFichero=new Fichero("videojuego.dat");
        miLista=miFichero.load(miLista);
    }
    
    public void mostrarMenu()
    {
        System.out.println("Menu Videjuegos");
        System.out.println("1.Añadir Libro");
        System.out.println("2.Update Libro");
        System.out.println("3.Buscar Libro");
        System.out.println("4.Mostrar todos los Libro");
        System.out.println("5.Pasar a xml");
        System.out.println("6.salir");
        System.out.println("Introduce una opcion");
    }
    
   public void add() throws IOException
    {
        Scanner entrada=new Scanner(System.in);
        String titulo,autor;
        int numPaginas;
        System.out.println("Añadiendo nuevo Libro");
        System.out.println("Introduce Titulo");
        titulo=entrada.nextLine();
        System.out.println("Introduce autor");
        autor=entrada.nextLine();
        System.out.println("Introduce numero de paginas");
        numPaginas=entrada.nextInt();

        
        Libro v1= new Libro(titulo,autor,numPaginas);
        miLista.add(v1);
        miFichero.save(miLista);
    }
    
    /*Metodo auxiliar para update y search*/
    public Libro search1()
    {
        String titulo,autor;
        Libro v1;
        Scanner entrada=new Scanner(System.in);
        System.out.println("Introduce titulo y autor para buscar juego");
        System.out.println("Introduce titulo");
        titulo=entrada.nextLine();
        System.out.println("Introduce autor");
        autor=entrada.nextLine();
        v1 = miLista.BuscarLibro(titulo, autor);
        return v1;
    }
    
    public void update() throws IOException
    {
        
        String titulo;
        String autor;
        int numPag;
        String pag;
        boolean modificar ;
        Scanner entrada = new Scanner(System.in);
        Libro v1 = search1();
        Libro vtemp;
        
        if(v1 == null )
        {
            System.out.println("El juego no existe");
        }
        else
        {
            System.out.println("Este el juego que quieres modificar?(true/false)");
            v1.MostrarDatos();
            modificar = entrada.nextBoolean();
            
            if(!modificar)
            {
                System.out.println("El juego no ha sido modificado");
            }
            else
            {
                entrada.nextLine();
                System.out.println("Intro para no modificar");
                
                System.out.println("Introduce nuevo titulo");
                titulo=entrada.nextLine();
                if(titulo.equals(""))
                    titulo=v1.getTitulo();
                
                System.out.println("Introduce nuevo autor");
                autor=entrada.nextLine();
                if(autor.equals(""))
                    autor=v1.getAutor();
                
                
                
                System.out.println("Introduce nueva descripcion");
                pag=entrada.nextLine();
                if(pag.equals(""))
                    numPag=v1.getNumPaginas();
                else
                    numPag = Integer.parseInt(pag);
                vtemp = new Libro(titulo,autor,numPag);
                miLista.update(v1, vtemp);
               
                miFichero.save(miLista);
            }
            System.out.println("Introduce nueva plataforma");
        }
    }
    
    /*Mostrar datos provisionales*/
    public void mostrarTodos()
    {
        System.out.println("-----------------");
        for(int i=0; i<miLista.Count();i++)
        {
            if(miLista.get(i)!=null)
            {
               
               miLista.get(i).MostrarDatos();
               System.out.println("-----------------");
            }
        }
    }
    
    public void search()
    {
        Libro v1 = search1();
        System.out.println("Mostrando datos");
        v1.MostrarDatos();
    }
    
    
    public void conversorXml()
    {
            try {
                PrintWriter fichEscritura = new PrintWriter("libros.xml");
                
                fichEscritura.println("<Biblioteca>");
                for(int i = 0 ; i<miLista.Count();i++ )
                {
                    Libro libro = miLista.get(i);
                fichEscritura.println("    <Libro>");
                fichEscritura.println("        <Titulo>"+libro.getTitulo()+"</Titulo>");
                fichEscritura.println("        <Autor>"+libro.getAutor()+"</Autor>");
                fichEscritura.println("        <Paginas>"+libro.getNumPaginas()+"</Paginas>");
                fichEscritura.println("    </Libro>");
                }
                fichEscritura.println("</Biblioteca>");
                fichEscritura.close();
            } 
            catch (Exception e) {
            }
        
    }

    
    public void pasarXml()
    {
        conversorXml();
    }
    public void run() throws IOException
    {
        boolean salida=false;
        String opcion;
        Scanner entrada=new Scanner(System.in);
        do
        {
            mostrarMenu();
            opcion=entrada.nextLine();
            
            switch(opcion)
            {
                case "1":
                    add();
                    break;
                case "2":
                    update();
                    break;
                case "3":
                    search();
                    break;
                case "4":
                    mostrarTodos();
                    break;
                case"5":
                    pasarXml();
                    break;
                 case "6":
                    salida=true;
                    break;
                default:
                    System.out.println("Opcion no valida");
                break;
            }
            
        }
        while(!salida);
        miFichero.save(miLista);
    }
    
}
