//Ejercicio nota:
//Mario Belso Ros
//Daniel Ossa
//Juan Salinas
package ficherosnota;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

class FicherosNota {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String opcion = "", opcion2 = "", titulo, genero, anyo,
                plataforma, resumen, coincidencia;
        ArrayList datos = new ArrayList();
        do {
            System.out.println(); // Espaciador.
            System.out.println("Este es el menu para el manejador de videojuegos.");
            System.out.println("1.- Añadir videojuego.");
            System.out.println("2.- Buscar videojuego.");
            System.out.println("3.- Modificar videojuego.");
            System.out.println("0.- Salir");
            System.out.println(); //Espaciador.
            System.out.println("Inserte una opción: ");
            opcion = sc.next();

            switch (opcion) {
                case "1":
                    //anyadirDatos(datos)
                    break;
                case "2":
                    buscar();
                    break;
                case "3":
                    System.out.println("Inserte el título del juego a modificar: ");
                    coincidencia = sc.next();
                    // for(int contador = 0; contador< )
                    break;
            }
        } while (!opcion.equals("0"));

    }

    static void anyadirDatos(String[] datos) {
        if (!(new File("juegos.txt")).exists()) {
            System.out.println("Fichero no encontrado.");
        } else {
            Scanner scan = new Scanner(System.in);

            System.out.print("Titulo: ");
            String titulo = scan.nextLine();

            System.out.print("Genero: ");
            String genero = scan.nextLine();

            System.out.print("Año: ");
            String anyo = scan.nextLine();

            System.out.print("Plataforma: ");
            String plataforma = scan.nextLine();

            System.out.print("Resumen: ");
            String resumen = scan.nextLine();

            datos[0] = titulo;
            datos[1] = genero;
            datos[2] = anyo;
            datos[3] = plataforma;
            datos[4] = resumen;

        }
    }

    static void actualizarFichero(ArrayList datos) {
        try {

            PrintWriter ficheroSalida = new PrintWriter("juegos.txt");
            for (int contador = 0; contador < datos.size(); contador++) {
                    System.out.println(datos.indexOf(0) + "//"+ datos.indexOf(1) +
                            "//" + datos.indexOf(2) + "//"+ datos.indexOf(3) + 
                            "//" + datos.indexOf(4));
                }
                
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void modificar(ArrayList datos) {
        if (!(new File("fichero.txt")).exists()) {
            System.out.println("Fichero no encontrado.");
        } else {
            Scanner scan = new Scanner(System.in);
            System.out.print("Titulo a modificar: ");
            String titulo = scan.nextLine();

            for (int i = 0; i < datos.size(); i++) {
                // if ( datos.indexOf(i)[0].equals(titulo) ) {

            }
        }

        try {
            PrintWriter fichero = new PrintWriter(
                    new BufferedWriter(
                            new FileWriter("fichero.txt", true)));

            //fichero.println(registro);
            fichero.println();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    static void buscar()
    {
        Scanner sc = new Scanner(System.in);
       
        if ( ! (new File("juegos.txt")).exists() ) {
            System.out.println("No se ha enconreado el fichero");
            return;
        }
       
        try {
            BufferedReader fichEntrada = new BufferedReader(
                new FileReader(new File("juegos.txt")));
           
            System.out.println("Selecciona la búsqueda por título (T) " +
                    "o por año (A)");
            char opcion = sc.next().charAt(0);
            String linea;
           
            switch (opcion) {
                case 't':
                case 'T':
                    System.out.println("Introduce el título del juego: ");
                    String titulo = sc.nextLine();
                   
                    linea = fichEntrada.readLine();
                    do {                        
                        if (linea.contains(titulo)) {
                            String[] datosTitulo = linea.split("//");
                            System.out.println("El videojuego es: ");
                            System.out.println("Título: " + datosTitulo[0]);
                            System.out.println("Género: " + datosTitulo[1]);
                            System.out.println("Año: " + datosTitulo[2]);
                            System.out.println("Plataforma: " + datosTitulo[3]);
                            System.out.println("Resumen: " + datosTitulo[4]);                          
                        }
                    }
                    while (linea != null);                    
                    break;
                   
                case 'a':
                case 'A':
                    System.out.println("Introduce el año del juego: ");    
                    String anio = sc.nextLine();
                   
                    linea = fichEntrada.readLine();
                    do {                        
                        if (linea.contains(anio)) {
                            String[] datosAnio = linea.split("//");
                            System.out.println("El videojuego es: ");
                            System.out.println("Título: " + datosAnio[0]);
                            System.out.println("Género: " + datosAnio[1]);
                            System.out.println("Año: " + datosAnio[2]);
                            System.out.println("Plataforma: " + datosAnio[3]);
                            System.out.println("Resumen: " + datosAnio[4]);
                        }
                    }
                    while (linea != null);
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
        }
        catch (IOException e) {
            System.out.println("Ha habido un error");
        }
    }
}

