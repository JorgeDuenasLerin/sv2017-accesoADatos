/*
Antonio Defez
Fernando carbonell
*/
package ejerciciobiblioteca;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Fichero 
{
    private static String nombrefich;
    
    public Fichero(String a)
    {
        nombrefich=a;
    }
    
    public static  ListaLibro load(ListaLibro lista)
            throws FileNotFoundException, IOException, ClassNotFoundException
    {
        File fich = new File(nombrefich);
        if(fich.exists())
        {   
            FileInputStream fichero_salida = new FileInputStream(fich);
            ObjectInputStream fichero_objeto = new ObjectInputStream(fichero_salida);
           
            lista = (ListaLibro)fichero_objeto.readObject();
            fichero_objeto.close();
        }
        else
        {
            System.out.println("No se han cargado los datos");
        }
        return lista;
    }
    
    public static void save(ListaLibro lista) throws FileNotFoundException,
            IOException
    {
           File fich = new File(nombrefich);
           FileOutputStream fichero_entrada = new FileOutputStream(fich);
            try (ObjectOutputStream fichero_objeto = 
                    new ObjectOutputStream(fichero_entrada)) 
            {
                fichero_objeto.writeObject(lista);
            }
            catch(Exception e)
            {
                System.out.println("eeror");
            }
    }
    
}
