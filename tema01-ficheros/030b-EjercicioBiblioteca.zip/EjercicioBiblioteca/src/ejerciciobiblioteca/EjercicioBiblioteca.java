/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciobiblioteca;

import java.io.IOException;

/**
 *
 * @author Usuario
 */
public class EjercicioBiblioteca {


    public static void main(String[] args) {
           Menu men;
        try {
            men = new Menu();
            men.run();
        } catch (IOException ex) {
            System.out.println("Error de entrada salida");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error de clase al guardar");
        }
    }
    
}
