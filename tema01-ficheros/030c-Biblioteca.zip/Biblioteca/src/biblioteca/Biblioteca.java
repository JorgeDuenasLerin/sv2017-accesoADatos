/* En este programa crearemos una biblioteca de libros, donde el usuario
podrá añadir y ver libros, así como poder exportar a formato XML.
Los cambios no se perderan, ya que usamos serialización.
 * Carla Liarte 
 Roberto Garcia Marcos
Sergio Garcia Balsas
 */
package biblioteca;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Biblioteca
{
    
    public static List <Libro> listalibros = new ArrayList<>();
    public static void menu()
    {
        System.out.println("1. Añadir libro");
        System.out.println("2. Mostrar todas");
        System.out.println("3. Exportar a XML");
        System.out.println("4. Salir");
    }
    
    public static void ExportarXml()
    {
        try{
            PrintWriter fichero = new PrintWriter ("libros.xml");
            fichero.println("<libros>");
            for(Libro l : listalibros){
                fichero.println("    <libro>");
                fichero.println("        <titulo>" +
                        l.getTitulo() + "</titulo>");
                fichero.println("        <autor>" +
                        l.getAutor() + "</autor>");
                fichero.println("        <numPag>" +
                        l.getNumPaginas() + "</numPag>");
                fichero.println("    </libro>");
            }
            fichero.println("</libros>");
            fichero.close ();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static void anadirLibro() 
    {
        Scanner teclado = new Scanner(System.in);
        String titulo="";
        String autor="";
        int paginas= 0;
        
        System.out.println("Titulo ?");
        titulo = teclado.nextLine();
        System.out.println("Autor ? ");
        autor = teclado.nextLine();
        System.out.println("Numero páginas ?");
        paginas = teclado.nextInt();
      
        
        Libro l = new Libro (titulo, autor, paginas);
        listalibros.add(l);
        try
        {
            //SERIALIZAMOS EL ARRAY
            File fichero = new File("libros.dat");
            FileOutputStream ficheroSalida = new FileOutputStream(fichero, false);
            ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida); 
            
            ficheroObjetos.writeObject(listalibros);
            
             ficheroObjetos.close();
             ficheroSalida.close();
        } 
        catch (FileNotFoundException ex)
        {
            System.err.println("Fichero no encontrado ");
        } 
        catch (IOException ex)
        {
           System.err.println("Excepcion Entrada salida ");
        }

        
    }
    
   
    
    public static void mostrarDatosSerializados()
    {
        try
        {
        File fichero = new File("libros.dat");
        FileInputStream ficheroSalida = new FileInputStream(fichero);
        ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroSalida);
        //DESERIALIZAMOS EL ARRAY
        List arrays = (ArrayList) ficheroObjetos.readObject();
        //AQUI GUARDO OTRA VEZ TODO EN MEMORIA!!!!! Y NO MACHACO!!!!!!!
        listalibros = arrays;
        
        for (int i = 0 ; i < arrays.size() ; i++)
        {
            System.out.println(arrays.get(i).toString());
        }
        
        ficheroSalida.close();
        ficheroObjetos.close();
        
        } 
        catch (FileNotFoundException ex)
        {
              System.err.println("Fichero no encontrado ");
        } 
        catch (IOException ex)
        {
            System.err.println("Error i/o ");
        } 
        catch (ClassNotFoundException ex)
        {
            System.err.println("Error de clase ");
        }
    }
    
    
    
    
    public static void main(String[] args)
    {
       Scanner teclado = new Scanner(System.in);
      
       boolean salir = false;
       String opcion="";
       do
       {
           menu();
           opcion = teclado.nextLine();
           switch (opcion)
           {
                case "1": //Añade un libro nuevo
                   anadirLibro();
                   break;
                case "2": //Muestra todo
                    mostrarDatosSerializados();
                    break;
                case "3":  //Exporta a XML
                        System.out.println("Exportando a XML....");
                        ExportarXml();
                break;
                case "4": //Salir
                    salir = true;
                    break;
                default: System.out.println("Número incorrecto");
                    break;
           }
           
       }
       while (!salir);
        System.out.println("Adios ! :) ");
    }
    
}
