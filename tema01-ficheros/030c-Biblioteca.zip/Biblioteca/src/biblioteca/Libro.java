/*
 *Clase libro del programa biblioteca
 */
package biblioteca;

import java.io.Serializable;

/**
 *
 * @author Usuario
 */
public class Libro implements Serializable
{
    private String titulo;
    private String autor;
    private int numPaginas;
    
    // Constructor
    public Libro(String titulo, String autor, int numPaginas){
        this.titulo = titulo;
        this.autor = autor;
        this.numPaginas = numPaginas;
    }
    // Getters y Setters
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public int getNumPaginas() {
        return numPaginas;
    }
    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }
    
    public String toString(){
        return "Titulo: " + this.titulo + ", " +
                "Autor: " + this.autor + ", " +
                "Num. Paginas: " + this.numPaginas;
    }
}
