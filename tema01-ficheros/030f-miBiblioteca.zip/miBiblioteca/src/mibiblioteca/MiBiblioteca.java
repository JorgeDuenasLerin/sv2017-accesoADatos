//serializar libros y exportar en xml
/*Azahara, Alexandra, Juan */
package mibiblioteca;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 *
 * @author Sandra
 */
public class MiBiblioteca {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        boolean salir = true;
        File file = new File("Biblioteca.dat");
        Serializador serial = new Serializador("Biblioteca.dat");
        Libro miLibro;
        Biblioteca libros = new Biblioteca();
        
        if (file.exists()) {//si existe el fichero cargo
            libros = (Biblioteca) serial.deserializar();
        }
        String opcion = "";
        do {
            System.out.println("MENU");
            System.out.println("1.- añadir libro ");
            System.out.println("2.- mostrar biblioteca");

            System.out.println("3.- Salir");
            opcion = teclado.nextLine();

            switch (opcion) {
                case "1":

                    System.out.print("titulo: ");
                    String titulo = teclado.nextLine();
                    System.out.print("autor: ");
                    String autor = teclado.nextLine();
                    System.out.print("pags: ");
                    String pags = teclado.nextLine();

                    libros.add(new Libro(titulo, autor, pags));
                    serial.serializar(libros);//serializo

                    break;
                case "2":
                    System.out.println("LIBROS");

                    for (Libro libro : libros.getLibros()) {

                        System.out.println(libro.toString());
                    }

                    break;
                case "3":
                    System.out.println("Saliendo...\n\n");
                    guardar(libros.getLibros());//xml exportar
                    salir = false;
                    break;
                default:
                    System.out.println("Opcion incorrecta\n\n");
                    break;
            }
        } while (salir);
    }
    static void guardar( ArrayList <Libro> lista){
        try {
                
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                
		// elemento raiz
                Document doc = docBuilder.newDocument();
                Element rootElement = doc.createElement("libros");
                doc.appendChild(rootElement);
                
                for(Libro l : lista){
                    Element libro = doc.createElement("libro");
                rootElement.appendChild(libro);

                //
                Attr attr = doc.createAttribute("titulo");
                attr.setValue(l.getTitulo());
                libro.setAttributeNode(attr);


                Element autor = doc.createElement("autor");
                autor.appendChild(doc.createTextNode(l.getAutor()));
                libro.appendChild(autor);


                Element pags = doc.createElement("pags");
                pags.appendChild(doc.createTextNode(l.getPags()));
                libro.appendChild(pags);
                }

                
 
                //
		// escribimos el contenido en un archivo .xml
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("biblioteca.xml"));
		
 
		transformer.transform(source, result);
 
		System.out.println("File saved!");
 
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		}
    
    }
    
}
