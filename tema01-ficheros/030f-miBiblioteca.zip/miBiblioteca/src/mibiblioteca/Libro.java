/* */
package mibiblioteca;

import java.io.Serializable;

public class Libro implements Serializable {
    private String titulo;
    private String autor;
    private String pags;
    
    public Libro(String titulo,String autor, String pags){
        this.titulo=titulo;
        this.autor=autor;
        this.pags=pags;
    }
    
    //metodo toString
    @Override
    public String toString(){
        return "Titulo: " + titulo + " Autor: " + " Numero paginas: " + pags;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getPags() {
        return pags;
    }

    public void setPags(String pags) {
        this.pags = pags;
    }
      
}
