/* Samuel Sergio Garcia Espinosa
 Antonia Sevila
 Carla Liarte
*/

package gestionvideojuegos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


class Videojuego
{
    private String titulo;
    private String genero;
    private String plataforma;
    private String resumen;
    private int anho;
    
    public Videojuego(String titulo, String genero, String plataforma,
        String resumen, int anho)
    {
        this.titulo = titulo;
        this.genero = genero;
        this.plataforma = plataforma;
        this.resumen = resumen;
        this.anho = anho;
    }
    
    public String getTitulo() { return titulo; }
    public String getGenero() { return genero; }
    public String getPlataforma() { return plataforma; }
    public String getResumen() { return resumen; }
    public int getAnyo() { return anho; }
}



public class GestionVideojuegos
{
    public static void guardarVideojuegos(
            ArrayList<Videojuego> listaVideojuegos)
    {

        try{
            PrintWriter fichero = new PrintWriter("videojuegos.txt");
        for(int posicionJuego = 0; posicionJuego < listaVideojuegos.size();
                posicionJuego++){
            fichero.print(listaVideojuegos.get(posicionJuego).getTitulo()+",");
            fichero.print(listaVideojuegos.get(posicionJuego).getGenero()+",");
            fichero.print(listaVideojuegos.get(posicionJuego).getAnyo()+",");
            fichero.print(listaVideojuegos.get(posicionJuego).getPlataforma()+",");
            fichero.println(listaVideojuegos.get(posicionJuego).getResumen());
        }
        fichero.close();
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
    
    public static void buscar(ArrayList<Videojuego> lista){
        Scanner entrada = new Scanner(System.in);
        int posicionJuego = 0;
        System.out.println("Introduce el titulo a buscar");
        String titulo = entrada.nextLine();
        for(Videojuego juego : lista){
            if( ! juego.getTitulo().equals(titulo)){
                posicionJuego++;
            }
            else{
                break;
            }
        }
        if(posicionJuego==lista.size()){
            System.out.println("Título no encontrado.");
        }
        else{
            System.out.println("Título: "+lista.get(posicionJuego).getTitulo());
            System.out.println("Género: "+lista.get(posicionJuego).getGenero());
            System.out.println("Año: "+lista.get(posicionJuego).getAnyo());
            System.out.println("Plataforma: "+lista.get(posicionJuego).getPlataforma());
            System.out.println("Resumen: "+lista.get(posicionJuego).getResumen());
        }
        
    }
    
    public static void modificar(String titulo, String genero, int anyo,
                String plataf, String resumen, ArrayList<Videojuego>lista){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Quieres modificar algun videojuego? S / N: ");
        String opcion = teclado.nextLine().toUpperCase();
        
        if(opcion.equals("S")){
            //titulo =
            String texto;
            int newAnyo=0;
            System.out.println("Titulo o intro para continuar: "+ titulo);
            texto = teclado.nextLine();
            if( ! texto.equals("")){
                titulo= texto;
            }
            
            System.out.println("Genero o intro para continuar: "+ genero);
            texto = teclado.nextLine();
            if( ! texto.equals("")){
                genero= texto;
            }
            
            System.out.println("Año o intro para continuar: "+ anyo);
            texto = teclado.nextLine();
            if( ! texto.equals("")){
                anyo= newAnyo;
            }
            
            System.out.println("Titulo o intro para continuar: "+ plataf);
            texto = teclado.nextLine();
            if( ! texto.equals("")){
                plataf= texto;
            }
            
            System.out.println("Titulo o intro para continuar: "+ resumen);
            texto = teclado.nextLine();
            if( ! texto.equals("")){
                resumen= texto;
            }  
        }
    }
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        int opcion;

        List<Videojuego> listaDeVideojuegos = new ArrayList();
        
        System.out.println("Bienvenido!");
        
        do
        {
            System.out.println("1. Añadir un nuevo videojuego");
            System.out.println("2. Modificar un videojuego");
            System.out.println("3. Buscar un videojuego");
            opcion = sc.nextInt();
            
            switch(opcion)
            {
                case 1:
                    
                    String nuevoTitulo;
                    String nuevoGenero;
                    String nuevaPlataforma;
                    String nuevoResumen;
                    int nuevoAnho;
                    
                    do
                    {
                        System.out.println("Introduce el titulo: ");
                        nuevoTitulo = sc.nextLine();
                        
                        System.out.println("Introduce su genero: ");
                        nuevoGenero = sc.nextLine();
                        
                        System.out.println("Introduce su plataforma: ");
                        nuevaPlataforma = sc.nextLine();
                        
                        System.out.println("Introduce un resumen: ");
                        nuevoResumen = sc.nextLine();
                        
                        System.out.println("Introduce su fecha de lanzamiento:");
                        nuevoAnho = sc.nextInt();

                        if ( ! nuevoTitulo.equals("") )
                        {
                            Videojuego videojuego = new Videojuego(nuevoTitulo, 
                                nuevoGenero, nuevaPlataforma, nuevoResumen,
                                nuevoAnho);
                        }
                        else
                            System.out.println("Introduzca un titulo valido");
                    }
                    while( nuevoTitulo.equals("") );
                    
                    break;
                    
                case 2:
                    
                    //modificar();
                    break;
                    
                case 3:
                    break;
            }
            
        }
        while( opcion != 0 );
    }
    
}
