//Mario Belso Ros
//Serializacion.
package serializacion;

import java.io.Serializable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Serializacion
{

    public static void main(String[] args)
            throws FileNotFoundException, IOException {
        File fichero = new File("videojuegos.dat");
        FileOutputStream ficheroSalida
                = new FileOutputStream(fichero);
        ObjectOutputStream ficheroObjetos
                = new ObjectOutputStream(ficheroSalida);
        VideoJuego v1 = new VideoJuego("Dark Souls", "RPG", 2012,"PC","Morir");
        ficheroObjetos.writeObject(v1);
        VideoJuego v2 = new VideoJuego("Dark Souls 2", "RPG", 2014, "PC",
        "Más morir");
        ficheroObjetos.writeObject(v2);
        ficheroObjetos.close();
    }
}
