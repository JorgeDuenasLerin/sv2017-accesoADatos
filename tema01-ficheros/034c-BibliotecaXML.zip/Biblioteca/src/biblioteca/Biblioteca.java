/* En este programa crearemos una biblioteca de libros, donde el usuario
podrá añadir y ver libros, así como poder exportar a formato XML.
Los cambios no se perderan, ya que usamos serialización.
 * Carla Liarte 
 Roberto Garcia Marcos
Sergio Garcia Balsas
 */
package biblioteca;

import com.sun.org.apache.xerces.internal.dom.DocumentImpl;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class Biblioteca
{
    
    public static List <Libro> listalibros = new ArrayList<>();
    public static void menu()
    {
        System.out.println("1. Añadir libro");
        System.out.println("2. Mostrar todas");
        System.out.println("3. Mostrar DOM XML");
        System.out.println("4. Cargar XML");
        System.out.println("5. Exportar a XML");
        System.out.println("6. Salir");
    }
    
    /*
     public static void mostrarLibros(){
        
        for(Libro libro: listalibros){
            System.out.println("Título: "+libro.getTitulo()+"-Autor: "
                    +libro.getAutor()+"-Número de páginas: "+libro.getNumPaginas());
        }
        
    }
*/
    
    public static void ExportarXml()
    {
        try{
            PrintWriter fichero = new PrintWriter ("libros.xml");
            fichero.println("<libros>");
            for(Libro l : listalibros){
                fichero.println("    <libro>");
                fichero.println("        <titulo>" +
                        l.getTitulo() + "</titulo>");
                fichero.println("        <autor>" +
                        l.getAutor() + "</autor>");
                fichero.println("        <numPag>" +
                        l.getNumPaginas() + "</numPag>");
                fichero.println("    </libro>");
            }
            fichero.println("</libros>");
            fichero.close ();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void CargarXML(Document xml) throws ParserConfigurationException, SAXException, IOException
    {
        String autor = xml.getElementsByTagName("autor").item(0).getTextContent();
        String titulo = xml.getElementsByTagName("titulo").item(0).getTextContent();
        String numpag = xml.getElementsByTagName("numPag").item(0).getTextContent();
    }
    
    public static void MostrarXMl(Document xml)
    {
        
        NodeList nList = xml.getElementsByTagName("libro");
                
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Titulo: "+ 
                            eElement.getAttribute("titulo"));
                    System.out.println("Autor: " + 
                            eElement.getElementsByTagName("autor").
                                    item(0).getTextContent());
                    System.out.println("Numerp Paginas: " + 
                            eElement.getElementsByTagName("numPag").
                                    item(0).getTextContent());
                    System.out.println("---------------------");
                }
            }
    }

    
    public static void anadirLibro() 
    {
        Scanner teclado = new Scanner(System.in);
        String titulo="";
        String autor="";
        int paginas= 0;
        
        System.out.println("Titulo ?");
        titulo = teclado.nextLine();
        System.out.println("Autor ? ");
        autor = teclado.nextLine();
        System.out.println("Numero páginas ?");
        paginas = teclado.nextInt();
      
        
        Libro l = new Libro (titulo, autor, paginas);
        listalibros.add(l);
        try
        {
            //SERIALIZAMOS EL ARRAY
            File fichero = new File("libros.dat");
            FileOutputStream ficheroSalida = new FileOutputStream(fichero, false);
            ObjectOutputStream ficheroObjetos = new ObjectOutputStream(ficheroSalida); 
            
            ficheroObjetos.writeObject(listalibros);
            
             ficheroObjetos.close();
             ficheroSalida.close();
        } 
        catch (FileNotFoundException ex)
        {
            System.err.println("Fichero no encontrado ");
        } 
        catch (IOException ex)
        {
           System.err.println("Excepcion Entrada salida ");
        }
    }
    
   
    
    public static void mostrarDatosSerializados()
    {
        try
        {
        File fichero = new File("libros.dat");
        FileInputStream ficheroSalida = new FileInputStream(fichero);
        ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroSalida);
        //DESERIALIZAMOS EL ARRAY
        List arrays = (ArrayList) ficheroObjetos.readObject();
        //AQUI GUARDO OTRA VEZ TODO EN MEMORIA!!!!! Y NO MACHACO!!!!!!!
        listalibros = arrays;
        
        for (int i = 0 ; i < arrays.size() ; i++)
        {
            System.out.println(arrays.get(i).toString());
        }
        
        ficheroSalida.close();
        ficheroObjetos.close();
        
        } 
        catch (FileNotFoundException ex)
        {
              System.err.println("Fichero no encontrado ");
        } 
        catch (IOException ex)
        {
            System.err.println("Error i/o ");
        } 
        catch (ClassNotFoundException ex)
        {
            System.err.println("Error de clase ");
        }
    }
    
    
    
    
    public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException
    {
       Scanner teclado = new Scanner(System.in);
      
       boolean salir = false;
       String opcion="";
       
       DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
       Document xml = dBuilder.parse(new File("libros.xml"));
       do
       {
           menu();
           opcion = teclado.nextLine();
           switch (opcion)
           {
                case "1": //Añade un libro nuevo
                   anadirLibro();
                   break;
                case "2": //Muestra todo
                    mostrarDatosSerializados();
                    break;
                    
                case "3": //Muestra todo
                  MostrarXMl(xml);
                  break;    
                    
               case "4": //Cargar XML
                   System.out.println("Todavia no");
                    break;    
               
                case "5":  //Exporta a XML
                        System.out.println("Exportando a XML....");
                        ExportarXml();
                break;
                case "6": //Salir
                    salir = true;
                    break;
                default: System.out.println("Número incorrecto");
                    break;
           }
           
       }
       while (!salir);
        System.out.println("Adios ! :) ");
    }
    
}
