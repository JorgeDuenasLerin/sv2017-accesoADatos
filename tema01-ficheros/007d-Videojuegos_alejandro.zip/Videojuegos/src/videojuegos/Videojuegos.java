
package videojuegos;


public class Videojuegos {

    public static void main(String[] args) {

    }
    
}
