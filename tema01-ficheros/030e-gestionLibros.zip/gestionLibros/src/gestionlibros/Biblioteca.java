/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionlibros;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abi
 */
public class Biblioteca {

    private String nombreFichero;
    private ArrayList<Libro> lista;

    public Biblioteca(String nombreFichero) {

        if (!new File(nombreFichero).exists()) {
            lista = new ArrayList<>();
        } else {
            FileInputStream fs;
            ObjectInputStream is;
            try {
                fs = new FileInputStream("biblioteca.dat");
                is = new ObjectInputStream(fs);
                lista = (ArrayList<Libro>) is.readObject();
            } catch (IOException e) {
                e.getMessage();
            } catch (ClassNotFoundException e) {
                e.getMessage();
            }
        }
    }

    public void add(Libro l) {
        lista.add(l);
    }

    public void guardarLibros() throws FileNotFoundException {
        try {
            FileOutputStream fs = new FileOutputStream("biblioteca.dat");
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(lista);
            fs.close();
            os.close();

        } catch (IOException e) {
            e.getMessage();
        }
    }

    public void mostrar() {
        for (Libro l : lista) {
            l.toString();
        }
    }

    public String toXML() {
        StringBuilder sb = new StringBuilder();
        for (Libro l : lista) {
            sb.append(l.toXML());
        }

        return XML.tag("biblioteca", sb.toString());
    }
    public void exportarXML(String path){
        try {
            PrintWriter p = new PrintWriter(path);
            
            p.write(toXML());
            p.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Biblioteca.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
