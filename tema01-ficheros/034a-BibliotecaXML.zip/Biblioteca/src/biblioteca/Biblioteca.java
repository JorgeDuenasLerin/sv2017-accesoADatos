/*
 * Antonio Sevila, Mario Belso y Miguel Moya
 */
package biblioteca;

import java.util.Scanner;

public class Biblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean finish = false;
        Scanner scanner = new Scanner(System.in);
        byte opcion;

        while (!finish) {
            mostrarOpciones();
            opcion = scanner.nextByte();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    System.out.println("Escribe el titulo:");
                    String titulo = scanner.nextLine();

                    System.out.println("Escribe el autor:");
                    String autor = scanner.nextLine();

                    System.out.println("Escribe el numero de páginas");
                    int n = scanner.nextInt();
                    scanner.nextLine();

                    Dom.guardarXML(titulo, autor, n);
                    Dom.escribirXML();

                    break;
                case 2:
                    Dom.leer();
                    break;
                /*case 3:
                    Dom.escribirXML();
                    break;*/
                case 0:
                    finish = true;
                    break;
                default:
                    System.out.println("Opción desconocida.");
                    break;
            }
        }
    }

    public static void mostrarOpciones() {
        System.out.println("¿Qué opción vas a usar?");
        System.out.println("    1) Añadir un libro.");
        System.out.println("    2) Mostrar todos.");
        //System.out.println("    3) Exportar a XML.");
        System.out.println("    0) Salir.");
    }

}
