package biblioteca;

import java.io.BufferedWriter;
import java.io.File;
<<<<<<< HEAD
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
=======
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
>>>>>>> 2685ccac631ac90ad8d52cf8953fa953fe9cb125
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author Miguel Moya Ortega
 */


public class Dom {

    public static void leer() {
        try {

            File inputFile = new File("libros.xml");
            DocumentBuilderFactory dbFactory
                    = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("libro");

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Titulo: "
                            + eElement.getElementsByTagName("titulo")
                                    .item(0).getTextContent());
                    System.out.println("Autor: "
                            + eElement.getElementsByTagName("autor")
                                    .item(0).getTextContent());
                    System.out.println("Páginas: "
                            + eElement.getElementsByTagName("paginas")
                                    .item(0).getTextContent());
                    System.out.println();
                }
            }
        } catch (Exception e) {
            System.out.println("Excepcion encontrada.");
        }

    }

    public static void guardarXML2(String titulo, String autor, byte n) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File inputFile = new File("libros.xml");
            DocumentBuilderFactory dbFactory
                    = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            org.w3c.dom.Document dom = dBuilder.parse(inputFile);

            NodeList libros = dom.getElementsByTagName("libro");
            for (int i = 0; i < libros.getLength(); i++) {
                Element libro = (Element) libros.item(i);

                Element titulos = dom.createElement("titulo");
                titulos.setTextContent(titulo);
                libro.appendChild(titulos);

                Element autors = dom.createElement("autor");
                autors.setTextContent(autor);
                libro.appendChild(autors);

                Element paginas = dom.createElement("paginas");
                paginas.setTextContent(n + "");
                libro.appendChild(paginas);

            }
        } catch (IOException e) {
            System.out.println("No se ha podido guardar");
        } catch (ParserConfigurationException ex) {
            System.out.println("Error");
        } catch (SAXException ex) {
            System.out.println("Error");
        }
    }

    

    public static void guardarXML(String titulo, String autor, int numPag) {
        try {
            PrintWriter salida = new PrintWriter(new BufferedWriter(
                    new FileWriter("libros.xml")));

            salida.println("<libro>");
            salida.println("<titulo>" + titulo + "</titulo>");
            salida.println("<autor>" + autor + "</autor>");
            salida.println("<numPag>" + numPag + "</numPag>");
            salida.println("</libro>");
            salida.close();
        } catch (IOException e) {
            System.out.println("Probelmas");
        }

    }

    public static void escribirXML() {

    }
;
}
