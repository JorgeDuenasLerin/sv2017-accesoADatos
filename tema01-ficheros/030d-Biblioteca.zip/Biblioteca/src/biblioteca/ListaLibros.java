/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author usuario
 */
public class ListaLibros implements Serializable{
    
    protected List<Libro> listaLibros;
   
    public ListaLibros() {
        listaLibros = new ArrayList<>();
    }
   
    public void nuevoLibro (Libro newLibro ) {
        listaLibros.add(newLibro);
        guardarLista();
    }
   
    public void borrarLibro (Libro borrarLibro ) {
        listaLibros.remove(borrarLibro);
        this.guardarLista();
    }
   
    public void cargarLista() {
       
        try {
            File fichero = new File("libros.dat");
            FileInputStream ficheroEntrada =
                new FileInputStream(fichero);
            ObjectInputStream ficheroLibros =
                new ObjectInputStream(ficheroEntrada);
 
            Libro libro = null;
 
            do {
                libro = (Libro) ficheroLibros.readObject();
                if ( libro != null ) {
                    nuevoLibro(libro);
                }
            }while ( libro != null );
        }
        catch ( IOException e ) {
            System.out.println("Error!");
        }
        catch (ClassNotFoundException ex) {    
            System.out.println("Clase no encontrada");
        }
    }
   
    public void guardarLista() {
        try {
            File fichero = new File("libros.dat");
            FileOutputStream ficheroSalida =
                new FileOutputStream(fichero);
            ObjectOutputStream ficheroLibros =
                new ObjectOutputStream(ficheroSalida);
                       
            /*for ( Libro libro : listaLibros )  {
                ficheroLibros.writeObject(libro);
            }*/
            
            ficheroLibros.writeObject(listaLibros);         
           
            ficheroLibros.close();
        }
        catch ( IOException e ) {
            System.out.println("Error!");
        }
    }
    
    public void mostrarLibros(){
        
        for(Libro libro: listaLibros){
            System.out.println("Título: "+libro.getTitulo()+"-Autor: "
                    +libro.getAutor()+"-Número de páginas: "+libro.getNumPag());
        }
        
    }
    
    public void exportarLista() {
        try {
            PrintWriter ficheroExportado = new PrintWriter(
                "biblioteca_exportada.xml");
            ficheroExportado.println("<biblioteca>");
           
            for ( Libro libro : listaLibros ) {
                ficheroExportado.println("<libro>");
                ficheroExportado.println(
                        "<titulo>" + libro.getTitulo() + "</titulo>");
                ficheroExportado.println(
                        "<autor>" + libro.getAutor() + "</autor>");
                ficheroExportado.println(
                        "<numpag>" + libro.getNumPag() + "</numpag>");
                ficheroExportado.println("</libro>");
            }
            ficheroExportado.println("</biblioteca>");
       
            ficheroExportado.close();
        }
        catch ( IOException e) {
            e.printStackTrace();
        }
    }
}
