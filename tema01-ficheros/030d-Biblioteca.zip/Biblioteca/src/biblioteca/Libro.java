/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

/**
 *
 * @author usuario
 */
public class Libro {
 
    private String titulo;
    private String autor;
    private int numPag;
   
    public Libro (String titulo,String autor, int numPag) {
       
        this.titulo = titulo;
        this.autor = autor;
        this.numPag = numPag;
       
    }
   
    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }
 
    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
 
    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }
 
    /**
     * @param autor the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }
 
    /**
     * @return the numPag
     */
    public int getNumPag() {
        return numPag;
    }
 
    /**
     * @param numPag the numPag to set
     */
    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }
   
}