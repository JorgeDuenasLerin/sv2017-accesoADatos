//Gestor videojuegos
//Javier Montejo, Fernando Carbonel, Azahara Carbonel
package gestorVideojuegos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

class fichero {
    public void leer(Videojuego lista){
            
            if ( ! (new File("listaDeVideojuegos.txt")).exists()) {
                System.out.println("Error no se ha encotrado la base de datos");
            }
            else{

                try {
                    BufferedReader fichLectura = new BufferedReader(
                            new FileReader(new File("listaDeVideojuegos.txt")));

                    String linea = fichLectura.readLine();
                    while (linea != null) {
                        lista.add(linea);
                    }
                } 
                catch (Exception e) {
                }
            }
        }
        
        public void guardar(Videojuego lista){
            
            Scanner sc = new Scanner(System.in);
            String nomFichLectura = sc.nextLine();


            if ( ! (new File(nomFichLectura)).exists()) {
                System.out.println("Error no se ha encotrado la base de datos");
            }
            else{

                try {
                    PrintWriter fichEscritura = new PrintWriter(
                            "listaDeVideojuegos.txt");
                    
                    for (int i = 0; i < lista.length; i++) {
                     //   fichEscritura.print();
                    }
                } 
                catch (Exception e) {
                }
            }      
        }
}
