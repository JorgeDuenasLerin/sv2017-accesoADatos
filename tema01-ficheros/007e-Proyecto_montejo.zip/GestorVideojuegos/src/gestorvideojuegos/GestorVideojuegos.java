//Gestor videojuegos
//Javier Montejo, Fernando Carbonel, Azahara Carbonel
package gestorvideojuegos;

import java.util.Scanner;

public class GestorVideojuegos {
    
    public static void main(String[] args) {
        
        boolean control = false;
        Scanner s = new Scanner(System.in);
        
        System.out.println("GESTOR DE VIDEOJUEGOS");
        System.out.println("");
        System.out.println("1.Añadir");
        System.out.println("2.Buscar");
        System.out.println("3.Modificar");
        System.out.println("X.Salir");
        
        //metodo mostrar de la lista
        
        do{
            String opcion = s.nextLine();
            
            switch (opcion) {
                
                case "1" : System.out.println("Proximamente"); 
                    control = true;
                    break;
                case "2" : System.out.println("Proximamente"); 
                    control = true;
                    break;
                case "3" : System.out.println("Proximamente"); 
                    control = true;
                    break;
                
                default : System.out.println("Escoje una opcion valida");
                    break;
        }  
                    
        }while (!control);
        
        
        
    }
    
}
