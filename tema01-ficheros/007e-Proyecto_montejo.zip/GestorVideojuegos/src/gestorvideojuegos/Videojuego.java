//Gestor videojuegos
//Javier Montejo, Fernando Carbonel, Azahara Carbonel
package gestorvideojuegos;

/**
 *
 * @author Montejeitor
 */
class Videojuego {
    protected String titulo;
    protected String genero;
    protected String anyo;
    protected String plataforma;
    protected String descripcion;
    
    public Videojuego(String titulo,String genero,String anyo,String p,String d){
        this.titulo=titulo;
        this.genero=genero;
        this.anyo=anyo;
        this.plataforma=plataforma;
        this.descripcion=descripcion;
    }
    public void Mostrar(){
        System.out.println("Titulo:"+titulo);
        System.out.println("Genero:"+genero);
        System.out.println("Año:"+anyo);
        System.out.println("Plataforma:"+plataforma);
        System.out.println("Descripcion:"+descripcion);
    }
    public String GetTitulo(){
        return titulo;
    }
    public void SetTitulo(String titulo){
        this.titulo=titulo;
    }
    public String GetGenero(){
        return genero;
    }
    public void SetGenero(String genero){
        this.genero=genero;
    }
    public String GetAnyo(){
        return anyo;
    }
    public void SetAnyo(String anyo){
        this.anyo=anyo;
    }
    public String GetPlataforma(){
        return plataforma;
    }
    public void SetPlataforma(String plataforma){
        this.plataforma=plataforma;
    }
    public String GetDescripcion(){
        return descripcion;
    }
    public void SetDescripcion(String descripcion){
        this.descripcion=descripcion;
    }
}
