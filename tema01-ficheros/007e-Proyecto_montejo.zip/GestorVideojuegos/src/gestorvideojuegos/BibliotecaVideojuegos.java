
package gestorvideojuegos;

import java.util.ArrayList;

public class BibliotecaVideojuegos {
    
    public void listado () {
    ArrayList <Videojuego> listaJuegos=new ArrayList<>();
        
        fichero.guardar(listaJuegos);
}
}
