/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abmvideojuegos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Inventory {
    
    ArrayList<Videogame> storage = new ArrayList<>();
    String fileName;
    
    public Inventory(){
        
    }
    
    public void add(Videogame v){
        storage.add(v);
    }
    public void find(String name){
        
        for (Videogame v : storage){
            if (v.title == name)
            {
                System.out.println(v);
            }
        }
    }
    
    public void list(){
        System.out.println("List of videogames: ");
        int i=0;
        for (Videogame v: storage){
            System.out.println("----------");
            System.out.println(i+1 + v.toString());
            System.out.println("----------");
        }
    }
}
