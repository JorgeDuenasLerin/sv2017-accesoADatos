/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abmvideojuegos;

/**
 *
 * @author Usuario
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

 *
 * @author alumno
 */
public class Videogame {
    String title;
    String genre;
    int year;
    String platform;
    String resume;

    public Videogame(String title, String genre, int year, String plaform, String resume) {
        this.title = title;
        this.genre = genre;
        this.year = year;
        this.platform = plaform;
        this.resume = resume;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getPlaform() {
        return platform;
    }

    public void setPlaform(String plaform) {
        this.platform = plaform;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
    
    @Override
    public String toString(){
        return String.
                format("%-20s%-10s%-5d%-15s%s", title, genre, year, platform, resume);
    }
}
