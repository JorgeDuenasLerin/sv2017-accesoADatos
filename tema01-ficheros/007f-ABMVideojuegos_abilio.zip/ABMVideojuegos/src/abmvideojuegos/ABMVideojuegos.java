/*
Antonio Defz
Abilio Reig Sancho
Hector Bordajandi
*/
package abmvideojuegos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.IOException;

public class ABMVideojuegos {
    
    Inventory inventory=new Inventory();
    private String file_game;
  
    public static void showMenu()
    {
        System.out.println("1.Add videogame");
        System.out.println("2.Search videogame");
        System.out.println("3.Update videogame");
        System.out.println("4.Exit videogame");
    }
    
    public static void load()
    {
        /*Formato de guardado | entre cada campo */
        String[]values;
        String fich="videogame.txt";
        try 
        {
            BufferedReader input_file = new BufferedReader(
            new FileReader(new File(fich)));
            String line = input_file.readLine();
            while (line != null) 
            {
                line = input_file.readLine();
                if(line!=null)
                {
                    values=line.split("|");
                    Videogame videojuego = new Videogame(
                                                        values[0],
                                                        values[1],
                                                        Integer.valueOf(values[2]),
                                                        values[3],
                                                        values[4]);
                  //  inventory.add(videojuego);
                    
                }
            }
            input_file.close();
        }
        catch (IOException errorDeFichero) 
        {
            System.out.println(
            "Ha habido problemas: " +
                errorDeFichero.getMessage() );
        }

    }
    public static void save()
    {
      
    String frase="";

        Scanner entrada = new Scanner(System.in);
        try 
        {
            //constructor para añadir texto
            PrintWriter fichero = new PrintWriter("videogame.txt");
            
            //for

            fichero.close();
        }

        catch(FileNotFoundException e) 
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
             e.printStackTrace();
        }
    }
    
    public static void add()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Title: ");
        String name = s.nextLine();
        
        System.out.println("Genre: ");
        String genre = s.nextLine();
        
        System.out.println("Year: ");
        int year = s.nextInt();
        
        System.out.println("Platform: ");
        String platform = s.nextLine();
        
        System.out.println("Resume: ");
        String resume = s.nextLine();
       
        Videogame v = new Videogame(name, genre, year, platform, resume);
        
        //      Collection.add(v);
    }
    
    public static void search()
    {
        //b
    }
    
    public static void update()
    {

        Scanner s = new Scanner(System.in);
        Collection.list();
        System.out.println("Videogame modified position: ");
        int index = s.nextInt();
        
        Collection.set(index, readVideogame());
        //despues de modificar guardamos en fichero
        save();
    
        save();
    }
    public static void main(String[] args) 
    {
        
        Scanner input=new Scanner(System.in);
        String option;
        boolean exit=false;
        do
        {
            showMenu();
            option=input.nextLine();
            switch(option)
            {
                case "1":
                    add();
                    break;
                case "2":
                    search();
                    break;
                case "3":
                    update();
                    break;
                case "4":
                    exit=true;
                    break;
                default:
                    System.out.println("Option not valid");
                    break;
            }
            
        }
        while(!exit);
        System.out.println("bye!");
    }
    
}
