create table personas
(
    identificador serial,
    nombre varchar(50),
    primary key(identificador)
);
create table cursos
(
    identificador   serial,
    nombre varchar(50),
     primary key(identificador)
);

create table matriculados
(
    id_persona integer references personas(identificador),
    id_curso integer references cursos(identificador),
    primary key(id_persona,id_curso)
);


insert into personas(nombre) values('GM'),('Herreros'),('Ossa');

insert into cursos(nombre) values('Clousure'),('Rust');

insert into matriculados(id_persona,id_curso) values(1,2),(3,1),(3,2);