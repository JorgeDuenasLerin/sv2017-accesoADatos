/*
Antonio Defez
 */
package cliente_compra;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
create table cliente
(
    id varchar(20),
    nombre varchar(30),
    primary key(id)
)

create table compra
(
    codigo varchar(10),
    precio numeric(4,2),
    cliente varchar(20) references cliente(id),
    primary key(codigo)
)


 */
public class Cliente_compra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger
                = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate")
                .setLevel(java.util.logging.Level.SEVERE);

        boolean salida = false;
        Scanner entrada = new Scanner(System.in);
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        do {
            mostrarMenu();
            String opcion = entrada.nextLine();
            switch (opcion) {
                case "1":
                    insertarCliente(sesion);
                    break;
                case "2":
                    insertarCompra(sesion);
                    break;
                case "3":
                    mostrarComprasCliente(sesion);
                    break;
                case "0":
                    salida = true;
                    break;
            }
        } while (!salida);
        sesion.close();
        NewHibernateUtil.getSessionFactory().close();
    }

    private static void mostrarMenu() {
        System.out.println("1.  Insertar usuario");
        System.out.println("2.  Insertar compra");
        System.out.println("3.  Mostrar compras de un cliente");
    }

    private static Cliente crearCliente() {
        Scanner entrada = new Scanner(System.in);
        String id;
        String nombre;
        System.out.println("Introduce el id del cliente");
        id = entrada.nextLine();
        System.out.println("Introduce su nombre");
        nombre = entrada.nextLine();

        return (new Cliente(id, nombre));
    }

    private static Compra crearCompra() {
        Scanner entrada = new Scanner(System.in);
        String codigo;
        BigDecimal precio;
        System.out.println("Introduce el codigo del producto");
        codigo = entrada.nextLine();
        System.out.println("Introudce el precio del producto");
        precio = entrada.nextBigDecimal();
        return (new Compra(codigo, precio));
    }

    private static void insertarCliente(Session sesion) {
        Cliente tmp = crearCliente();
        try {
            Transaction trans = sesion.beginTransaction();
            sesion.save(tmp);
            trans.commit();
            System.out.println("El usuario ha sido introducido cliente");

        } catch (HibernateException e) {
            System.out.println("Error al introducir el nuevo cliente");
        }
    }

    private static void insertarCompra(Session sesion) {
        Compra tmp_compra = crearCompra();
        try {
            Cliente tmp_cliente = obtenerCliente(sesion);
            if (tmp_cliente == null) {
                System.out.println("El usuario no existe compra no posible");
            } else {
                Transaction trans = sesion.beginTransaction();
               
                tmp_compra.setCliente(tmp_cliente);
                sesion.save(tmp_compra);
                trans.commit();
            }

        } catch (HibernateException e) {
            System.out.println("Error al introducir la nueva compra");
        }
    }

    private static void mostrarComprasCliente(Session sesion) {
        Cliente tmp_cliente = obtenerCliente(sesion);
        if(tmp_cliente ==null)
        {
            System.out.println("El cliente no existe");
        }
        else
        {
            System.out.println("Datos cliente");
            System.out.println(tmp_cliente);
            System.out.println("Lista de compras");
            tmp_cliente.mostrarLista();
        }
    }

    private static Cliente obtenerCliente(Session sesion) {
        Scanner entrada = new Scanner(System.in);
        String id;
        System.out.println("Introudce el id del cliente");
        id = entrada.nextLine();

        Query consulta
                = sesion.createQuery("from Cliente where id like '%" + id + "%'");
        List resultados = consulta.list();
        if (resultados.isEmpty()) {
            return null;
        } else {
            Cliente tmp = (Cliente) resultados.get(0);
            return tmp;
        }

    }

}
