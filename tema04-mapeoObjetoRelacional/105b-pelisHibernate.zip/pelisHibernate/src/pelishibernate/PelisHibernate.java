/*
SERGIO GARCIA BALSAS
SQL:
CREATE TABLE actor
(
    idActor NUMERIC(4) PRIMARY KEY,
    nombreActor varchar(30),
    apellidos varchar(60)
);

CREATE TABLE pelicula
(
    idPelicula NUMERIC(4) PRIMARY KEY,
    titulo VARCHAR(30),
    ano NUMERIC(4),
    director VARCHAR(30),
    valoracion NUMERIC(3),
    ubicacion VARCHAR(30),
    tamanioMB NUMERIC(6)
);

CREATE TABLE rueda 
(
    idActorRueda NUMERIC(4) REFERENCES actor(idActor),
    idPelicula NUMERIC(4) REFERENCES pelicula(idPelicula),
    PRIMARY KEY(idActorRueda, idPelicula)
);


 */
package pelishibernate;

import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author sergio
 */
public class PelisHibernate
{

    public static void Menu()
    {
        System.out.println("1. Añadir actor/actriz");
        System.out.println("2. Añadir pelicula");
        System.out.println("3. Buscar peliculas por titulo (parcial) ");
        System.out.println("4. Buscar actores ");
        System.out.println("5. Buscar peliculas por director");
        System.out.println("6. Mostrar todo (Opcion invetada por mi)");
        System.out.println("7. Añadir actores en peliculas (Inventada por mi)");
        System.out.println("0. Salir");
    }

    public static void main(String[] args)
    {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);

        boolean salir = false;
        Scanner sc = new Scanner(System.in);
        do
        {
            Menu();
            String opcion = sc.nextLine();
            switch (opcion)
            {
                case "1": //Añadir actor/actriz
                    System.out.println("Id del actor?");
                    short id = Short.parseShort(sc.nextLine());
                    System.out.print("Introduzca el nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Introduzca apellidos: ");
                    String apellidos = sc.nextLine();

                    Session sesion
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Transaction trans = sesion.beginTransaction();
                    Actor actor = new Actor(id, nombre, apellidos, null);
                    sesion.save(actor);
                    trans.commit();
                    sesion.close();
                    break;
                case "2": //Añadir pelicula
                    System.out.println("Id de la pelicula?");
                    short idPelicula = Short.parseShort(sc.nextLine());
                    System.out.print("Introduzca el nombre de la pelicula: ");
                    String nombrePelicula = sc.nextLine();
                    System.out.println("Año de la pelicula?");
                    short ano = Short.parseShort(sc.nextLine());
                    System.out.print("Director de la pelicula: ");
                    String director = sc.nextLine();
                    System.out.println("Valoracion ?[0-10]");
                    short valoracion = Short.parseShort(sc.nextLine());
                    System.out.print("Introduzca ubicacion de la pelicula: ");
                    String ubicacion = sc.nextLine();
                    System.out.print("Tamaño en MB de la pelicula?: ");
                    int tamanio = Integer.parseInt(sc.nextLine());

                    Session sesion2
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Transaction trans2 = sesion2.beginTransaction();
                    Pelicula peli = new Pelicula(idPelicula, nombrePelicula,
                            ano, director, valoracion, ubicacion, tamanio, null);
                    sesion2.save(peli);
                    trans2.commit();
                    sesion2.close();
                    break;
                case "3": //Buscar peliculas por titulo
                    System.out.println("Nombre de la pelicula?");
                    String nombrePeli = sc.nextLine().toLowerCase();
                    Session sesion4
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta4
                            = sesion4.createQuery("select titulo, director from "
                                    + "Pelicula WHERE LOWER(titulo) LIKE'%"
                                    + nombrePeli + "%'");
                    List<Object[]> resultados5 = consulta4.list();
                    if (resultados5.size() > 0)
                    {
                        for (Object[] resultado : resultados5)
                        {

                            System.out.println("Titulo: " + (String) resultado[0]);
                            System.out.println("Director: " + (String) resultado[1]);
                        }
                    } else
                    {
                        System.out.println("No hay peliculas con ese titulo");
                    }

                    sesion4.close();
                    break;
                case "4": //Buscar actores
                    System.out.println("Nombre del actor?");
                    String nombreActor = sc.nextLine().toLowerCase();
                    Session sesion66
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta66
                            = sesion66.createQuery("select nombreactor, "
                                    + "apellidos from Actor "
                                    + "WHERE LOWER(nombreactor) LIKE'%"
                                    + nombreActor + "%'");
                    List<Object[]> resultados66 = consulta66.list();
                    if (resultados66.size() > 0)
                    {
                        for (Object[] resultado : resultados66)
                        {

                            System.out.println("Nombre: " + (String) resultado[0]);
                            System.out.println("Apellidos: " + (String) resultado[1]);
                        }
                    } else
                    {
                        System.out.println("No hay actores con ese nombre");
                    }

                    sesion66.close();
                    break;
                case "5": //buscar peliculas por director
                    System.out.println("Nombre del director?");
                    String directorPeli = sc.nextLine().toLowerCase();
                    Session sesion5
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta5
                            = sesion5.createQuery("select titulo, "
                                    + "director from Pelicula "
                                    + "WHERE LOWER(director) LIKE'%"
                                    + directorPeli + "%'");
                    List<Object[]> resultados6 = consulta5.list();
                    if (resultados6.size() > 0)
                    {
                        for (Object[] resultado : resultados6)
                        {

                            System.out.println("Titulo: " + (String) resultado[0]);
                            System.out.println("Director: " + (String) resultado[1]);
                        }
                    } else
                    {
                        System.out.println("No hay peliculas con ese director");
                    }

                    sesion5.close();
                    break;
                case "6": //Mostrar todo
                    System.out.println("Mostrando todos los datos:");
                    Session sesion3
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta = sesion3.createQuery("from Pelicula");
                    List resultados = consulta.list();
                    Actor a2 = new Actor();
                    for (Object resultado : resultados)
                    {
                        Pelicula pelicula = (Pelicula) resultado;
                        System.out.println(
                                "ID: " + pelicula.getIdpelicula()
                                + " Titulo: " + pelicula.getTitulo()
                                + " Año: " + pelicula.getAno()
                                + " Director: " + pelicula.getDirector()
                                + " Ubicacion: " + pelicula.getUbicacion()
                                + " Valoracion: " + pelicula.getValoracion()
                                + " Tamaño MB: " + pelicula.getTamaniomb()
                                + " Reparto: "
                        );
                        String reparto = "";
                        for (Object r : pelicula.getActors())
                        {
                            a2 = (Actor) r;
                            reparto += a2.getNombreactor() + " " + a2.getApellidos() + " , ";
                        }
                        System.out.println(reparto);

                    }

                    System.out.println("Mostrando actores con peliculas interpretadas");

                    Query consulta2 = sesion3.createQuery("from Actor");
                    List resultados2 = consulta2.list();
                    Pelicula p = new Pelicula();
                    for (Object rs : resultados2)
                    {
                        Actor a = (Actor) rs;
                        System.out.println("ID del actor : " + a.getIdactor()
                                + " Nombre del actor: " + a.getNombreactor()
                                + " Apellidos del actor: " + a.getApellidos());

                        String pelis = "";
                        for (Object j : a.getPeliculas())
                        {
                            p = (Pelicula) j;
                            pelis += p.getTitulo() + " , ";
                        }
                        System.out.println(pelis);
                    }

                    sesion3.close();
                    break;
                case "7": //Añadir actores en peliculas
                    System.out.println("Id del actor?");
                    short idActor = Short.parseShort(sc.nextLine());

                    System.out.println("Id de la peli que ha participado?");
                    short idPeli = Short.parseShort(sc.nextLine());

                    Session sesion77
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta77 = sesion77.createQuery(
                            "FROM Actor WHERE id=" + idActor);
                    
                     Query consulta88 = sesion77.createQuery(
                            "FROM Pelicula WHERE id=" + idPeli);
                    
                    
                    List resultados77 = consulta77.list();
                    List resultados88 = consulta88.list();
                    
                    Actor actorAModificar = (Actor) resultados77.get(0);
                    Pelicula peliModificar = (Pelicula) resultados88.get(0);
                    
                    
                    Transaction trans77 = sesion77.beginTransaction();
                    actorAModificar.getPeliculas().add(peliModificar);
                    sesion77.update(actorAModificar);
                                
                    trans77.commit();
                    sesion77.close();
                    break;
                case "0":
                    salir = true;
                    break;

            }
        } while (!salir);
        System.out.println("Adios");

        NewHibernateUtil.getSessionFactory().close();
    }

}
