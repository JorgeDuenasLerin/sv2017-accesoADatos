﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 //las tablas son aproximadas, las he hecho a posteriori
  CREATE TABLE dueno
  (
     idDueno varchar(30) PRIMARY KEY,
     nombreDueno varchar(30)
   )  


  CREATE TABLE perro 
  (
      idPerro varchar (30) PRIMARY KEY,
      nombrePerro varchar(30)
      dueno varchar(30) REFERENCES dueno (idDueno)
   )

 */
package h;

import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author sergio
 */
public class H
{

    public static void Menu()
    {
        System.out.println("1. Mostrar");
        System.out.println("2. Añadir perro");
        System.out.println("3. Añadir dueño");
        System.out.println("4. Añadir perro con su dueño");
        System.out.println("5. Salir");
    }

    public static void main(String[] args)
    {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);

        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        do
        {
            Menu();
            String opcion = sc.nextLine();
            switch (opcion)
            {
                case "1": //Mostrar
                    System.out.println("Mostrando todos los datos:");
                    Session sesion
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta = sesion.createQuery("from Perro");
                    List resultados = consulta.list();
                    for (Object resultado : resultados)
                    {
                        Perro p = (Perro) resultado;
                        System.out.println("ID: " + p.getIdperro()
                                + " nombre del perro: " + p.getNombreperro());
                        if (p.getDueno() != null)
                        {
                            System.out.println(" Dueño: " + p.getDueno().getNombredueno());
                        } else
                        {
                            System.out.println("No tiene dueño");
                        }
                    }
                    System.out.println();
                    //Lo mismo para ver los perros de un dueño
                    Query consulta2 = sesion.createQuery("from Dueno");
                    List resultados2 = consulta2.list();
                    for (Object resultado : resultados2)
                    {
                        Dueno d = (Dueno) resultado;

                        System.out.println("ID: " + d.getIddueno()
                                + " nombre del dueño: " + d.getNombredueno()
                                + " Perros que tiene: "
                        );
                        Perro p2 = new Perro();
                        String perros = "";
                        for (Object r : d.getPerros())
                        {
                            p2 = (Perro) r;
                            perros += p2.getNombreperro() + " ";

                        }
                        System.out.println(perros);
                    }

                    sesion.close();
                    break;
                case "2": //Añadir perro con su dueño
                    System.out.print("Introduzca el código del perro: ");
                    short idPerro = Short.parseShort(sc.nextLine());
                    System.out.print("Introduzca el nombre del perro: ");
                    String nombrePerro = sc.nextLine();

                    Session sesion2
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Transaction trans = sesion2.beginTransaction();
                    Perro perrito = new Perro(idPerro, null, nombrePerro);
                    sesion2.save(perrito);
                    trans.commit();
                    sesion2.close();
                case "3": //Añadir dueño
                    System.out.print("Introduzca el código del dueño: ");
                    short idDueno = Short.parseShort(sc.nextLine());
                    System.out.print("Introduzca nombre dueño: ");
                    String nombreDueno = sc.nextLine();

                    Session sesion3
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Transaction trans2 = sesion3.beginTransaction();
                    Dueno d = new Dueno(idDueno, nombreDueno, null);
                    sesion3.save(d);
                    trans2.commit();
                    sesion3.close();
                    break;
                case "4": //Añadir un perro a un dueño
                    System.out.println("Id del dueno?");
                    short idDuenoM = Short.parseShort(sc.nextLine());
                    System.out.println("Id del perro?");
                    short idPerroM = Short.parseShort(sc.nextLine());

                    Session sesion4
                            = NewHibernateUtil.getSessionFactory().openSession();
                    Query consulta4 = sesion4.createQuery("from Perro where idperro=" + idPerroM);
                    List resultados4 = consulta4.list();
                    Perro perroAdoptado = (Perro) resultados4.get(0);

                    Query consulta5 = sesion4.createQuery("from Dueno where iddueno=" + idDuenoM);
                    List resultados5 = consulta5.list();
                    Dueno duenoAdoptador = (Dueno) resultados5.get(0);

                    System.out.println(" El dueño " + duenoAdoptador.getNombredueno()
                            + " desea adoptar a " + perroAdoptado.getNombreperro());
                    String respuesta = sc.nextLine().toLowerCase();
                    if (respuesta.equals("si"))
                    {
                        Transaction trans4 = sesion4.beginTransaction();
                        perroAdoptado.setDueno(duenoAdoptador);
                        sesion4.update(perroAdoptado);
                        trans4.commit();
                       
                    } else
                    {
                        System.out.println("No se adpota");
                    }

                    sesion4.close();

                    break;
                case "5":
                    salir = true;
                    break;
            }
        } while (!salir);
        System.out.println("Adios");

        NewHibernateUtil.getSessionFactory().close();
    }

}
