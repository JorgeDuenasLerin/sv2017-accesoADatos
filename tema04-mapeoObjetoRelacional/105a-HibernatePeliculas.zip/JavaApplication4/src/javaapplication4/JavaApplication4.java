//Mario Belso Ros - Hibernate PrePreExamen.
package javaapplication4;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/*
    CREATE TABLE actores(
	id VARCHAR(15) PRIMARY KEY,
    nombre VARCHAR(25),
    apellido VARCHAR(60)
);

CREATE TABLE peliculas(
	id VARCHAR(15) PRIMARY KEY,
    titulo VARCHAR(35),
    anyo NUMERIC(4),
    director VARCHAR(40),
    valoracion NUMERIC(100),
    ubicacion VARCHAR(45),
    tamanyo NUMERIC(8,2)
);

CREATE TABLE actuar(
	idPeli VARCHAR(15),
    idActor VARCHAR(15),
    FOREIGN KEY (idPeli) REFERENCES peliculas (id),
    FOREIGN KEY (idActor) REFERENCES actores (id),
    PRIMARY KEY (idPeli, idActor)
);




 */
public class JavaApplication4 {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
        String opc = "";

        do {
            mostrarMenu();
            opc = sc.nextLine();
            switch (opc) {
                case "1":
                    anyadirActor();
                    break;
                case "2":
                    anyadirPelicula();
                    break;
                case "3":
                    mostrarMenuBusqueda();
                    opc = sc.nextLine();
                    switch (opc) {
                        case "1":
                            busquedaTitulo();
                            break;
                        case "2":
                            busquedaNombre();
                            break;
                        case "3":
                            busquedaDirector();
                            break;
                    }

                    break;
                case "4":
                    anyadirActorAPelicula();
                    break;
                case "0":
                    NewHibernateUtil.getSessionFactory().close();
                    break;
            }

        } while (!opc.equals("0"));

    }

    static void mostrarMenu() {
        System.out.println();
        System.out.println("1.- Añadir actor/actriz.");
        System.out.println("2.- Añadir pelicula.");
        System.out.println("3.- Busqueda.");
        System.out.println("4.- Añadir actor al reparto de una pelicula.");
        //Me parecia mas ordenado y "simple" para el usuario el que se añada el actor a la pelicula por separado.
        System.out.println("0.- Salir");
        System.out.println("Introduzca una opcion: ");
        System.out.println();
    }

    static void mostrarMenuBusqueda() {
        System.out.println();
        System.out.println("1.- Peliculas por titulo.");
        System.out.println("2.- Actores por nombre.");
        System.out.println("3.- Peliculas por director.");
        System.out.println("Introduzca una opcion: ");
        System.out.println();
    }

    static void anyadirActor() {
        System.out.println("Introduzca la id del actor (dni?): ");
        String id = sc.nextLine();
        System.out.println("Introduzca el nombre del actor: ");
        String nombre = sc.nextLine();
        System.out.println("Introduza el apelliudo del actor: ");
        String apellido = sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();
        Actores actor = new Actores(id, nombre, apellido, null);
        sesion.save(actor);
        trans.commit();
        sesion.close();
        System.out.println("Actor añadido!");
    }

    static void anyadirPelicula() {
        System.out.println("Introduzca la id de la pelicula: ");
        String id = sc.nextLine();
        System.out.println("introduzca el titulo de la pelicula: ");
        String titulo = sc.nextLine();
        System.out.println("Introduzca el año de la pelicula: ");
        short anyo = sc.nextShort();
        sc.nextLine();
        System.out.println("Introduzca el director de la pelicula: ");
        String director = sc.nextLine();
        System.out.println("Introduzca la valoracion de la pelicula: ");
        BigDecimal valoracion = sc.nextBigDecimal();
        sc.nextLine();
        System.out.println("Introduzca la ubicacion de la pelicula:");
        String ubicacion = sc.nextLine();
        System.out.println("Introduzca el tamaño de la pelicula: ");
        BigDecimal tamanyo = sc.nextBigDecimal();
        sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();
        Peliculas pelicula = new Peliculas(id, titulo, anyo, director, valoracion,
                ubicacion, tamanyo, null);
        sesion.save(pelicula);
        trans.commit();
        sesion.close();
        System.out.println("Pelicula guardada!");
    }

    static void anyadirActorAPelicula() {
        Set actoresMod = new HashSet();
        System.out.println("Mostrando actores disponibles (id, nombre): ");
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery("from Actores");
        List actores = consulta.list();
        System.out.println("Id                    Nombre");
        for (Object resultado : actores) {
            Actores actor = (Actores) resultado;
            System.out.println(String.format("%-15s", actor.getId())
                    + String.format("%-15s", actor.getNombre()));
        }
        System.out.println("Introduzca la id del actor a añadir: ");
        String idActor = sc.nextLine();

        System.out.println("Mostrando peliculas disponibles (id, titulo): ");
        consulta = sesion.createQuery("from Peliculas");
        List peliculas = consulta.list();
        System.out.println("Id                    Titulo");
        for (Object resultado : peliculas) {
            Peliculas pelicula = (Peliculas) resultado;
            System.out.println(String.format("%-15s", pelicula.getId())
                    + String.format("%-15s", pelicula.getTitulo()));
        }
        System.out.println("Introduzca la id de la pelicula a modificar: ");
        String idPeli = sc.nextLine();
        for (Object resultado : actores) {
            Actores actor = (Actores) resultado;
            if (actor.getId().toLowerCase().equals(idActor.toLowerCase())) {
                consulta = sesion.createQuery(
                        "FROM Peliculas WHERE id='" + idPeli + "'");
                List pelicula = consulta.list();
                Peliculas peliMod = (Peliculas) pelicula.get(0);
                Transaction trans = sesion.beginTransaction();
                actoresMod = peliMod.getActoreses();
                actoresMod.add(new Actores(actor.getId(), actor.getNombre(),
                        actor.getApellido(), null));
                peliMod.setActoreses(actoresMod);
                sesion.update(peliMod);
                trans.commit();
            }
        }
        sesion.close();
        System.out.println("Actor añadido al reparto!");
    }

    static void busquedaDirector() {
        System.out.println("Introduzca el nombre del director: ");
        String director = sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Peliculas where director='" + director + "'");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Peliculas pelicula = (Peliculas) resultado;
            System.out.println(pelicula.toString());
        }
        sesion.close();
    }

    static void busquedaTitulo() {
        System.out.println("Introduzca el titulo de la pelicula: ");
        String titulo = sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Peliculas where titulo='" + titulo + "'");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Peliculas pelicula = (Peliculas) resultado;
            System.out.println(pelicula.toString());
        }
        sesion.close();
    }

    static void busquedaNombre() {
        System.out.println("Introduzca el nombre del actor: ");
        String nombre = sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Actores where nombre='" + nombre + "'");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Actores actor = (Actores) resultado;
            System.out.println(actor.toString());
        }
        sesion.close();
    }
}
