--Antonio Sevila

CREATE TABLE personas (
	cod NUMERIC(4) PRIMARY KEY,
	nombre VARCHAR(50),
	email VARCHAR(60),
);

CREATE TABLE cursos (
	cod NUMERIC(4) PRIMARY KEY,
	nombre VARCHAR(50),
	fechaInicio date,
	fechaFin date
);

CREATE TABLE cursar(
	codPersona NUMERIC(4),
	codCurso NUMERIC(4),
	PRIMARY KEY (codPersona, codCurso),
	FOREIGN KEY (codPersona) REFERENCES personas(cod),
	FOREIGN KEY (codCurso) REFERENCES cursos(cod)
);


--Inserts

INSERT INTO personas VALUES (111, 'Herreros', 'Herreros@gmail.com');
INSERT INTO personas VALUES (222, 'GM', 'GM@gmail.com');
INSERT INTO personas VALUES (333, 'Ossa', 'Ossa@gmail.com');

INSERT INTO cursos VALUES (123, 'Clojure', '10/10/1992', '10/10/1993');
INSERT INTO cursos VALUES (234, 'Rust', '10/10/2002', '10/10/2003');

INSERT INTO cursar VALUES (222, 234);
INSERT INTO cursar VALUES (333, 123);
INSERT INTO cursar VALUES (333, 234);