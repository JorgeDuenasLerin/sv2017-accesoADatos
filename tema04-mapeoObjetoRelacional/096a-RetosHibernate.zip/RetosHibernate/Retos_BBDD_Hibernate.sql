--Antonio Sevila Díaz

--TABLE (id numeric 4, titulo 30, descripcion text, dificultad - 1..10 -) -> 

CREATE TABLE reto(
	id NUMERIC(4) PRIMARY KEY,
	titulo VARCHAR(30),
	descripcion text,
	dificultad NUMERIC(2)
);

--INSERTS
INSERT INTO reto
	VALUES (100, 'Campanadas', 'Crear un programa que diga el número de campanadas', 7);
	
INSERT INTO reto
	VALUES (200, 'Caramelos', 'Caramelos para todos', 3);
	
INSERT INTO reto
	VALUES (300, 'Natacion', 'Cuantas brazadas da el nadador en X vueltas', 5);