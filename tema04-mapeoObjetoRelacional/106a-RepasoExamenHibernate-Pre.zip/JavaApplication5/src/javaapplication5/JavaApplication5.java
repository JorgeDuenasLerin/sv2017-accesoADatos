//Mario Belso Ros - Simulacro.
package javaapplication5;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class JavaApplication5 {

    /**
     * CREATE TABLE clientes( codigo VARCHAR(15) PRIMARY KEY, nombre
     * VARCHAR(70), direccion VARCHAR(50), telefono VARCHAR(13) );
     *
     * CREATE TABLE vehiculos ( matricula VARCHAR(8) PRIMARY KEY, marca
     * VARCHAR(25), modelo VARCHAR(35), color VARCHAR(25), importe NUMERIC(7,2)
     * );
     *
     * CREATE TABLE furgonetas( capacidad NUMERIC(7,2) )INHERITS(vehiculos);
     *
     * ALTER TABLE furgonetas ADD PRIMARY KEY(matricula);
     *
     * CREATE TABLE alquilar ( idMatricula VARCHAR(8), idCodigo VARCHAR(15),
     * fechaEntrega TIMESTAMP, fechaSalida TIMESTAMP, kilometros NUMERIC(10,2),
     * comentarios TEXT, FOREIGN KEY (idMatricula) REFERENCES
     * vehiculos(matricula), FOREIGN KEY (idCodigo) REFERENCES clientes
     * (codigo), PRIMARY KEY(idMatricula, idCodigo, fechaEntrega) );
     *
     */
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger
                = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate")
                .setLevel(java.util.logging.Level.SEVERE);

        String opc = "";

        do {
            mostrarMenu();
            opc = sc.nextLine();
            switch (opc) {
                case "1":
                    anyadirAlquiler();
                    break;
                case "2":

                    break;

                case "3":
                    buscarAlquilerPendiente();
                    break;
                case "4":
                    anyadirCliente();
                    break;
                case "5":
                    buscarClientes();
                    break;

                case "6":
                    anyadirVehiculo();
                    break;

                case "7":
                    buscarVehiculos();
                    break;
                case "8":
                    modificarVehiculo();
                    break;
                case "0":
                    NewHibernateUtil.getSessionFactory().close();
                    break;
                default:
                    System.out.println("Opcion erronea, vuelve a intentarlo.");
                    break;
            }

        } while (!opc.equals("0"));

    }

    static void mostrarMenu() {
        System.out.println();
        System.out.println("1.- Alquiler de vehiculos.");
        System.out.println("2.- Devolucion de vehiculos.");
        System.out.println("3.- Ver devoluciones pendientes.");
        System.out.println("4.- Nuevo cliente.");
        System.out.println("5.- Buscar clientes.");
        System.out.println("6.- Nuevo vehiculo.");
        System.out.println("7.- Buscar vehiculos.");
        System.out.println("8.- Modificar vehiculo.");
        System.out.println("0.- Salir.");
        System.out.println("Introduzca una opcion: ");
        System.out.println();

    }

    static void anyadirVehiculo() {
        System.out.println("Introduce la matricula del coche: ");
        String matricula = sc.nextLine();
        System.out.println("Introduce la marca del coche: ");
        String marca = sc.nextLine();
        System.out.println("Introduce el modelo del coche: ");
        String modelo = sc.nextLine();
        System.out.println("Introduce el color del coche: ");
        String color = sc.nextLine();
        System.out.println("Introduce el importe diario: ");
        BigDecimal importe = sc.nextBigDecimal();

        Vehiculos vehiculo = new Vehiculos(matricula, marca, modelo,
                color, importe, null);
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();
        sesion.save(vehiculo);
        trans.commit();
        sesion.close();
        System.out.println("Vehiculo añadido!");
    }

    static void anyadirAlquiler() {
        System.out.println("Introduzca el codigo del cliente: ");
        String codigo = sc.nextLine();
        System.out.println("Introduzca la matricula del coche: ");
        String matricula = sc.nextLine();
        Date fechaActual = new Date();
        Alquilar alquiler = new Alquilar(new AlquilarId(matricula, codigo, fechaActual),
                null, null, null, null, null);
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();
        sesion.save(alquiler);
        trans.commit();
        sesion.close();
        System.out.println("Alquiler añadido!");
    }

    static void anyadirCliente() {
        System.out.println("Introduce el codigo del cliente: ");
        String codigo = sc.nextLine();
        System.out.println("Introduce el nombre del cliente: ");
        String nombre = sc.nextLine();
        System.out.println("Introduce la direccion del cliente: ");
        String direccion = sc.nextLine();
        System.out.println("Introduce el telefono del cliente: ");
        String telefono = sc.nextLine();
        Clientes cliente = new Clientes(codigo, nombre, direccion,
                telefono, null);
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Transaction trans = sesion.beginTransaction();
        sesion.save(cliente);
        trans.commit();
        sesion.close();
        System.out.println("Cliente añadido!");
    }

    static void buscarClientes() {
        System.out.println("Inserte un nombre para buscar coincidencias: ");
        String nombre = sc.nextLine().toLowerCase();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Clientes WHERE LOWER(nombre) LIKE '%" + nombre + "%'");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Clientes cliente = (Clientes) resultado;
            System.out.println(cliente.toString());
        }
        sesion.close();
    }

    static void buscarVehiculos() {
        System.out.println("Inserte una marca para buscar coincidencias: ");
        String marca = sc.nextLine().toLowerCase();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Vehiculos WHERE LOWER(marca) LIKE '%" + marca + "%'");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Vehiculos vehiculo = (Vehiculos) resultado;
            System.out.println(vehiculo.toString());
        }
        sesion.close();
    }
    
    static void buscarAlquilerPendiente() {
        
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "from Alquilar WHERE fechaSalida is null");
        List resultados = consulta.list();
        for (Object resultado : resultados) {
            Alquilar alquiler = (Alquilar) resultado;
            System.out.println(alquiler.toString());
        }
        sesion.close();
    }

    static void modificarVehiculo() {
        System.out.println("Introduzca la matricula del coche a modificar: ");
        String matricula = sc.nextLine();
        Session sesion
                = NewHibernateUtil.getSessionFactory().openSession();
        Query consulta = sesion.createQuery(
                "FROM Vehiculos WHERE matricula='" + matricula + "'");
        List resultados = consulta.list();
        Vehiculos vehiculoMod = (Vehiculos) resultados.get(0);
        System.out.println("Introduzca el nuevo color del coche: ");
        String color = sc.nextLine();
        vehiculoMod.setColor(color);
        Transaction trans = sesion.beginTransaction();
        sesion.update(vehiculoMod);
        trans.commit();
        sesion.close();
    }

}
